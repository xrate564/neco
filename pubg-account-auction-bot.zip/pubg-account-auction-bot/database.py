"""Small SQLite data layer. Bid placement and state transitions are transactional."""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def as_utc_iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds")


def parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


class Database:
    def __init__(self, path: str) -> None:
        self.path = path
        if path != ":memory:":
            Path(path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def initialize(self) -> None:
        conn = self._connect()
        try:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS auctions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    seller_id INTEGER NOT NULL,
                    seller_name TEXT NOT NULL,
                    seller_username TEXT,
                    description TEXT NOT NULL,
                    images_json TEXT NOT NULL,
                    start_price INTEGER NOT NULL,
                    current_price INTEGER NOT NULL,
                    current_bidder_id INTEGER,
                    current_bidder_name TEXT,
                    bid_count INTEGER NOT NULL DEFAULT 0,
                    duration_hours INTEGER NOT NULL,
                    starts_at TEXT,
                    ends_at TEXT,
                    status TEXT NOT NULL DEFAULT 'pending',
                    channel_album_message_id INTEGER,
                    channel_post_message_id INTEGER,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS bids (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    auction_id INTEGER NOT NULL,
                    bidder_id INTEGER NOT NULL,
                    bidder_name TEXT NOT NULL,
                    amount INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (auction_id) REFERENCES auctions(id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_auctions_seller ON auctions(seller_id, created_at);
                CREATE INDEX IF NOT EXISTS idx_auctions_status_end ON auctions(status, ends_at);
                CREATE INDEX IF NOT EXISTS idx_bids_auction ON bids(auction_id, created_at);
                """
            )
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def _row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
        return dict(row) if row is not None else None

    def create_auction(
        self,
        *,
        seller_id: int,
        seller_name: str,
        seller_username: str | None,
        description: str,
        images: list[str],
        start_price: int,
        duration_hours: int,
    ) -> int:
        conn = self._connect()
        try:
            cur = conn.execute(
                """
                INSERT INTO auctions (
                    seller_id, seller_name, seller_username, description, images_json,
                    start_price, current_price, duration_hours, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
                """,
                (
                    seller_id,
                    seller_name,
                    seller_username,
                    description,
                    json.dumps(images, ensure_ascii=False),
                    start_price,
                    start_price,
                    duration_hours,
                    as_utc_iso(utc_now()),
                ),
            )
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()

    def get_auction(self, auction_id: int) -> dict[str, Any] | None:
        conn = self._connect()
        try:
            row = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            result = self._row_to_dict(row)
            if result is not None:
                result["images"] = json.loads(result.pop("images_json"))
            return result
        finally:
            conn.close()

    def list_seller_auctions(self, seller_id: int, limit: int = 10) -> list[dict[str, Any]]:
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT * FROM auctions WHERE seller_id = ? ORDER BY id DESC LIMIT ?",
                (seller_id, limit),
            ).fetchall()
            result = []
            for row in rows:
                item = dict(row)
                item["images"] = json.loads(item.pop("images_json"))
                result.append(item)
            return result
        finally:
            conn.close()

    def list_active_auctions(self) -> list[dict[str, Any]]:
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT * FROM auctions WHERE status = 'active' ORDER BY ends_at"
            ).fetchall()
            result = []
            for row in rows:
                item = dict(row)
                item["images"] = json.loads(item.pop("images_json"))
                result.append(item)
            return result
        finally:
            conn.close()

    def claim_for_publish(self, auction_id: int) -> tuple[str, dict[str, Any] | None]:
        """Atomically claim a pending listing for publication; failed posts can be retried."""
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            if row is None:
                conn.commit()
                return "not_found", None
            if row["status"] not in ("pending", "publish_failed"):
                status = str(row["status"])
                conn.commit()
                return status, None

            start = utc_now()
            end = start + timedelta(hours=int(row["duration_hours"]))
            conn.execute(
                """
                UPDATE auctions SET status = 'publishing', starts_at = ?, ends_at = ?
                WHERE id = ?
                """,
                (as_utc_iso(start), as_utc_iso(end), auction_id),
            )
            claimed = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            conn.commit()
            result = self._row_to_dict(claimed)
            if result is not None:
                result["images"] = json.loads(result.pop("images_json"))
            return "claimed", result
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def mark_publish_failed(self, auction_id: int) -> None:
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE auctions SET status = 'publish_failed' WHERE id = ? AND status = 'publishing'",
                (auction_id,),
            )
            conn.commit()
        finally:
            conn.close()

    def save_album_message_id(self, auction_id: int, message_id: int) -> None:
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE auctions SET channel_album_message_id = ? WHERE id = ?",
                (message_id, auction_id),
            )
            conn.commit()
        finally:
            conn.close()

    def save_post_message_id(self, auction_id: int, message_id: int) -> None:
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE auctions SET channel_post_message_id = ? WHERE id = ?",
                (message_id, auction_id),
            )
            conn.commit()
        finally:
            conn.close()

    def mark_active(self, auction_id: int) -> None:
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE auctions SET status = 'active' WHERE id = ? AND status = 'publishing'",
                (auction_id,),
            )
            conn.commit()
        finally:
            conn.close()

    def reject_auction(self, auction_id: int) -> tuple[bool, dict[str, Any] | None]:
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            if row is None or row["status"] not in ("pending", "publish_failed"):
                conn.commit()
                return False, self._row_to_dict(row)
            conn.execute("UPDATE auctions SET status = 'rejected' WHERE id = ?", (auction_id,))
            updated = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            conn.commit()
            return True, self._row_to_dict(updated)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def place_bid(
        self,
        *,
        auction_id: int,
        bidder_id: int,
        bidder_name: str,
        amount: int,
        minimum_increment: int,
    ) -> tuple[str, dict[str, Any] | None, int | None, int | None]:
        """Return (result, auction, minimum_required, previous_bidder_id)."""
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            if row is None:
                conn.commit()
                return "not_found", None, None, None
            auction = dict(row)
            previous_bidder_id = auction["current_bidder_id"]

            if auction["status"] != "active":
                conn.commit()
                return "inactive", auction, None, previous_bidder_id
            if int(auction["seller_id"]) == bidder_id:
                conn.commit()
                return "seller", auction, None, previous_bidder_id

            ends_at = parse_datetime(auction["ends_at"])
            if ends_at is None or ends_at <= utc_now():
                conn.commit()
                return "expired", auction, None, previous_bidder_id

            if auction["current_bidder_id"] is None:
                minimum = int(auction["start_price"])
            else:
                minimum = int(auction["current_price"]) + minimum_increment
            if amount < minimum:
                conn.commit()
                return "too_low", auction, minimum, previous_bidder_id

            now = as_utc_iso(utc_now())
            conn.execute(
                "INSERT INTO bids (auction_id, bidder_id, bidder_name, amount, created_at) VALUES (?, ?, ?, ?, ?)",
                (auction_id, bidder_id, bidder_name, amount, now),
            )
            conn.execute(
                """
                UPDATE auctions
                SET current_price = ?, current_bidder_id = ?, current_bidder_name = ?, bid_count = bid_count + 1
                WHERE id = ? AND status = 'active'
                """,
                (amount, bidder_id, bidder_name, auction_id),
            )
            updated = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            conn.commit()
            return "ok", self._row_to_dict(updated), minimum, previous_bidder_id
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def close_auction_if_due(self, auction_id: int) -> dict[str, Any] | None:
        """Close once only. Returns the closed row only for the process that won the transition."""
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            if row is None or row["status"] != "active":
                conn.commit()
                return None
            ends_at = parse_datetime(row["ends_at"])
            if ends_at is None or ends_at > utc_now():
                conn.commit()
                return None
            conn.execute("UPDATE auctions SET status = 'closed' WHERE id = ? AND status = 'active'", (auction_id,))
            closed = conn.execute("SELECT * FROM auctions WHERE id = ?", (auction_id,)).fetchone()
            conn.commit()
            result = self._row_to_dict(closed)
            if result is not None:
                result["images"] = json.loads(result.pop("images_json"))
            return result
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
