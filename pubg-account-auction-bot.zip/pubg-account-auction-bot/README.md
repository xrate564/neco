# PUBG Account Auction Bot (bepul versiya)

Python 3.11+, aiogram 3, SQLite va APScheduler asosidagi Telegram auksion boti. E’lon avval admin tasdig‘iga yuboriladi; admin tasdiqlagandan keyingina kanalga chiqadi va auksion vaqti boshlanadi.

## Imkoniyatlar

- Foydalanuvchi tavsif, 3–5 ta skrinshot, boshlang‘ich narx va muddat yuboradi.
- Admin e’lonni tasdiqlaydi yoki rad etadi.
- Kanalda skrinshotlar albomi, tavsif, narx va **Taklif berish** tugmasi chiqadi.
- Takliflar botning shaxsiy chatida qabul qilinadi. Birinchi taklif boshlang‘ich narxdan kam bo‘lmaydi; keyingilari joriy narxdan `MIN_BID_INCREMENT` miqdorida yuqori bo‘lishi kerak.
- Muddat tugaganda auksion avtomatik yopiladi. G‘olib va sotuvchiga bot shaxsiy xabar yuboradi.
- Bot qayta ishga tushganda faol auksionlar uchun taymerlar SQLite’dan qayta tiklanadi.

## O‘rnatish

```bash
cd pubg-account-auction-bot
python3.11 -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env            # Windows'da faylni qo‘lda nusxalang
```

`.env` faylida quyidagilarni kiriting:

- `BOT_TOKEN` — BotFather tokeni.
- `CHANNEL_ID` — kanalning raqamli ID'si (`-100...`) yoki `@username`.
- `ADMIN_IDS` — tasdiqlash huquqiga ega adminlarning raqamli Telegram ID'lari.
- `MIN_BID_INCREMENT` — takliflar orasidagi minimal qadam, so‘mda.

So‘ng botni kanalga admin qilib qo‘shing. Botga kanalga post joylash huquqi kerak; taklifdan keyin kanal postini tahrirlash uchun xabarlarni tahrirlash huquqini ham bering. Har bir admin bot bilan avval shaxsiy chatni ochib `/start` yuborsin, aks holda Telegram botga adminning shaxsiy chatiga xabar jo‘natishga ruxsat bermaydi.

```bash
python bot.py
```

Bot polling rejimida ishlaydi; server yoki hostingda jarayonni doimiy ishlatib turing. SQLite fayli (`auction.db`) shu papkada yaratiladi.

## Foydalanish

1. Sotuvchi `/start` → **Akkaunt qo‘shish** ni tanlaydi.
2. Tavsif va 3–5 ta rasm yuboradi. Kamida 3 ta rasm kelgach **Rasmlar tayyor** tugmasi orqali davom etadi; 5 ta rasmga yetganda bot avtomatik davom etadi.
3. Boshlang‘ich narxni so‘mda yuboradi (masalan `250000`; raqamlar orasida bo‘shliq bilan yozish ham qabul qilinadi), so‘ng muddatni tanlaydi.
4. Admin botga kelgan albom va so‘rovdagi **Tasdiqlash** tugmasini bosadi. Auksion kanalda e’lon qilinadi.
5. Xaridor kanal postidagi **Taklif berish** tugmasini bosadi. Taklif summasini botning shaxsiy chatiga yuboradi.

Foydali buyruqlar: `/start`, `/add`, `/my_auctions`, `/help`, `/cancel`.

## Muhim eslatmalar

- Ushbu namuna to‘lov, escrow, akkaunt tekshiruvi yoki akkauntni xaridorga topshirishni amalga oshirmaydi. To‘lov va topshirish taraflar o‘rtasida kelishiladi.
- Tavsif yoki skrinshotlarda parol, SMS-kod, 2FA kodi yoki boshqa maxfiy ma’lumotlarni yubormang.
- PUBG/Tencent hamda Telegram qoidalariga muvofiqlikni o‘zingiz tekshiring. Bot akkaunt savdosining qonuniyligi yoki xavfsizligini kafolatlamaydi.
- Ishlab chiqarish muhitida zaxira nusxa, monitoring, spamga qarshi limitlar va moderatsiya qoidalarini qo‘shish tavsiya etiladi.
