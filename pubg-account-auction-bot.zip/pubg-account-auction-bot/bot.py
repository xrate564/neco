from __future__ import annotations

import asyncio
import logging
from datetime import timezone
from html import escape as html_escape
from zoneinfo import ZoneInfo

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.base import StorageKey
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import CallbackQuery, InputMediaPhoto, Message, ReplyKeyboardRemove
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger

from config import Settings, load_settings
from database import Database, parse_datetime, utc_now
from keyboards import (
    ADD_LABEL,
    HELP_LABEL,
    MY_AUCTIONS_LABEL,
    admin_review_keyboard,
    bid_keyboard,
    duration_keyboard,
    main_menu_keyboard,
    photos_keyboard,
)

router = Router()
TASHKENT = ZoneInfo("Asia/Tashkent")
MAX_DESCRIPTION_LENGTH = 1800
MAX_PRICE = 10**12
DURATIONS = {"1 soat": 1, "6 soat": 6, "12 soat": 12, "24 soat": 24, "3 kun": 72}


class AuctionForm(StatesGroup):
    description = State()
    photos = State()
    starting_price = State()
    duration = State()
    bid_amount = State()


def format_money(amount: int) -> str:
    return f"{amount:,}".replace(",", " ") + " so‘m"


def format_time(value: str | None) -> str:
    parsed = parse_datetime(value)
    if parsed is None:
        return "—"
    return parsed.astimezone(TASHKENT).strftime("%d.%m.%Y %H:%M (Toshkent)")


def parse_amount(raw: str) -> int | None:
    # Raqamlar orasidagi oddiy/NBSP bo‘shliqlarga ruxsat beramiz: 250000 yoki 250 000.
    normalized = raw.replace(" ", "").replace("\u00a0", "").strip()
    if not normalized.isdigit():
        return None
    try:
        amount = int(normalized)
    except ValueError:
        return None
    if amount < 1 or amount > MAX_PRICE:
        return None
    return amount


def user_name(user) -> str:
    return (user.full_name or "Foydalanuvchi").strip()


def user_tag(username: str | None, name: str) -> str:
    if username:
        return f"@{html_escape(username)}"
    return html_escape(name)


def minimum_next_bid(auction: dict, increment: int) -> int:
    if auction.get("current_bidder_id") is None:
        return int(auction["start_price"])
    return int(auction["current_price"]) + increment


def status_label(status: str) -> str:
    return {
        "pending": "Admin tasdig‘ida",
        "publishing": "Kanalga chiqarilmoqda",
        "publish_failed": "Kanalga chiqarilmadi — admin qayta urinishi mumkin",
        "active": "Faol",
        "closed": "Yakunlangan",
        "rejected": "Rad etilgan",
    }.get(status, status)


def channel_post_text(auction: dict) -> str:
    current = int(auction["current_price"])
    end_time = format_time(auction.get("ends_at"))
    description = html_escape(auction["description"])
    return (
        f"🎮 <b>PUBG akkaunt auksioni #{auction['id']}</b>\n\n"
        f"{description}\n\n"
        f"💵 <b>Boshlang‘ich narx:</b> {format_money(int(auction['start_price']))}\n"
        f"🔥 <b>Joriy eng yuqori taklif:</b> {format_money(current)}\n"
        f"📈 <b>Takliflar:</b> {int(auction['bid_count'])}\n"
        f"⏰ <b>Tugash vaqti:</b> {end_time}\n\n"
        "Taklif berish uchun quyidagi tugmani bosing."
    )


def admin_review_text(auction: dict) -> str:
    seller = user_tag(auction.get("seller_username"), auction["seller_name"])
    return (
        f"🆕 <b>Yangi auksion so‘rovi #{auction['id']}</b>\n\n"
        f"👤 <b>Sotuvchi:</b> {seller} (ID: <code>{auction['seller_id']}</code>)\n"
        f"📝 <b>Tavsif:</b>\n{html_escape(auction['description'])}\n\n"
        f"💵 <b>Boshlang‘ich narx:</b> {format_money(int(auction['start_price']))}\n"
        f"⏳ <b>Muddat:</b> {int(auction['duration_hours'])} soat\n"
        f"🖼 <b>Skrinshotlar:</b> {len(auction['images'])} ta\n\n"
        "Kanalga chiqarish uchun tasdiqlang."
    )


def closed_channel_text(auction: dict) -> str:
    text = channel_post_text(auction)
    if auction.get("current_bidder_id") is None:
        ending = "\n\n🏁 <b>Auksion yakunlandi — taklif kelib tushmadi.</b>"
    else:
        ending = (
            "\n\n🏁 <b>Auksion yakunlandi.</b>\n"
            f"🏆 <b>Yakuniy narx:</b> {format_money(int(auction['current_price']))}"
        )
    return text.rsplit("\n\nTaklif berish uchun quyidagi tugmani bosing.", 1)[0] + ending


async def notify_admins(bot: Bot, settings: Settings, auction: dict) -> int:
    delivered = 0
    media = [InputMediaPhoto(media=file_id) for file_id in auction["images"]]
    for admin_id in settings.admin_ids:
        try:
            await bot.send_media_group(chat_id=admin_id, media=media)
            await bot.send_message(
                chat_id=admin_id,
                text=admin_review_text(auction),
                reply_markup=admin_review_keyboard(int(auction["id"])),
            )
            delivered += 1
        except TelegramForbiddenError:
            logging.warning("Admin %s botni hali /start qilmagan yoki botni bloklagan.", admin_id)
        except TelegramAPIError:
            logging.exception("Admin %s ga auksion so‘rovini yuborib bo‘lmadi.", admin_id)
    return delivered


async def publish_auction(bot: Bot, db: Database, settings: Settings, auction_id: int) -> dict:
    auction = db.get_auction(auction_id)
    if auction is None:
        raise RuntimeError("Auksion bazadan topilmadi.")

    album_message_id = auction.get("channel_album_message_id")
    if album_message_id is None:
        media = [InputMediaPhoto(media=file_id) for file_id in auction["images"]]
        album_messages = await bot.send_media_group(chat_id=settings.channel_id, media=media)
        if not album_messages:
            raise RuntimeError("Kanalga rasm albomi yuborilmadi.")
        album_message_id = album_messages[0].message_id
        db.save_album_message_id(auction_id, album_message_id)
        auction = db.get_auction(auction_id)

    post_message_id = auction.get("channel_post_message_id")
    if post_message_id is None:
        post = await bot.send_message(
            chat_id=settings.channel_id,
            text=channel_post_text(auction),
            reply_markup=bid_keyboard(auction_id),
        )
        post_message_id = post.message_id
        db.save_post_message_id(auction_id, post_message_id)
    else:
        try:
            await bot.edit_message_text(
                chat_id=settings.channel_id,
                message_id=post_message_id,
                text=channel_post_text(auction),
                reply_markup=bid_keyboard(auction_id),
            )
        except TelegramBadRequest as exc:
            if "message is not modified" not in str(exc).lower():
                raise

    db.mark_active(auction_id)
    result = db.get_auction(auction_id)
    if result is None:
        raise RuntimeError("Auksion holatini yangilab bo‘lmadi.")
    return result


def schedule_close(scheduler: AsyncIOScheduler, bot: Bot, db: Database, settings: Settings, auction: dict) -> None:
    end_time = parse_datetime(auction.get("ends_at"))
    if end_time is None:
        logging.error("Auksion #%s tugash vaqti bazada yo‘q.", auction.get("id"))
        return
    auction_id = int(auction["id"])
    scheduler.add_job(
        close_auction_job,
        trigger=DateTrigger(run_date=end_time, timezone=timezone.utc),
        kwargs={"bot": bot, "db": db, "settings": settings, "auction_id": auction_id},
        id=f"auction-close-{auction_id}",
        replace_existing=True,
        misfire_grace_time=24 * 60 * 60,
    )


async def refresh_channel_post(bot: Bot, settings: Settings, auction: dict) -> None:
    message_id = auction.get("channel_post_message_id")
    if not message_id:
        return
    try:
        await bot.edit_message_text(
            chat_id=settings.channel_id,
            message_id=message_id,
            text=channel_post_text(auction),
            reply_markup=bid_keyboard(int(auction["id"])),
        )
    except TelegramBadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            logging.exception("Kanal posti yangilanmadi (auksion #%s).", auction["id"])
    except TelegramAPIError:
        logging.exception("Kanal posti yangilanmadi (auksion #%s).", auction["id"])


async def close_auction_job(bot: Bot, db: Database, settings: Settings, auction_id: int) -> None:
    auction = db.close_auction_if_due(auction_id)
    if auction is None:
        return

    message_id = auction.get("channel_post_message_id")
    if message_id:
        try:
            await bot.edit_message_text(
                chat_id=settings.channel_id,
                message_id=message_id,
                text=closed_channel_text(auction),
                reply_markup=None,
            )
        except TelegramAPIError:
            logging.exception("Yakunlangan auksion #%s kanal postini tahrirlab bo‘lmadi.", auction_id)

    seller_id = int(auction["seller_id"])
    bidder_id = auction.get("current_bidder_id")
    if bidder_id is None:
        seller_text = (
            f"🏁 Auksion #{auction_id} yakunlandi.\n"
            "Taklif kelib tushmagani uchun g‘olib aniqlanmadi."
        )
    else:
        winner_name = auction.get("current_bidder_name") or "Xaridor"
        seller_text = (
            f"🏁 Auksion #{auction_id} yakunlandi.\n"
            f"🏆 G‘olib: {html_escape(winner_name)} (Telegram ID: <code>{bidder_id}</code>)\n"
            f"💰 Yakuniy narx: {format_money(int(auction['current_price']))}\n\n"
            "To‘lov va akkauntni topshirishni o‘zaro kelishib oling."
        )
    try:
        await bot.send_message(chat_id=seller_id, text=seller_text)
    except TelegramAPIError:
        logging.warning("Auksion #%s sotuvchisiga yakuniy xabar yuborilmadi.", auction_id)

    if bidder_id is not None:
        seller_contact = user_tag(auction.get("seller_username"), auction["seller_name"])
        winner_text = (
            f"🎉 Siz PUBG auksioni #{auction_id} g‘olibi bo‘ldingiz!\n"
            f"💰 Yakuniy taklifingiz: {format_money(int(auction['current_price']))}\n"
            f"👤 Sotuvchi: {seller_contact} (Telegram ID: <code>{seller_id}</code>)\n\n"
            "To‘lov va akkauntni topshirishni sotuvchi bilan o‘zaro kelishing."
        )
        try:
            await bot.send_message(chat_id=int(bidder_id), text=winner_text)
        except TelegramAPIError:
            logging.warning("Auksion #%s g‘olibiga yakuniy xabar yuborilmadi.", auction_id)


@router.message(CommandStart())
async def start_command(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "Assalomu alaykum! 🎮\n\n"
        "Bu bot PUBG akkauntlarini auksionga qo‘yish va taklif yuborish uchun. "
        "E’lonlar admin tasdig‘idan keyin kanalga chiqadi.\n\n"
        "Parol, SMS-kod yoki 2FA ma’lumotlarini yubormang.",
        reply_markup=main_menu_keyboard(),
    )


@router.message(Command("help"))
@router.message(F.text == HELP_LABEL)
async def help_command(message: Message) -> None:
    await message.answer(
        "🎮 <b>Yordam</b>\n\n"
        "• Akkaunt qo‘shish: tavsif → 3–5 ta rasm → boshlang‘ich narx → muddat.\n"
        "• Admin tasdiqlagach, e’lon kanalga joylanadi.\n"
        "• Taklif berish: kanal postidagi tugmani bosing va summani botga shaxsiy xabarda yuboring.\n"
        "• Bekor qilish: /cancel\n"
        "• O‘z e’lonlaringiz: /my_auctions\n\n"
        "Bot to‘lovni qabul qilmaydi yoki escrow xizmatini ko‘rsatmaydi. Maxfiy ma’lumot yubormang.",
        reply_markup=main_menu_keyboard(),
    )


@router.message(Command("cancel"))
async def cancel_command(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Joriy amal bekor qilindi.", reply_markup=main_menu_keyboard())


@router.message(Command("add"))
@router.message(F.text == ADD_LABEL)
async def begin_auction(message: Message, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(AuctionForm.description)
    await message.answer(
        "Akkaunt tavsifini yuboring (rank, level, skinlar va boshqalar).\n"
        "Parol, SMS-kod yoki 2FA ma’lumotlarini yozmang. Tavsif 1800 belgigacha bo‘lsin.\n\n"
        "Bekor qilish uchun /cancel yuboring.",
        reply_markup=ReplyKeyboardRemove(),
    )


@router.message(Command("my_auctions"))
@router.message(F.text == MY_AUCTIONS_LABEL)
async def my_auctions(message: Message, db: Database) -> None:
    items = db.list_seller_auctions(message.from_user.id, limit=10)
    if not items:
        await message.answer("Sizda hali auksion yo‘q.", reply_markup=main_menu_keyboard())
        return
    lines = ["📋 <b>Oxirgi auksionlaringiz</b>"]
    for item in items:
        current = int(item["current_price"])
        line = f"\n<b>#{item['id']}</b> — {status_label(item['status'])}\n💰 {format_money(current)}"
        if item.get("ends_at"):
            line += f"\n⏰ {format_time(item['ends_at'])}"
        lines.append(line)
    await message.answer("\n".join(lines), reply_markup=main_menu_keyboard())


@router.message(AuctionForm.description)
async def collect_description(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip():
        await message.answer("Tavsifni matn ko‘rinishida yuboring.")
        return
    description = message.text.strip()
    if len(description) > MAX_DESCRIPTION_LENGTH:
        await message.answer(f"Tavsif {MAX_DESCRIPTION_LENGTH} belgidan oshmasin. Qisqartirib qayta yuboring.")
        return

    await state.update_data(description=description, photos=[])
    await state.set_state(AuctionForm.photos)
    await message.answer(
        "Endi akkauntning 3–5 ta skrinshotini alohida rasm qilib yuboring.\n"
        "Kamida 3 ta rasm yuborgach, <b>Rasmlar tayyor</b> tugmasini bosing; 5 ta rasmga yetganda davom etadi.",
        reply_markup=photos_keyboard(),
    )


@router.message(AuctionForm.photos)
async def collect_photos(message: Message, state: FSMContext) -> None:
    if not message.photo:
        await message.answer("Iltimos, skrinshotni rasm (photo) ko‘rinishida yuboring.")
        return

    data = await state.get_data()
    photos: list[str] = data.get("photos", [])
    if len(photos) >= 5:
        await message.answer("5 ta rasm allaqachon qabul qilindi.")
        return

    photos.append(message.photo[-1].file_id)
    await state.update_data(photos=photos)
    if len(photos) == 5:
        await state.set_state(AuctionForm.starting_price)
        await message.answer(
            "✅ 5 ta rasm qabul qilindi. Boshlang‘ich narxni so‘mda, faqat raqamlar bilan yuboring (masalan: 250000).",
            reply_markup=ReplyKeyboardRemove(),
        )
    else:
        await message.answer(
            f"✅ Rasm qabul qilindi: {len(photos)}/5. Kamida 3 ta kerak. Rasm yuborishda davom eting yoki yuqoridagi xabardagi tugmani bosing."
        )


@router.callback_query(F.data == "photos:done")
async def finish_photos(callback: CallbackQuery, state: FSMContext) -> None:
    if await state.get_state() != AuctionForm.photos.state:
        await callback.answer("Bu bosqich endi faol emas.", show_alert=True)
        return
    data = await state.get_data()
    photos = data.get("photos", [])
    if len(photos) < 3:
        await callback.answer("Davom etish uchun kamida 3 ta rasm yuboring.", show_alert=True)
        return
    await state.set_state(AuctionForm.starting_price)
    await callback.answer("Rasmlar qabul qilindi.")
    if isinstance(callback.message, Message):
        try:
            await callback.message.edit_reply_markup(reply_markup=None)
        except TelegramAPIError:
            pass
        await callback.message.answer(
            "Boshlang‘ich narxni so‘mda, faqat raqamlar bilan yuboring (masalan: 250000).",
            reply_markup=ReplyKeyboardRemove(),
        )


@router.message(AuctionForm.starting_price)
async def collect_starting_price(message: Message, state: FSMContext) -> None:
    amount = parse_amount(message.text or "")
    if amount is None:
        await message.answer("Narx musbat raqam bo‘lishi kerak. Masalan: 250000 yoki 250 000.")
        return
    await state.update_data(start_price=amount)
    await state.set_state(AuctionForm.duration)
    await message.answer("Auksion muddatini tanlang:", reply_markup=duration_keyboard())


@router.message(AuctionForm.duration)
async def collect_duration(
    message: Message,
    state: FSMContext,
    db: Database,
    settings: Settings,
    bot: Bot,
) -> None:
    duration = DURATIONS.get((message.text or "").strip())
    if duration is None:
        await message.answer("Tugmalardan birini tanlang: 1, 6, 12, 24 soat yoki 3 kun.")
        return

    data = await state.get_data()
    user = message.from_user
    auction_id = db.create_auction(
        seller_id=user.id,
        seller_name=user_name(user),
        seller_username=user.username,
        description=data["description"],
        images=data["photos"],
        start_price=int(data["start_price"]),
        duration_hours=duration,
    )
    await state.clear()
    await message.answer(
        f"✅ So‘rov #{auction_id} adminga yuborildi. Tasdiqlansa, kanalga joylanadi va auksion vaqti o‘shanda boshlanadi.",
        reply_markup=main_menu_keyboard(),
    )

    auction = db.get_auction(auction_id)
    if auction is None:
        logging.error("Yangi auksion #%s bazadan topilmadi.", auction_id)
        return
    delivered = await notify_admins(bot, settings, auction)
    if delivered == 0:
        await message.answer(
            "⚠️ Adminlarga xabar yetkazilmadi. Har bir admin botga /start yuborganini va ADMIN_IDS to‘g‘riligini tekshiring.",
            reply_markup=main_menu_keyboard(),
        )


@router.callback_query(F.data.startswith("admin:approve:"))
async def approve_auction(
    callback: CallbackQuery,
    bot: Bot,
    db: Database,
    settings: Settings,
    scheduler: AsyncIOScheduler,
) -> None:
    if callback.from_user.id not in settings.admin_ids:
        await callback.answer("Bu amal faqat adminlar uchun.", show_alert=True)
        return
    try:
        auction_id = int((callback.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        await callback.answer("Auksion ID noto‘g‘ri.", show_alert=True)
        return

    status, auction = db.claim_for_publish(auction_id)
    if status != "claimed" or auction is None:
        await callback.answer(f"Bu auksionni tasdiqlab bo‘lmaydi: {status_label(status)}.", show_alert=True)
        return

    await callback.answer("Auksion kanalga chiqarilmoqda…")
    try:
        published = await publish_auction(bot, db, settings, auction_id)
    except Exception:
        logging.exception("Auksion #%s ni kanalga joylashda xatolik.", auction_id)
        db.mark_publish_failed(auction_id)
        if isinstance(callback.message, Message):
            try:
                await callback.message.edit_text(
                    f"⚠️ <b>Auksion #{auction_id} kanalga chiqarilmadi.</b>\n"
                    "Kanal ID va bot huquqlarini tekshiring. Muammo bartaraf etilgach, qayta urinishingiz mumkin.",
                    reply_markup=admin_review_keyboard(auction_id),
                )
            except TelegramAPIError:
                pass
        return

    schedule_close(scheduler, bot, db, settings, published)
    if isinstance(callback.message, Message):
        try:
            await callback.message.edit_text(
                f"✅ <b>Auksion #{auction_id} tasdiqlandi va kanalga joylandi.</b>\n"
                f"Tugash vaqti: {format_time(published.get('ends_at'))}",
                reply_markup=None,
            )
        except TelegramAPIError:
            pass
    try:
        await bot.send_message(
            chat_id=int(published["seller_id"]),
            text=f"✅ Auksion #{auction_id} tasdiqlandi va kanalga joylandi.\n⏰ Tugash vaqti: {format_time(published.get('ends_at'))}",
        )
    except TelegramAPIError:
        logging.warning("Auksion #%s sotuvchisiga tasdiq xabari yuborilmadi.", auction_id)


@router.callback_query(F.data.startswith("admin:reject:"))
async def reject_auction(callback: CallbackQuery, db: Database, settings: Settings) -> None:
    if callback.from_user.id not in settings.admin_ids:
        await callback.answer("Bu amal faqat adminlar uchun.", show_alert=True)
        return
    try:
        auction_id = int((callback.data or "").rsplit(":", 1)[1])
    except (ValueError, IndexError):
        await callback.answer("Auksion ID noto‘g‘ri.", show_alert=True)
        return

    changed, auction = db.reject_auction(auction_id)
    if not changed or auction is None:
        await callback.answer("Auksion kutayotgan holatda emas.", show_alert=True)
        return
    await callback.answer("Auksion rad etildi.")
    if isinstance(callback.message, Message):
        try:
            await callback.message.edit_text(f"❌ <b>Auksion #{auction_id} rad etildi.</b>", reply_markup=None)
        except TelegramAPIError:
            pass
    try:
        await callback.bot.send_message(
            chat_id=int(auction["seller_id"]),
            text=f"❌ Afsuski, auksion #{auction_id} admin tomonidan rad etildi.",
        )
    except TelegramAPIError:
        logging.warning("Rad etilgan auksion #%s sotuvchisiga xabar yuborilmadi.", auction_id)


@router.callback_query(F.data.startswith("bid:"))
async def begin_bid(callback: CallbackQuery, state: FSMContext, bot: Bot, db: Database, settings: Settings) -> None:
    try:
        auction_id = int((callback.data or "").split(":", 1)[1])
    except (ValueError, IndexError):
        await callback.answer("Auksion ID noto‘g‘ri.", show_alert=True)
        return

    auction = db.get_auction(auction_id)
    if auction is None or auction["status"] != "active":
        await callback.answer("Bu auksion faol emas.", show_alert=True)
        return
    if int(auction["seller_id"]) == callback.from_user.id:
        await callback.answer("O‘z auksioningizga taklif bera olmaysiz.", show_alert=True)
        return
    ends_at = parse_datetime(auction.get("ends_at"))
    if ends_at is None or ends_at <= utc_now():
        await close_auction_job(bot, db, settings, auction_id)
        await callback.answer("Auksion muddati tugagan.", show_alert=True)
        return

    # Callback kanaldan kelgani uchun uning FSM chat_id'si kanal bo‘lishi mumkin.
    # Taklif esa foydalanuvchining shaxsiy chatida yoziladi, shu sabab FSM kalitini DM uchun tuzamiz.
    private_state = FSMContext(
        storage=state.storage,
        key=StorageKey(
            bot_id=bot.id,
            chat_id=callback.from_user.id,
            user_id=callback.from_user.id,
        ),
    )
    await private_state.clear()
    await private_state.update_data(auction_id=auction_id)
    await private_state.set_state(AuctionForm.bid_amount)
    minimum = minimum_next_bid(auction, settings.min_bid_increment)
    try:
        await bot.send_message(
            chat_id=callback.from_user.id,
            text=(
                f"💰 Auksion #{auction_id} uchun taklif summasini yuboring.\n"
                f"Minimal taklif: <b>{format_money(minimum)}</b>.\n"
                "Raqam yuboring; bekor qilish uchun /cancel."
            ),
        )
    except TelegramForbiddenError:
        await private_state.clear()
        await callback.answer("Avval botga shaxsiy chatda /start yuboring, keyin kanal tugmasini qayta bosing.", show_alert=True)
        return
    except TelegramAPIError:
        await private_state.clear()
        await callback.answer("Shaxsiy xabar yuborilmadi. Botga /start yuborib qayta urinib ko‘ring.", show_alert=True)
        return
    await callback.answer("Taklif summasini botning shaxsiy chatiga yuboring.")


@router.message(AuctionForm.bid_amount)
async def receive_bid(
    message: Message,
    state: FSMContext,
    db: Database,
    settings: Settings,
    bot: Bot,
) -> None:
    amount = parse_amount(message.text or "")
    if amount is None:
        await message.answer("Taklif musbat raqam bo‘lishi kerak. Masalan: 260000 yoki 260 000.")
        return
    data = await state.get_data()
    auction_id = int(data.get("auction_id", 0))
    result, auction, minimum, previous_bidder_id = db.place_bid(
        auction_id=auction_id,
        bidder_id=message.from_user.id,
        bidder_name=user_name(message.from_user),
        amount=amount,
        minimum_increment=settings.min_bid_increment,
    )

    if result == "too_low":
        await message.answer(
            f"❌ Taklif yetarli emas. Hozir minimal taklif: <b>{format_money(int(minimum or 0))}</b>. Qayta yuboring."
        )
        return
    if result == "expired":
        await state.clear()
        await close_auction_job(bot, db, settings, auction_id)
        await message.answer("Auksion muddati tugagan, taklif qabul qilinmadi.", reply_markup=main_menu_keyboard())
        return
    if result == "seller":
        await state.clear()
        await message.answer("O‘z auksioningizga taklif bera olmaysiz.", reply_markup=main_menu_keyboard())
        return
    if result != "ok" or auction is None:
        await state.clear()
        await message.answer("Bu auksion endi faol emas yoki topilmadi.", reply_markup=main_menu_keyboard())
        return

    await state.clear()
    await message.answer(
        f"✅ Taklifingiz qabul qilindi. Auksion #{auction_id} dagi joriy narx: <b>{format_money(int(auction['current_price']))}</b>.",
        reply_markup=main_menu_keyboard(),
    )
    await refresh_channel_post(bot, settings, auction)

    if previous_bidder_id is not None and int(previous_bidder_id) != message.from_user.id:
        try:
            await bot.send_message(
                chat_id=int(previous_bidder_id),
                text=(
                    f"🔔 Siz auksion #{auction_id} da oshirib o‘tildingiz.\n"
                    f"Joriy narx: {format_money(int(auction['current_price']))}."
                ),
            )
        except TelegramAPIError:
            logging.info("Oldingi taklif egasiga outbid xabari yuborilmadi.")


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    settings = load_settings()
    db = Database(settings.db_path)
    db.initialize()

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    scheduler = AsyncIOScheduler(timezone=timezone.utc)
    scheduler.start()

    dispatcher = Dispatcher(storage=MemoryStorage())
    dispatcher.include_router(router)
    dispatcher["settings"] = settings
    dispatcher["db"] = db
    dispatcher["scheduler"] = scheduler

    # Bot qayta ishga tushganda faol auksionlarning tugash vaqtlarini tiklaymiz.
    for active_auction in db.list_active_auctions():
        schedule_close(scheduler, bot, db, settings, active_auction)

    logging.info("PUBG Auction Bot ishga tushdi. Kanal: %s", settings.channel_id)
    try:
        await dispatcher.start_polling(bot, allowed_updates=dispatcher.resolve_used_update_types())
    finally:
        scheduler.shutdown(wait=False)
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Bot to‘xtatildi.")
