"""Environment-backed configuration for the auction bot."""
from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv


@dataclass(frozen=True)
class Settings:
    bot_token: str
    channel_id: int | str
    admin_ids: tuple[int, ...]
    db_path: str
    min_bid_increment: int


def load_settings() -> Settings:
    load_dotenv()

    token = os.getenv("BOT_TOKEN", "").strip()
    channel_raw = os.getenv("CHANNEL_ID", "").strip()
    admin_raw = os.getenv("ADMIN_IDS", "").strip()

    if not token:
        raise RuntimeError("BOT_TOKEN .env faylida ko‘rsatilmagan.")
    if not channel_raw:
        raise RuntimeError("CHANNEL_ID .env faylida ko‘rsatilmagan.")
    if not admin_raw:
        raise RuntimeError("ADMIN_IDS .env faylida ko‘rsatilmagan.")

    try:
        channel_id: int | str = int(channel_raw)
    except ValueError:
        # Masalan: @my_auction_channel
        channel_id = channel_raw

    try:
        admin_ids = tuple(
            dict.fromkeys(int(value.strip()) for value in admin_raw.split(",") if value.strip())
        )
    except ValueError as exc:
        raise RuntimeError("ADMIN_IDS vergul bilan ajratilgan Telegram raqamli ID'lari bo‘lishi kerak.") from exc
    if not admin_ids:
        raise RuntimeError("ADMIN_IDS ichida kamida bitta admin ID bo‘lishi kerak.")

    try:
        increment = int(os.getenv("MIN_BID_INCREMENT", "1000").strip())
    except ValueError as exc:
        raise RuntimeError("MIN_BID_INCREMENT butun son bo‘lishi kerak.") from exc
    if increment < 1:
        raise RuntimeError("MIN_BID_INCREMENT kamida 1 bo‘lishi kerak.")

    return Settings(
        bot_token=token,
        channel_id=channel_id,
        admin_ids=admin_ids,
        db_path=os.getenv("DB_PATH", "auction.db").strip() or "auction.db",
        min_bid_increment=increment,
    )
