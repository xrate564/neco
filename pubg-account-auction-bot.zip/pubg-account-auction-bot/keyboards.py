from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)

ADD_LABEL = "➕ Akkaunt qo‘shish"
MY_AUCTIONS_LABEL = "📋 Mening auksionlarim"
HELP_LABEL = "ℹ️ Yordam"


def main_menu_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=ADD_LABEL)],
            [KeyboardButton(text=MY_AUCTIONS_LABEL), KeyboardButton(text=HELP_LABEL)],
        ],
        resize_keyboard=True,
        input_field_placeholder="Kerakli bo‘limni tanlang",
    )


def photos_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="✅ Rasmlar tayyor", callback_data="photos:done")]]
    )


def duration_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="1 soat"), KeyboardButton(text="6 soat")],
            [KeyboardButton(text="12 soat"), KeyboardButton(text="24 soat")],
            [KeyboardButton(text="3 kun")],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def admin_review_keyboard(auction_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Tasdiqlash / qayta urinish", callback_data=f"admin:approve:{auction_id}"),
                InlineKeyboardButton(text="❌ Rad etish", callback_data=f"admin:reject:{auction_id}"),
            ]
        ]
    )


def bid_keyboard(auction_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="💰 Taklif berish", callback_data=f"bid:{auction_id}")]
        ]
    )
