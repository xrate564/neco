/**
 * player.js — birinchi shaxs: kamera, harakat, qo'l/qarmoq viewmodel,
 * otish/tortish animatsiyalari, o'zaro ta'sir (E) nurlanishi.
 */
import * as THREE from 'three';
import { CFG } from './core/balance.js';

const SKIN = 0xd9a274;

export class Player {
  constructor(world) {
    this.world = world;
    this.cam = world.camera;
    this.pos = world.spawnPoint().clone();
    this.vel = new THREE.Vector3();
    this.yaw = 0;               // suvga (−Z) qarab
    this.pitch = -0.05;
    this.hp = CFG.player.maxHP;
    this.stamina = CFG.player.stamina;
    this.sens = 1; this.invertY = false;
    this.keys = Object.create(null);
    this.locked = false;
    this.bob = 0;
    this.recoil = 0;
    this.sprinting = false;
    this.crouched = false;
    this.airborne = false;
    this.moving = false;
    this.speedNow = 0;
    this.weaponId = 'rod';
    this._lastDmg = -99;
    this._hpRegenCd = 0;
    this._stepCd = 0;
    this.interactTarget = null;
    this.fightMode = false;   // tension mini-o'yini paytida kamera burilmaydi

    this._buildRig();
    this._bindInput();

    this.ray = new THREE.Raycaster();
    this.ray.far = 3.6;
    this._center = new THREE.Vector2(0, 0);
  }

  /* ---------------- viewmodel: qo'llar + qarmoq + qurol ---------------- */
  _buildRig() {
    this.rig = new THREE.Group();
    this.cam.add(this.rig);
    this.world.scene.add(this.cam);
    this.rig.position.set(0, -0.24, -0.34);

    const skinMat = new THREE.MeshStandardMaterial({ color: SKIN, roughness: 0.75 });
    const sleeveMat = new THREE.MeshStandardMaterial({ color: 0x2f6b4f, roughness: 0.9 });

    // qo'l: bo'g'inlar local -Y bo'ylab; guruh X atrofida burilganda oldinga qarab turadi
    const arm = (side) => {
      const g = new THREE.Group();
      const sleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.055, 0.2, 8), sleeveMat);
      sleeve.position.y = -0.1;
      const fore = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.046, 0.2, 8), skinMat);
      fore.position.y = -0.3;
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), skinMat);
      hand.position.y = -0.44;
      g.add(sleeve, fore, hand);
      g.position.set(side * 0.15, -0.16, -0.12);
      g.rotation.x = 1.05;                 // oldinga cho'zilgan holat
      g.rotation.z = side * -0.12;
      return g;
    };
    this.armL = arm(-1);
    this.armR = arm(1);
    this.rig.add(this.armL, this.armR);

    // --- qarmoq: rig ga mahkam, qo'lda ushlangandek ---
    this.rod = new THREE.Group();
    const rodMat = new THREE.MeshStandardMaterial({ color: 0x2b2f36, roughness: 0.45, metalness: 0.35 });
    const seg = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.024, 1.4, 8), rodMat);
    seg.position.y = 0.7;
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.028, 0.22, 8), new THREE.MeshStandardMaterial({ color: 0x1b1b1b, roughness: 0.95 }));
    grip.position.y = 0.02;
    const reel = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.045, 12), new THREE.MeshStandardMaterial({ color: 0x9aa4ad, metalness: 0.85, roughness: 0.25 }));
    reel.rotation.z = Math.PI / 2; reel.position.set(0.045, 0.16, 0);
    this.rod.add(seg, grip, reel);
    this.rod.position.set(0.16, -0.34, -0.28);
    this.rod.rotation.set(-0.55, 0, -0.1);
    this.rig.add(this.rod);
    this.reelMesh = reel;
    this.rodTipLocal = new THREE.Vector3(0, 1.4, 0);

    // --- qurol viewmodellari ---
    const gunMat = new THREE.MeshStandardMaterial({ color: 0x24272c, roughness: 0.5, metalness: 0.6 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x6b4a2a, roughness: 0.85 });
    const mkGun = (len, thick, stock) => {
      const g = new THREE.Group();
      const barrel = new THREE.Mesh(new THREE.BoxGeometry(thick, thick, len), gunMat);
      barrel.position.set(0, 0, -len / 2);
      g.add(barrel);
      if (stock) {
        const st = new THREE.Mesh(new THREE.BoxGeometry(thick * 1.6, thick * 2.2, 0.26), woodMat);
        st.position.set(0, -0.02, 0.16); g.add(st);
      }
      const gripG = new THREE.Mesh(new THREE.BoxGeometry(thick * 1.1, 0.13, 0.07), gunMat);
      gripG.position.set(0, -0.075, 0.02); gripG.rotation.x = 0.25; g.add(gripG);
      return g;
    };
    this.guns = {
      pistol: mkGun(0.22, 0.05, false),
      rifle: mkGun(0.62, 0.045, true),
      auto: mkGun(0.5, 0.055, true),
      sniper: mkGun(0.85, 0.05, true),
    };
    for (const g of Object.values(this.guns)) {
      g.visible = false;
      g.position.set(0.16, -0.3, -0.3);
      this.rig.add(g);
    }
    const scope = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.16, 10), gunMat);
    scope.rotation.x = Math.PI / 2; scope.position.set(0, 0.06, -0.3);
    this.guns.sniper.add(scope);

    // pichoq
    this.knife = new THREE.Group();
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.045, 0.3), new THREE.MeshStandardMaterial({ color: 0xd6dde2, metalness: 0.9, roughness: 0.2 }));
    blade.position.z = -0.18;
    const kh = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.09, 0.09), new THREE.MeshStandardMaterial({ color: 0x3a2a1c, roughness: 0.9 }));
    this.knife.add(blade, kh);
    this.knife.position.set(0.16, -0.3, -0.3);
    this.knife.visible = false;
    this.rig.add(this.knife);

    // miltiq alangasi
    this.muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 5), new THREE.MeshBasicMaterial({ color: 0xffe9a0 }));
    this.muzzle.visible = false;
    this.muzzle.position.set(0.16, -0.28, -0.85);
    this.rig.add(this.muzzle);

    // --- chiziq + poplavok ---
    this.lineGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    this.line = new THREE.Line(this.lineGeo, new THREE.LineBasicMaterial({ color: 0xf2f7fa, transparent: true, opacity: 0.85 }));
    this.line.frustumCulled = false;
    this.line.visible = false;
    this.world.scene.add(this.line);

    this.bobber = new THREE.Group();
    const bTop = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), new THREE.MeshStandardMaterial({ color: 0xe8382f, roughness: 0.5 }));
    const bBot = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), new THREE.MeshStandardMaterial({ color: 0xf7f7f2, roughness: 0.5 }));
    bBot.scale.y = -0.8;
    this.bobber.add(bTop, bBot);
    this.bobber.visible = false;
    this.world.scene.add(this.bobber);

    this._animState = 'idle';
    this._animT = 0;
    this.castPower = 0;
    this._pumpAnim = 0;
  }

  /* ---------------- input ---------------- */
  _bindInput() {
    addEventListener('keydown', (e) => {
      this.keys[e.code] = true;
      if (e.code === 'ShiftLeft') this.sprinting = true;
      if (e.code === 'KeyC' || e.code === 'ControlLeft') this.crouched = !this.crouched;
    });
    addEventListener('keyup', (e) => {
      this.keys[e.code] = false;
      if (e.code === 'ShiftLeft') this.sprinting = false;
    });
    addEventListener('mousemove', (e) => {
      if (!this.locked) return;
      // JANG REJIMI: gorizontal harakat kamerani EMAS, faqat zonani boshqaradi
      if (this.fightMode) {
        this.mouseNX = Math.max(0, Math.min(1, (this.mouseNX ?? 0.5) + (e.movementX / innerWidth) * 1.7 * this.sens));
        const sv = 0.0011 * this.sens;
        this.pitch -= e.movementY * sv * (this.invertY ? -1 : 1);
        this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch));
        return;
      }
      const s = 0.0022 * this.sens;
      this.yaw -= e.movementX * s;
      this.pitch -= e.movementY * s * (this.invertY ? -1 : 1);
      this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch));
      this.mouseNX = e.clientX / innerWidth;   // 0..1 — mini-o'yin zonasi uchun
    });
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === this.world.canvas;
    });
  }
  lock() { this.world.canvas.requestPointerLock?.(); }
  unlock() { document.exitPointerLock?.(); }
  get mouseNormX() { return this.mouseNX ?? 0.5; }

  /* ---------------- qurol almashtirish ---------------- */
  setWeapon(id) {
    this.weaponId = id;
    const isRod = id === 'rod';
    this.rod.visible = isRod;
    this.knife.visible = id === 'knife';
    for (const [k, g] of Object.entries(this.guns)) g.visible = (k === id);
  }

  /* ---------------- animatsiyalar ---------------- */
  playCast(power) { this._animState = 'cast'; this._animT = 0; this.castPower = power; }
  playReel(on) {
    this._reeling = on;
    if (on) this._pumpAnim = 1;
    if (this.app?.fishing) this.app.fishing._reelingHeld = on;
  }
  playMelee(kind) { this._animState = kind; this._animT = 0; }
  kickRecoil(amount) { this.recoil = Math.min(0.35, this.recoil + amount); this.pitch += amount * 0.35; }
  flashMuzzle() {
    this.muzzle.visible = true;
    this._muzzleT = 0.05;
  }

  /* ---------------- harakat ---------------- */
  update(dt) {
    const P = CFG.player;
    const f = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const r = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const move = new THREE.Vector3();
    if (this.keys.KeyW) move.add(f);
    if (this.keys.KeyS) move.sub(f);
    if (this.keys.KeyD) move.add(r);
    if (this.keys.KeyA) move.sub(r);
    const wantMove = move.lengthSq() > 0.001;
    if (wantMove) move.normalize();

    const canSprint = this.sprinting && this.stamina > 1 && this.keys.KeyW;
    let sp = canSprint ? P.sprintSpeed : P.walkSpeed;
    if (this.crouched) sp = P.crouchSpeed;
    if (canSprint) this.stamina = Math.max(0, this.stamina - P.sprintDrain * dt);
    else this.stamina = Math.min(P.stamina, this.stamina + P.staminaRegen * dt);

    this.speedNow += (wantMove ? sp : 0 - this.speedNow) * Math.min(1, dt * 10);
    this.moving = this.speedNow > 0.4;
    this.pos.addScaledVector(move, this.speedNow * dt);

    // --- kolliziya: suvga tushmaslik (pirs ustida yurish mumkin) ---
    const onDock = Math.abs(this.pos.x) < 1.7 && this.pos.z > -16.4 && this.pos.z < 2;
    const h = this.world.terrainH(this.pos.x, this.pos.z);
    let groundY = Math.max(h, this.world.waterY(this.pos.x, this.pos.z));
    if (onDock) groundY = Math.max(groundY, 0.58);
    if (h < -0.2 && !onDock) {           // suv — orqaga qaytarish
      this.pos.x -= move.x * this.speedNow * dt * 1.6;
      this.pos.z -= move.z * this.speedNow * dt * 1.6;
      groundY = Math.max(this.world.terrainH(this.pos.x, this.pos.z), 0.58);
    }
    // orol chegarasi
    const R = this.world.island.size * 0.58;
    const d = Math.hypot(this.pos.x, this.pos.z);
    if (d > R) { this.pos.x *= R / d; this.pos.z *= R / d; }

    const eye = P.eyeHeight - (this.crouched ? 0.55 : 0);
    this.pos.y += (groundY + eye - this.pos.y) * Math.min(1, dt * 12);

    // --- kamera tebranishi (bob) + recoil ---
    if (this.moving) this.bob += dt * (canSprint ? 12 : 8);
    this.recoil = Math.max(0, this.recoil - dt * 1.4);
    const bobY = Math.sin(this.bob) * 0.035 * (this.moving ? 1 : 0);
    const bobX = Math.cos(this.bob * 0.5) * 0.028 * (this.moving ? 1 : 0);
    this.cam.position.set(this.pos.x + bobX * 0.3, this.pos.y + bobY, this.pos.z);
    this.cam.rotation.set(0, 0, 0);
    this.cam.rotateY(this.yaw);
    this.cam.rotateX(this.pitch + this.recoil * 0.35);
    this.cam.rotateZ(bobX * 0.06);

    // qadam tovushi
    if (this.moving) {
      this._stepCd -= dt * (canSprint ? 2.2 : 1.5);
      if (this._stepCd <= 0) { this._stepCd = 0.5; this.onStep?.(); }
    }

    // HP regen
    this._hpRegenCd -= dt;
    if (this._hpRegenCd <= 0 && this.hp < P.maxHP) this.hp = Math.min(P.maxHP, this.hp + P.hpRegen * dt);

    this._updateRigAnim(dt);
    this._updateInteract();
  }

  _updateRigAnim(dt) {
    this._animT += dt;
    const t = performance.now() * 0.001;
    const sway = Math.sin(t * 1.1) * 0.02;
    const walkSway = this.moving ? Math.sin(this.bob) * 0.04 : 0;
    this.rig.position.set(0, -0.24 + walkSway * 0.5, -0.34 + (this._reeling ? Math.sin(t * 9) * 0.012 : 0));

    const rodIdle = -0.55;
    if (this._animState === 'cast') {
      const k = this._animT;
      if (k < 0.55) this.rod.rotation.x = rodIdle - 1.1 * (k / 0.55) * this.castPower;
      else if (k < 0.72) this.rod.rotation.x = rodIdle - 1.1 * this.castPower + 1.9 * ((k - 0.55) / 0.17);
      else if (k < 1.25) this.rod.rotation.x = rodIdle + 0.8 * (1 - (k - 0.72) / 0.53);
      else this._animState = 'idle';
      this.armR.rotation.x = 1.05 - this.rod.rotation.x * 0.12;
    } else if (this._animState === 'punch') {
      const k = Math.min(1, this._animT / 0.28);
      this.armR.rotation.x = 1.05 - 0.9 * Math.sin(k * Math.PI);
      this.armR.rotation.z = 0.12;
      if (k >= 1) this._animState = 'idle';
    } else if (this._animState === 'slash') {
      const k = Math.min(1, this._animT / 0.34);
      this.armR.rotation.x = 1.05 - 1.1 * Math.sin(k * Math.PI);
      this.armR.rotation.z = 0.12 - 1.2 * Math.sin(k * Math.PI);
      if (k >= 1) this._animState = 'idle';
    } else if (this._reeling) {
      this._pumpAnim = Math.max(0, this._pumpAnim - dt * 3.4);
      const pump = this._pumpAnim;
      this.rod.rotation.x = rodIdle + 0.25 - pump * 0.45 + Math.sin(t * 9) * 0.05;
      this.armR.rotation.x = 1.05 - pump * 0.3;
      this.reelMesh.rotation.x += dt * 16;
    } else {
      this.rod.rotation.x = rodIdle + sway;
      this.armR.rotation.x = 1.05 + sway * 0.6;
      this.armL.rotation.x = 1.05 - sway * 0.6;
    }
    // qurol/pichoq tebranishi
    for (const g of Object.values(this.guns)) if (g.visible) { g.rotation.x = sway; g.position.z = -0.3 + (this.recoil * 0.5); }
    if (this.knife.visible) this.knife.rotation.x = sway;

    if (this._muzzleT > 0) { this._muzzleT -= dt; if (this._muzzleT <= 0) this.muzzle.visible = false; }
  }

  /** Qarmoq uchining dunyo koordinatasi. */
  rodTipWorld(out = new THREE.Vector3()) {
    return this.rod.localToWorld(out.copy(this.rodTipLocal));
  }

  setLine(target) {
    if (!target) { this.line.visible = false; this.bobber.visible = false; return; }
    const a = this.rodTipWorld();
    const pts = this.lineGeo.attributes.position;
    pts.setXYZ(0, a.x, a.y, a.z);
    pts.setXYZ(1, target.x, target.y, target.z);
    pts.needsUpdate = true;
    this.line.visible = true;
    this.bobber.visible = true;
    this.bobber.position.copy(target);
  }

  /* ---------------- o'zaro ta'sir ---------------- */
  _updateInteract() {
    this.interactTarget = null;
    this.fightMode = false;   // tension mini-o'yini paytida kamera burilmaydi
    let best = 3.4;
    for (const it of this.world.interactables) {
      const d = it.pos.distanceTo(this.cam.position);
      if (d < best) { best = d; this.interactTarget = it; }
    }
  }

  /* ---------------- zarar ---------------- */
  damage(amount, from) {
    this.hp -= amount;
    this._hpRegenCd = 5;
    this.recoil = Math.min(0.4, this.recoil + 0.12);
    this.onDamage?.(amount, from);
    if (this.hp <= 0) { this.hp = 0; this.onDeath?.(from); }
  }
  heal(n) { this.hp = Math.min(CFG.player.maxHP, this.hp + n); }
  respawn() { this.hp = CFG.player.maxHP; this.pos.copy(this.world.spawnPoint()); }

  get forward() { return new THREE.Vector3(0, 0, -1).applyQuaternion(this.cam.quaternion); }
  get right() { return new THREE.Vector3(1, 0, 0).applyQuaternion(this.cam.quaternion); }
}
