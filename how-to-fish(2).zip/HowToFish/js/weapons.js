/**
 * weapons.js — jang runtime: hitscan, melee, trick-shot, baliq/boss/o'yinchiga zarar.
 */
import * as THREE from 'three';
import { CFG } from './core/balance.js';
import { WEAPONS, weaponStats, shotDamage, trickShot, armedFishShot } from './core/weapons.js';

export class Combat {
  constructor(world, state, audio, player = null) {
    this.world = world; this.state = state; this.audio = audio; this.player = player;
    this.ray = new THREE.Raycaster();
    this.ray.far = 400;
    this.cooldown = 0;
    this.reloading = 0;
    this.clips = {};          // weaponId → joriy o'q
    this.triggerHeld = false;
    this.scoped = false;
    this.hitscanTargets = [];
    this.onKill = null;       // (info) => {}
    this.onShot = null;
  }

  setTargets(list) { this.hitscanTargets = list; }

  get currentId() { return (this.player ?? this.world.player).weaponId; }
  get stats() { return weaponStats(this.currentId, this.state.levels[this.currentId] ?? 1); }

  clipOf(id) {
    const w = WEAPONS[id];
    if (!w.mag) return Infinity;
    if (this.clips[id] == null) this.clips[id] = weaponStats(id, this.state.levels[id] ?? 1).mag;
    return this.clips[id];
  }

  canFire() {
    const id = this.currentId, w = WEAPONS[id];
    if (this.cooldown > 0 || this.reloading > 0) return false;
    if (id === 'rod') return false;
    if (w.mag && this.clipOf(id) <= 0) return false;
    if (w.ammo && (this.state.ammo[w.ammo] ?? 0) <= 0 && this.clipOf(id) <= 0) return false;
    return true;
  }

  reload() {
    const id = this.currentId, w = WEAPONS[id];
    if (!w.mag) return false;
    const mag = weaponStats(id, this.state.levels[id] ?? 1).mag;
    const have = this.state.ammo[w.ammo] ?? 0;
    if (this.clips[id] >= mag || have <= 0) return false;
    this.reloading = 1.5;
    return true;
  }

  update(dt, player) {
    this.cooldown = Math.max(0, this.cooldown - dt);
    if (this.reloading > 0) {
      this.reloading -= dt;
      if (this.reloading <= 0) {
        const id = this.currentId, w = WEAPONS[id];
        const mag = weaponStats(id, this.state.levels[id] ?? 1).mag;
        const need = mag - (this.clips[id] ?? 0);
        const take = Math.min(need, this.state.ammo[w.ammo] ?? 0);
        this.clips[id] = (this.clips[id] ?? 0) + take;
        this.state.ammo[w.ammo] -= take;
      }
    }
    const w = WEAPONS[this.currentId];
    const auto = this.currentId === 'auto';
    if (this.triggerHeld && (auto || this._semi) && this.canFire()) this.fire(player);
  }

  /** Sichqoncha bosildi. */
  press(player) { this.triggerHeld = true; this._semi = true; if (this.canFire()) this.fire(player); }
  release() { this.triggerHeld = false; this._semi = true; }

  fire(player) {
    const id = this.currentId, w = WEAPONS[id], s = this.stats;
    if (w.kind === 'melee') return this.melee(player, id);
    if (w.mag) this.clips[id] -= 1;
    this.cooldown = 60 / s.rpm;
    this._semi = false;

    // tarqoqlik (spread)
    const dir = player.forward.clone();
    const spread = s.spread * (this.scoped && w.scoped ? 0.25 : 1) * (player.moving ? 2.2 : 1) * (player.airborne ? 3 : 1);
    dir.x += (Math.random() - 0.5) * spread;
    dir.y += (Math.random() - 0.5) * spread;
    dir.z += (Math.random() - 0.5) * spread;
    dir.normalize();

    this.ray.set(player.cam.position.clone(), dir);
    this.ray.far = s.range;
    const hits = this.ray.intersectObjects(this.hitscanTargets, true);
    let hit = null;
    if (hits.length) hit = this._resolveHit(hits[0], player, id, s);

    player.kickRecoil(s.recoil * (this.scoped ? 0.6 : 1));
    player.flashMuzzle();
    this.audio?.play('shot_' + (w.ammo ?? 'pistol'), { volume: 0.85 });
    this.onShot?.({ id, hit });
    return hit;
  }

  _resolveHit(threeHit, player, id, s) {
    let obj = threeHit.object;
    while (obj && !obj.userData?.combat) obj = obj.parent;
    const dist = threeHit.distance;
    const weakspot = (threeHit.object.name === 'weakspot') || (threeHit.point.y > obj?.position.y + 0.2);
    const dmg = shotDamage({
      weaponId: id, level: this.state.levels[id] ?? 1, distance: dist,
      headshot: weakspot, scoped: this.scoped,
    });
    const trick = trickShot({
      weaponId: id, distance: dist, headshot: weakspot, scoped: this.scoped,
      playerAirborne: player.airborne, fishAirborne: obj?.userData?.airborne ?? false,
      moving: player.moving, weakspot,
    });
    const target = obj?.userData?.combat;
    if (target === 'boss') this.onKill?.({ type: 'damage', dmg, trick, target: 'boss', distance: dist, weapon: id });
    else if (target === 'fish') this.onKill?.({ type: 'damage', dmg, trick, target: 'fish', ref: obj, distance: dist, weapon: id });
    else if (target === 'player') this.onKill?.({ type: 'damage', dmg, trick, target: 'player', ref: obj.userData.netId, distance: dist, weapon: id });
    return { dist, dmg, trick, target };
  }

  melee(player, id) {
    const w = WEAPONS[id], s = this.stats;
    this.cooldown = 60 / s.rpm;
    player.playMelee(id === 'knife' ? 'slash' : 'punch');
    this.audio?.play(id === 'knife' ? 'slash' : 'punch', { volume: 0.7 });
    const origin = player.cam.position;
    const fwd = player.forward;
    const results = [];
    for (const obj of this.hitscanTargets) {
      const to = obj.position.clone().sub(origin);
      const d = to.length();
      if (d > w.range) continue;
      if (to.normalize().dot(fwd) < 0.55) continue;
      const trick = trickShot({ weaponId: id, distance: d, headshot: false, scoped: false, playerAirborne: player.airborne, moving: player.moving, weakspot: false, fishAirborne: obj.userData?.airborne });
      results.push({ target: obj.userData?.combat, ref: obj, dmg: s.dmg, trick, distance: d });
    }
    for (const r of results) this.onKill?.({ ...r, weapon: id, type: 'damage' });
    return results;
  }

  /** Qurollangan baliqning javob o't ochishi. */
  armedFishRetaliate(species, distance, player) {
    const shot = armedFishShot(species, distance);
    if (!shot) return null;
    if (shot.hit) {
      player.damage(shot.dmg, 'fish');
      this.audio?.playAt('shot_' + (shot.weapon ?? 'pistol'), player.cam.position.clone().add(player.forward.clone().multiplyScalar(distance)), player.cam.position, player.right, 120);
    }
    return shot;
  }
}
