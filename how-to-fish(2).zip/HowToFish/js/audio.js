/**
 * audio.js — Web Audio: protsedural WAV fayllar + loop kanallari + 3D pozitsion ovoz.
 * Yandex Games / WebGL da AudioContext foydalanuvchi harakatidan keyin ochilishi kerak.
 */
const FILES = [
  'water_loop', 'birds_loop', 'reeds_loop', 'rain_loop', 'wind_loop', 'thunder',
  'shot_pistol', 'shot_rifle', 'shot_auto', 'shot_sniper', 'splash', 'reel_click',
  'bite_bell', 'ui_click', 'coins', 'slash', 'punch', 'step', 'line_snap', 'fish_flop', 'boss_roar',
];

export class AudioSys {
  constructor(base = './assets/audio/') {
    this.base = base;
    this.ctx = null; this.buffers = {}; this.master = null;
    this.volumes = { master: 0.8, sfx: 0.9, music: 0.35 };
    this.loops = {}; this.muted = false;
    this.listener = null;
    this.ready = false;
  }

  async init() {
    if (this.ready) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { console.warn('WebAudio yo\'q'); return; }
    this.ctx = new AC();
    // brauzer siyosati: kontekst harakatdan keyingina ishlaydi
    if (this.ctx.state === 'suspended') {
      const unlock = () => { this.ctx.resume(); removeEventListener('pointerdown', unlock); removeEventListener('keydown', unlock); };
      addEventListener('pointerdown', unlock, { once: true });
      addEventListener('keydown', unlock, { once: true });
    }
    this.master = this.ctx.createGain();
    this.master.gain.value = this.volumes.master;
    this.master.connect(this.ctx.destination);

    // sfx va ambience alohida shinalar
    this.sfxBus = this.ctx.createGain(); this.sfxBus.gain.value = this.volumes.sfx; this.sfxBus.connect(this.master);
    this.ambBus = this.ctx.createGain(); this.ambBus.gain.value = this.volumes.music; this.ambBus.connect(this.master);

    const load = async (name) => {
      try {
        const res = await fetch(this.base + name + '.wav');
        if (!res.ok) throw new Error(res.status);
        const buf = await res.arrayBuffer();
        this.buffers[name] = await this.ctx.decodeAudioData(buf);
      } catch (e) { console.warn(`audio ${name} yuklanmadi:`, e.message); }
    };
    await Promise.all(FILES.map(load));
    this._startLoops();
    this.ready = true;
  }

  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }

  setVolume(kind, v) {
    this.volumes[kind] = v;
    if (!this.ctx) return;
    if (kind === 'master') this.master.gain.value = v;
    if (kind === 'sfx') this.sfxBus.gain.value = v;
    if (kind === 'music') this.ambBus.gain.value = v;
  }

  _startLoops() {
    const mk = (name, rate = 1) => {
      const b = this.buffers[name];
      if (!b) return null;
      const src = this.ctx.createBufferSource();
      src.buffer = b; src.loop = true; src.playbackRate.value = rate;
      const g = this.ctx.createGain(); g.gain.value = 0;
      src.connect(g); g.connect(this.ambBus);
      src.start();
      return { src, gain: g, target: 0 };
    };
    this.loops.water = mk('water_loop');
    this.loops.birds = mk('birds_loop');
    this.loops.reeds = mk('reeds_loop');
    this.loops.rain = mk('rain_loop');
    this.loops.wind = mk('wind_loop');
  }

  /** Ambient kanallarni ob-havo/vaqtga moslash. weights = {water:0.5, birds:0.2, ...} */
  setAmbient(weights, fade = 1.5) {
    if (!this.ready) return;
    const now = this.ctx.currentTime;
    for (const [k, node] of Object.entries(this.loops)) {
      if (!node) continue;
      const v = (weights[k] ?? 0) * (this.muted ? 0 : 1);
      node.gain.gain.cancelScheduledValues(now);
      node.gain.gain.setTargetAtTime(v, now, fade / 3);
    }
  }

  /** Bir martalik ovoz. opts: {volume, rate, pan(-1..1), delay} */
  play(name, opts = {}) {
    if (!this.ready || this.muted) return null;
    const b = this.buffers[name];
    if (!b) return null;
    const src = this.ctx.createBufferSource();
    src.buffer = b;
    src.playbackRate.value = (opts.rate ?? 1) * (0.94 + Math.random() * 0.12);
    const g = this.ctx.createGain();
    g.gain.value = opts.volume ?? 1;
    let node = src;
    if (opts.pan != null && this.ctx.createStereoPanner) {
      const p = this.ctx.createStereoPanner(); p.pan.value = Math.max(-1, Math.min(1, opts.pan));
      node.connect(p); node = p;
    }
    node.connect(g); g.connect(opts.bus === 'ambient' ? this.ambBus : this.sfxBus);
    src.start(this.ctx.currentTime + (opts.delay ?? 0));
    return src;
  }

  /** Masofa + pan bilan (oddiy 3D). */
  playAt(name, pos, camPos, camRight, maxDist = 60) {
    const dx = pos.x - camPos.x, dz = pos.z - camPos.z;
    const d = Math.hypot(dx, dz);
    if (d > maxDist) return null;
    const vol = Math.max(0, 1 - d / maxDist) ** 1.6;
    const right = camRight ? (dx * camRight.x + dz * camRight.z) / (d || 1) : 0;
    return this.play(name, { volume: vol, pan: Math.max(-1, Math.min(1, right)) });
  }

  /** Chaqmoq: avval chaqnash, keyin masofaga qarab momaqaldiroq. */
  thunder(distance = 300) {
    const delay = Math.min(6, distance / 340);
    this.play('thunder', { volume: Math.max(0.15, 1 - distance / 1600), delay, rate: 0.9 + Math.random() * 0.2 });
  }

  /** Oddiy sintezlangan "o'tish" tovushi (fayl kerak emas). */
  beep(freq = 660, dur = 0.08, type = 'sine', vol = 0.2) {
    if (!this.ctx || this.muted) return;
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(vol, this.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + dur);
    o.connect(g); g.connect(this.sfxBus);
    o.start(); o.stop(this.ctx.currentTime + dur + 0.02);
  }
}

export const audio = new AudioSys();
