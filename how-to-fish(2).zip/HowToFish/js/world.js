/**
 * world.js — Three.js dunyosi: relef, suv (shader), osmon, quyosh/oy, ob-havo,
 * qamish/daraxt/tog', prop'lar, baliq mesh'lari, boss.
 */
import * as THREE from 'three';
import { ISLANDS } from './core/fishData.js';
import { WEATHERS } from './core/time.js';
import { SIZE_ORDER } from './core/balance.js';

/* ---------------- deterministik noise ---------------- */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hash2(x, y, s) {
  let h = x * 374761393 + y * 668265263 + s * 1442695040888963407 % 100000;
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
const vnoise = (x, y, s) => {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s);
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
};
const fbm = (x, y, s) => vnoise(x, y, s) * 0.55 + vnoise(x * 2.1, y * 2.1, s + 7) * 0.28 + vnoise(x * 4.3, y * 4.3, s + 13) * 0.17;

/* ---------------- suv shaderi ---------------- */
const WATER_VS = `
uniform float uTime; uniform float uWave;
varying vec3 vWorld; varying vec3 vN; varying vec2 vUv;
void main(){
  vec3 p = position;
  float w1 = sin(p.x*0.17 + uTime*1.25) * cos(p.y*0.13 + uTime*0.95);
  float w2 = sin((p.x+p.y)*0.09 - uTime*0.7);
  float w3 = sin(p.x*0.52 - uTime*2.1) * cos(p.y*0.44 + uTime*1.7);
  p.z += (w1*0.55 + w2*0.75 + w3*0.22) * uWave;
  float dx = (0.17*cos(p.x*0.17 + uTime*1.25)*cos(p.y*0.13 + uTime*0.95)*0.55
            + 0.09*cos((p.x+p.y)*0.09 - uTime*0.7)*0.75) * uWave;
  float dy = (-0.13*sin(p.x*0.17 + uTime*1.25)*sin(p.y*0.13 + uTime*0.95)*0.55
            + 0.09*cos((p.x+p.y)*0.09 - uTime*0.7)*0.75) * uWave;
  vN = normalize(vec3(-dx, -dy, 1.0));
  vec4 wp = modelMatrix * vec4(p,1.0);
  vWorld = wp.xyz; vUv = uv;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;

const WATER_FS = `
uniform vec3 uDeep; uniform vec3 uShallow; uniform vec3 uSunColor; uniform vec3 uSunDir;
uniform vec3 uCam; uniform float uTime; uniform float uVis; uniform float uFoam;
varying vec3 vWorld; varying vec3 vN; varying vec2 vUv;
float h(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
float nz(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
  return mix(mix(h(i),h(i+vec2(1,0)),f.x), mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x), f.y); }
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(uCam - vWorld);
  float fres = pow(1.0 - clamp(dot(N,V), 0.0, 1.0), 3.2);
  float depthFade = clamp(length(vWorld.xz - uCam.xz) / 220.0, 0.0, 1.0);
  vec3 col = mix(uShallow, uDeep, depthFade*0.85 + 0.15);
  // suv osti to'lqin chiziqlari
  float caustic = nz(vWorld.xz*0.35 + uTime*0.25) * nz(vWorld.xz*0.21 - uTime*0.17);
  col += caustic * 0.06 * (1.0 - depthFade);
  // quyosh aksi
  vec3 H = normalize(uSunDir + V);
  float spec = pow(max(dot(N,H), 0.0), 220.0) * 1.4;
  float glit = step(0.86, nz(vWorld.xz*2.2 + uTime*0.6)) * 0.35;
  col += uSunColor * (spec + glit*0.12) * (1.0 - depthFade*0.4);
  // ko'pik (qirg'oq yaqinida)
  float shore = smoothstep(0.0, 1.0, 1.0 - clamp(length(vWorld.xz)/1.0, 0.0, 1.0));
  col = mix(col, uSunColor*0.9 + vec3(0.25), fres * uVis * 0.55);
  col += vec3(0.7,0.78,0.8) * uFoam * shore * 0.0;
  gl_FragColor = vec4(col, 0.90);
}`;

/* ---------------- osmon shaderi ---------------- */
const SKY_VS = `varying vec3 vDir; void main(){ vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const SKY_FS = `
uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uSunDir; uniform vec3 uSunColor; uniform float uStars;
varying vec3 vDir;
float h(vec3 p){ return fract(sin(dot(p, vec3(12.9898,78.233,37.719)))*43758.5453); }
void main(){
  vec3 d = normalize(vDir);
  float y = clamp(d.y*1.05 + 0.06, 0.0, 1.0);
  vec3 col = mix(uHorizon, uTop, pow(y, 0.65));
  float sun = pow(max(dot(d, normalize(uSunDir)), 0.0), 900.0) * 3.2
            + pow(max(dot(d, normalize(uSunDir)), 0.0), 12.0) * 0.35;
  col += uSunColor * sun;
  if (uStars > 0.01 && d.y > 0.0) {
    vec3 g = floor(d * 260.0);
    float s = h(g);
    float star = step(0.9985, s) * (0.5 + 0.5*sin(s*900.0));
    col += vec3(star) * uStars * smoothstep(0.0, 0.25, d.y);
  }
  gl_FragColor = vec4(col, 1.0);
}`;

export class World {
  constructor(canvas) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.1, 1400);
    this.scene.fog = new THREE.FogExp2(0x9fb6c0, 0.004);

    this.island = ISLANDS[0];
    this.rnd = mulberry32(1);
    // instanced material shaderlariga uzatiladigan umumiy uniformlar
    this._timeUniform = { value: 0 };
    this._windUniform = { value: 0.3 };
    this.sunDir = new THREE.Vector3(0, 1, 0);
    this.clock = 0;
    this.fishes = [];
    this.props = [];
    this.interactables = [];
    this._groups = {};

    this._buildSky();
    this._buildLights();
    this._buildWater();
    this.buildIsland(0);

    addEventListener('resize', () => this.resize());
  }

  /* ---------- osmon / yorug'lik ---------- */
  _buildSky() {
    const geo = new THREE.SphereGeometry(900, 32, 20);
    this.skyMat = new THREE.ShaderMaterial({
      vertexShader: SKY_VS, fragmentShader: SKY_FS, side: THREE.BackSide, depthWrite: false,
      uniforms: {
        uTop: { value: new THREE.Color(0x2a6fd0) },
        uHorizon: { value: new THREE.Color(0xbfd8e6) },
        uSunDir: { value: new THREE.Vector3(0, 1, 0) },
        uSunColor: { value: new THREE.Color(0xfff1d0) },
        uStars: { value: 0 },
      },
    });
    this.sky = new THREE.Mesh(geo, this.skyMat);
    this.scene.add(this.sky);
  }

  _buildLights() {
    this.sun = new THREE.DirectionalLight(0xfff1d0, 2.2);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const c = this.sun.shadow.camera;
    c.left = -90; c.right = 90; c.top = 90; c.bottom = -90; c.near = 1; c.far = 420;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    this.hemi = new THREE.HemisphereLight(0xbfd8ff, 0x2b3a2a, 0.55);
    this.scene.add(this.hemi);
    this.flash = new THREE.DirectionalLight(0xeaf2ff, 0);
    this.scene.add(this.flash);
  }

  /* ---------- suv ---------- */
  _buildWater() {
    const geo = new THREE.PlaneGeometry(1200, 1200, 140, 140);
    geo.rotateX(-Math.PI / 2);
    this.waterMat = new THREE.ShaderMaterial({
      vertexShader: WATER_VS, fragmentShader: WATER_FS, transparent: true,
      uniforms: {
        uTime: { value: 0 }, uWave: { value: 0.38 },
        uDeep: { value: new THREE.Color(0x0a3a4a) },
        uShallow: { value: new THREE.Color(0x2f9fa8) },
        uSunColor: { value: new THREE.Color(0xfff1d0) },
        uSunDir: { value: new THREE.Vector3(0, 1, 0) },
        uCam: { value: new THREE.Vector3() },
        uVis: { value: 1 }, uFoam: { value: 1 },
      },
    });
    this.water = new THREE.Mesh(geo, this.waterMat);
    this.water.position.y = 0;
    this.scene.add(this.water);
  }

  /** Suv sirti balandligi (shader bilan mos). */
  waterY(x, z) {
    const w = this.waterMat.uniforms.uWave.value, t = this.clock;
    const w1 = Math.sin(x * 0.17 + t * 1.25) * Math.cos(-z * 0.13 + t * 0.95);
    const w2 = Math.sin((x - z) * 0.09 - t * 0.7);
    const w3 = Math.sin(x * 0.52 - t * 2.1) * Math.cos(-z * 0.44 + t * 1.7);
    return (w1 * 0.55 + w2 * 0.75 + w3 * 0.22) * w;
  }

  /* ---------- relef ---------- */
  /** Orol markazi (dok janubiy sohilga to'g'ri kelishi uchun siljitilgan). */
  get oz() { return this.island.size * 0.98; }
  terrainH(x, z) {
    const R = this.island.size * 0.42;
    const d = Math.hypot(x, z - this.oz);
    if (d > R * 1.6) return -14;
    const base = Math.max(0, 1 - (d / R) ** 2.1);
    const h = fbm(x * 0.012 + 11, z * 0.012 - 7, this.island.id + 3);
    let y = base * (7 + h * 26) - 3.4;
    if (this.island.climate === 'alpine') y = base * (14 + h * 46) - 4.2;
    if (this.island.climate === 'abyssal') y = base * (3 + h * 9) - 5.0;
    if (this.island.climate === 'humid') y = base * (4 + h * 14) - 3.0;
    return y;
  }
  isWater(x, z) { return this.terrainH(x, z) < 0.05; }
  /** O'yinchi tug'iladigan nuqta (pirs ustida). */
  spawnPoint() { return new THREE.Vector3(0, 0.7, -6); }

  /* ---------- orolni qurish ---------- */
  buildIsland(id) {
    this.island = ISLANDS[id] ?? ISLANDS[0];
    this.rnd = mulberry32(this.island.id * 977 + 13);
    for (const k of ['land', 'deco', 'props', 'mountains']) {
      if (this._groups[k]) { this.scene.remove(this._groups[k]); this._disposeGroup(this._groups[k]); }
      this._groups[k] = new THREE.Group();
      this.scene.add(this._groups[k]);
    }
    this.interactables = [];
    this._buildLand();
    this._buildMountains();
    this._buildDeco();
    this._buildProps();
    this._applyPalette();
    return this.island;
  }

  _disposeGroup(g) {
    g.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => m.dispose());
    });
  }

  _buildLand() {
    const N = 128, R = this.island.size * 0.62;
    const geo = new THREE.PlaneGeometry(R * 2, R * 2, N, N);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    const cSand = new THREE.Color(0xd9c48c), cGrass = new THREE.Color(0x4d7a35),
      cDirt = new THREE.Color(0x6b5a3c), cRock = new THREE.Color(0x7c8288),
      cSnow = new THREE.Color(0xeef4f8), cSwamp = new THREE.Color(0x3d5230);
    const tmp = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i);
      const y = this.terrainH(x, z);
      pos.setY(i, y);
      if (this.island.climate === 'cold' && y > 16) tmp.copy(cSnow);
      else if (this.island.climate === 'alpine' && y > 20) tmp.copy(y > 34 ? cSnow : cRock);
      else if (y < 0.9) tmp.copy(cSand);
      else if (y > 18) tmp.copy(cRock);
      else if (this.island.climate === 'humid') tmp.copy(cSwamp).lerp(cGrass, Math.min(1, y / 8));
      else if (this.island.climate === 'tropical') tmp.copy(cSand).lerp(cGrass, Math.min(1, (y - 0.9) / 6));
      else tmp.copy(cSand).lerp(cGrass, Math.min(1, (y - 0.6) / 4)).lerp(cDirt, Math.min(0.4, Math.max(0, (y - 10) / 30)));
      const n = (fbm(x * 0.2, z * 0.2, 5) - 0.5) * 0.12;
      colors[i * 3] = Math.max(0, Math.min(1, tmp.r + n));
      colors[i * 3 + 1] = Math.max(0, Math.min(1, tmp.g + n));
      colors[i * 3 + 2] = Math.max(0, Math.min(1, tmp.b + n));
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.96, metalness: 0.0 });
    this.land = new THREE.Mesh(geo, mat);
    this.land.receiveShadow = true;
    this._groups.land.add(this.land);
  }

  _buildMountains() {
    const g = this._groups.mountains;
    const n = this.island.climate === 'alpine' ? 16 : 9;
    const cz = this.oz;
    const mat = new THREE.MeshStandardMaterial({ color: 0x6d757d, roughness: 1, flatShading: true });
    const snowMat = new THREE.MeshStandardMaterial({ color: 0xf2f7fb, roughness: 0.85, flatShading: true });
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + this.rnd() * 0.4;
      const d = this.island.size * (1.15 + this.rnd() * 1.15);
      const h = 55 + this.rnd() * (this.island.climate === 'alpine' ? 220 : 120);
      const r = h * (0.5 + this.rnd() * 0.35);
      const m = new THREE.Mesh(new THREE.ConeGeometry(r, h, 7 + Math.floor(this.rnd() * 4), 1), mat);
      m.position.set(Math.cos(a) * d, h / 2 - 12, cz + Math.sin(a) * d);
      m.rotation.y = this.rnd() * 3;
      g.add(m);
      if (h > 90) {
        const cap = new THREE.Mesh(new THREE.ConeGeometry(r * 0.42, h * 0.28, 6), snowMat);
        cap.position.set(m.position.x, h - 12 - h * 0.14, m.position.z);
        cap.rotation.y = m.rotation.y;
        g.add(cap);
      }
    }
  }

  _buildDeco() {
    const g = this._groups.deco;
    const R = this.island.size * 0.42;
    const cz = this.oz;
    // --- qamishlar (instanced, shamolda tebranadi) ---
    const reedGeo = new THREE.ConeGeometry(0.05, 2.6, 4, 3);
    reedGeo.translate(0, 1.3, 0);
    const reedMat = new THREE.MeshStandardMaterial({ color: 0x6f8f3f, roughness: 1 });
    reedMat.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this._timeUniform;
      sh.uniforms.uWind = this._windUniform;
      sh.vertexShader = 'uniform float uTime; uniform float uWind;\n' + sh.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         float ph = transformed.x*0.7 + transformed.z*0.5;
         transformed.x += sin(uTime*1.6 + ph) * 0.18 * uWind * transformed.y;
         transformed.z += cos(uTime*1.25 + ph) * 0.14 * uWind * transformed.y;`);
    };
    const reedCount = this.island.climate === 'abyssal' ? 0 : 900;
    const reeds = new THREE.InstancedMesh(reedGeo, reedMat, reedCount);
    const m4 = new THREE.Matrix4();
    let placed = 0, guard = 0;
    while (placed < reedCount && guard++ < 20000) {
      const a = this.rnd() * Math.PI * 2, d = R * (0.72 + this.rnd() * 0.42);
      const x = Math.cos(a) * d, z = cz + Math.sin(a) * d;
      const y = this.terrainH(x, z);
      if (y > 1.4 || y < -1.6) continue;
      const s = 0.7 + this.rnd() * 0.9;
      m4.makeRotationY(this.rnd() * 6.28);
      m4.scale(new THREE.Vector3(s, s * (0.8 + this.rnd() * 0.7), s));
      m4.setPosition(x, y - 0.35, z);
      reeds.setMatrixAt(placed++, m4);
    }
    reeds.count = placed;
    reeds.instanceMatrix.needsUpdate = true;
    g.add(reeds);

    // --- daraxtlar ---
    const trunkGeo = new THREE.CylinderGeometry(0.16, 0.26, 2.4, 6);
    trunkGeo.translate(0, 1.2, 0);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5a4327, roughness: 1 });
    const leafColors = { temperate: 0x2f6b2a, cold: 0x1f4f33, tropical: 0x2f8f3a, humid: 0x35602a, alpine: 0x24523a, abyssal: 0x2b4a44 };
    const leafMat = new THREE.MeshStandardMaterial({ color: leafColors[this.island.climate] ?? 0x2f6b2a, roughness: 0.9, flatShading: true });
    const treeCount = this.island.climate === 'abyssal' ? 26 : 190;
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
    const conifer = this.island.climate === 'cold' || this.island.climate === 'alpine';
    const leafGeo = conifer ? new THREE.ConeGeometry(1.5, 4.2, 7) : new THREE.IcosahedronGeometry(1.6, 0);
    leafGeo.translate(0, conifer ? 3.9 : 3.2, 0);
    const leaves = new THREE.InstancedMesh(leafGeo, leafMat, treeCount);
    let t = 0; guard = 0;
    while (t < treeCount && guard++ < 30000) {
      const a = this.rnd() * Math.PI * 2, d = R * (0.25 + this.rnd() * 0.72);
      const x = Math.cos(a) * d, z = cz + Math.sin(a) * d;
      const y = this.terrainH(x, z);
      if (y < 1.6 || y > 26) continue;
      const s = 0.75 + this.rnd() * 0.85;
      m4.makeRotationY(this.rnd() * 6.28);
      m4.scale(new THREE.Vector3(s, s, s));
      m4.setPosition(x, y - 0.2, z);
      trunks.setMatrixAt(t, m4);
      leaves.setMatrixAt(t, m4);
      t++;
    }
    trunks.count = t; leaves.count = t;
    trunks.instanceMatrix.needsUpdate = true;
    leaves.instanceMatrix.needsUpdate = true;
    trunks.castShadow = leaves.castShadow = true;
    leaves.receiveShadow = true;
    g.add(trunks, leaves);

    // --- toshlar ---
    const rockGeo = new THREE.DodecahedronGeometry(0.9, 0);
    const rockMat = new THREE.MeshStandardMaterial({ color: 0x777d82, roughness: 1, flatShading: true });
    const rocks = new THREE.InstancedMesh(rockGeo, rockMat, 90);
    let rk = 0; guard = 0;
    while (rk < 90 && guard++ < 12000) {
      const a = this.rnd() * Math.PI * 2, d = R * (0.4 + this.rnd() * 0.8);
      const x = Math.cos(a) * d, z = cz + Math.sin(a) * d;
      const y = this.terrainH(x, z);
      if (y < 0.2) continue;
      const s = 0.4 + this.rnd() * 1.5;
      m4.makeRotationFromEuler(new THREE.Euler(this.rnd(), this.rnd() * 6, this.rnd()));
      m4.scale(new THREE.Vector3(s, s * 0.7, s));
      m4.setPosition(x, y + s * 0.2, z);
      rocks.setMatrixAt(rk++, m4);
    }
    rocks.count = rk;
    rocks.instanceMatrix.needsUpdate = true;
    rocks.castShadow = true;
    g.add(rocks);
  }

  _buildProps() {
    const g = this._groups.props;
    // --- pirс (dok) ---
    const dock = new THREE.Group();
    const plankMat = new THREE.MeshStandardMaterial({ color: 0x8a6b45, roughness: 0.9 });
    for (let i = 0; i < 12; i++) {
      const p = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.14, 1.1), plankMat);
      p.position.set(0, 0.5, -2 - i * 1.15);
      p.castShadow = p.receiveShadow = true;
      dock.add(p);
    }
    for (const sx of [-1.4, 1.4]) for (let i = 0; i < 5; i++) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 2.6, 6), plankMat);
      leg.position.set(sx, -0.8, -2.4 - i * 2.7);
      dock.add(leg);
    }
    dock.position.set(0, 0, 0);
    g.add(dock);
    this.dockEnd = new THREE.Vector3(0, 0.58, -15.2);

    const mk = (mesh, pos, label, action, extra = {}) => {
      mesh.position.copy(pos);
      mesh.castShadow = true;
      g.add(mesh);
      const it = { object: mesh, pos: pos.clone(), label, action, ...extra };
      this.interactables.push(it);
      return it;
    };

    // --- qishloq sohilga, dokning ortiga joylashadi ---
    const vy = (x, z) => this.terrainH(x, z) + 0.05;
    const stall = this._makeStall(0xd8b26a);
    mk(stall, new THREE.Vector3(7, vy(7, 10), 10), 'talkVendor', 'vendor:fishMarket', { vendor: 'fishMarket' });
    const bm = this._makeStall(0x50324a);
    mk(bm, new THREE.Vector3(-9, vy(-9, 11), 11), 'talkVendor', 'vendor:blackMarket', { vendor: 'blackMarket' });
    const casino = this._makeCasinoTent();
    mk(casino, new THREE.Vector3(-3, vy(-3, 18), 18), 'openCasino', 'casino');
    const charm = this._makeStall(0x2f7f8f);
    mk(charm, new THREE.Vector3(10, vy(10, 16), 16), 'openShop', 'shop:charm');
    mk(this._makeGrill(), new THREE.Vector3(3, vy(3, 7), 7), 'useGrill', 'grill');
    // --- orollararo qayiqlar (dok yonida, suvda) ---
    for (let i = 1; i < ISLANDS.length; i++) {
      const boat = this._makeBoat();
      const p = new THREE.Vector3(9 + (i % 3) * 3.4, 0.1, -14 - i * 4.2);
      mk(boat, p, 'travelTo', `travel:${i}`, { island: i });
    }
    // --- boss chaqirish joyi (suv ustidagi belgi) ---
    const marker = new THREE.Mesh(
      new THREE.TorusGeometry(3.4, 0.18, 8, 40),
      new THREE.MeshStandardMaterial({ color: 0xff4d6d, emissive: 0xff2244, emissiveIntensity: 1.4 }),
    );
    marker.rotation.x = Math.PI / 2;
    mk(marker, new THREE.Vector3(0, 0.15, -46), 'fightBoss', 'boss');
    this.bossMarker = marker;
  }

  _makeStall(color) {
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.9 });
    const base = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.1, 1.6), mat);
    base.position.y = 0.55; base.castShadow = true;
    const roof = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.16, 2.2), new THREE.MeshStandardMaterial({ color: 0xb0402f, roughness: 0.8 }));
    roof.position.y = 2.3; roof.castShadow = true;
    g.add(base, roof);
    for (const x of [-1.5, 1.5]) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 2.3, 6), mat);
      pole.position.set(x, 1.15, 0.9); g.add(pole);
    }
    return g;
  }

  _makeCasinoTent() {
    const g = new THREE.Group();
    const tent = new THREE.Mesh(new THREE.ConeGeometry(4.6, 3.4, 8), new THREE.MeshStandardMaterial({ color: 0x8e1f3a, roughness: 0.85 }));
    tent.position.y = 1.7; tent.castShadow = true;
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(4.4, 4.4, 0.3, 12), new THREE.MeshStandardMaterial({ color: 0x2b2b33, roughness: 0.9 }));
    floor.position.y = 0.15; floor.receiveShadow = true;
    const neon = new THREE.Mesh(new THREE.TorusGeometry(1.1, 0.09, 6, 24), new THREE.MeshStandardMaterial({ color: 0xffd24a, emissive: 0xffb000, emissiveIntensity: 2.2 }));
    neon.position.y = 3.5; neon.rotation.x = Math.PI / 2;
    const light = new THREE.PointLight(0xffb64a, 1.4, 22, 2); light.position.y = 2.4;
    g.add(tent, floor, neon, light);
    this.casinoNeon = neon;
    return g;
  }

  _makeGrill() {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.55, 0.9, 12), new THREE.MeshStandardMaterial({ color: 0x33383d, roughness: 0.7, metalness: 0.5 }));
    body.position.y = 0.75; body.castShadow = true;
    const coal = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 0.1, 12), new THREE.MeshStandardMaterial({ color: 0xff5a1e, emissive: 0xff3b00, emissiveIntensity: 1.6 }));
    coal.position.y = 1.2;
    const fire = new THREE.PointLight(0xff7a2a, 1.6, 12, 2); fire.position.y = 1.4;
    g.add(body, coal, fire);
    for (let i = 0; i < 3; i++) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.75, 5), body.material);
      leg.position.set(Math.cos(i * 2.1) * 0.45, 0.35, Math.sin(i * 2.1) * 0.45);
      g.add(leg);
    }
    this.grillFire = fire;
    this.grillCoal = coal;
    return g;
  }

  _makeBoat() {
    const g = new THREE.Group();
    const hull = new THREE.Mesh(new THREE.CapsuleGeometry(0.7, 2.4, 4, 8), new THREE.MeshStandardMaterial({ color: 0x7a5230, roughness: 0.9 }));
    hull.rotation.z = Math.PI / 2; hull.rotation.y = Math.PI / 2; hull.position.y = 0.35;
    hull.scale.set(1, 1, 0.6);
    hull.castShadow = true;
    g.add(hull);
    return g;
  }

  /* ---------- rang palitrasi (iqlimga qarab suv/osmon) ---------- */
  _applyPalette() {
    const palettes = {
      temperate: { deep: 0x0a3a4a, shallow: 0x2f9fa8, horizon: 0xbfd8e6, top: 0x2a6fd0 },
      cold:      { deep: 0x0c2f42, shallow: 0x3b7f92, horizon: 0xcfe0ea, top: 0x4a7fb5 },
      tropical:  { deep: 0x04444f, shallow: 0x2fd0c0, horizon: 0xd6f0f2, top: 0x1f9fd8 },
      humid:     { deep: 0x1b3320, shallow: 0x4a6b3c, horizon: 0xb9c9b2, top: 0x5d7f6a },
      alpine:    { deep: 0x0b2c3f, shallow: 0x3a86a8, horizon: 0xd8e6f0, top: 0x3568b0 },
      abyssal:   { deep: 0x02121f, shallow: 0x0d3a52, horizon: 0x6f88a0, top: 0x11223c },
    };
    this.palette = palettes[this.island.climate] ?? palettes.temperate;
    const u = this.waterMat.uniforms;
    u.uDeep.value.setHex(this.palette.deep);
    u.uShallow.value.setHex(this.palette.shallow);
  }

  /* ---------- baliq mesh'lari ---------- */
  makeFishMesh(sp, tier, colorOverride) {
    const sizeIdx = SIZE_ORDER.indexOf(tier);
    const len = 0.45 * (0.7 + sizeIdx * 0.5) * (sp.id === 'megalodon' ? 3.4 : 1);
    const color = colorOverride ?? this._speciesColor(sp);
    const g = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.45, metalness: 0.25, flatShading: false });
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.5, 14, 10), bodyMat);
    body.scale.set(2.2, 0.85, 0.62);
    body.castShadow = true;
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.7, 4), bodyMat);
    tail.rotation.z = Math.PI / 2; tail.position.x = -1.35; tail.scale.set(1, 1, 0.25);
    const fin = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.5, 3), bodyMat);
    fin.position.set(0.1, 0.42, 0); fin.rotation.x = 0;
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x101010, roughness: 0.2 });
    const e1 = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 6), eyeMat); e1.position.set(0.85, 0.1, 0.24);
    const e2 = e1.clone(); e2.position.z = -0.24;
    g.add(body, tail, fin, e1, e2);
    g.scale.setScalar(len);
    g.userData = { tail, body, speciesId: sp.id, tier, len, phase: Math.random() * 6.28 };
    if (sp.armed) {
      const gun = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.16, 0.12), new THREE.MeshStandardMaterial({ color: 0x22262b, metalness: 0.7, roughness: 0.4 }));
      gun.position.set(0.5, -0.28, 0.28);
      g.add(gun);
      g.userData.armed = true;
    }
    return g;
  }

  _speciesColor(sp) {
    const table = {
      Common: 0x9aa7b0, Uncommon: 0x6fbf73, Rare: 0x4ab8ff, Epic: 0xc07bff, Legendary: 0xffb02e, Mythic: 0xff4fd8,
    };
    let h = 0;
    for (const ch of sp.id) h = (h * 31 + ch.charCodeAt(0)) % 360;
    const base = new THREE.Color().setHSL(h / 360, 0.35, 0.45);
    const rar = new THREE.Color(table[sp.rarity] ?? 0xffffff);
    return base.lerp(rar, 0.45).getHex();
  }

  /* ---------- suvdagi hayot (ambient baliqlar) ---------- */
  spawnAmbientFish(list, count = 14) {
    this.clearAmbientFish();
    this.ambient = [];
    for (let i = 0; i < count; i++) {
      const sp = list[Math.floor(Math.random() * list.length)];
      const tier = SIZE_ORDER[Math.floor(Math.random() * 3)];
      const m = this.makeFishMesh(sp, tier);
      const x = (Math.random() - 0.5) * 90;
      const z = -(6 + Math.random() * 44);
      m.position.set(x, -0.6 - Math.random() * 1.4, z);
      const ang = Math.random() * 6.28;
      m.userData.dir = new THREE.Vector3(Math.cos(ang + 1.6), 0, Math.sin(ang + 1.6));
      m.userData.speed = 0.6 + Math.random() * 1.4;
      this.scene.add(m);
      this.ambient.push(m);
    }
  }
  clearAmbientFish() {
    for (const f of this.ambient ?? []) { this.scene.remove(f); this._disposeGroup(f); }
    this.ambient = [];
  }
  updateAmbientFish(dt) {
    for (const f of this.ambient ?? []) {
      const u = f.userData;
      u.phase += dt * 6;
      f.position.addScaledVector(u.dir, u.speed * dt);
      f.rotation.y = Math.atan2(u.dir.x, u.dir.z) - Math.PI / 2;
      if (u.tail) u.tail.rotation.y = Math.sin(u.phase) * 0.5;
      if (f.position.length() > 70) { u.dir.multiplyScalar(-1); }
      f.position.y = -0.6 - Math.abs(Math.sin(u.phase * 0.3)) * 1.2;
    }
  }

  /* ---------- boss ---------- */
  spawnBoss(def) {
    this.despawnBoss();
    const sp = { id: def.id, rarity: def.rarity, armed: def.armed };
    const m = this.makeFishMesh(sp, 'Mythic', def.color);
    const scale = 3 + def.hp / 4000;
    m.scale.multiplyScalar(scale);
    m.position.set(0, -1.2, -46);
    this.scene.add(m);
    this.boss = { mesh: m, def, dir: new THREE.Vector3(1, 0, 0), phase: 0 };
    return this.boss;
  }
  despawnBoss() { if (this.boss) { this.scene.remove(this.boss.mesh); this._disposeGroup(this.boss.mesh); this.boss = null; } }

  /* ---------- effektlar ---------- */
  spawnProjectile(from, to, color = 0xffdd66, speed = 60) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 5), new THREE.MeshBasicMaterial({ color }));
    m.position.copy(from);
    this.scene.add(m);
    const vel = to.clone().sub(from).normalize().multiplyScalar(speed);
    this.projectiles = this.projectiles ?? [];
    this.projectiles.push({ mesh: m, vel, life: 3 });
  }
  updateProjectiles(dt) {
    if (!this.projectiles) return;
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.mesh.position.addScaledVector(p.vel, dt);
      p.life -= dt;
      if (p.life <= 0) { this.scene.remove(p.mesh); p.mesh.geometry.dispose(); this.projectiles.splice(i, 1); }
    }
  }

  splashAt(pos, scale = 1) {
    const g = new THREE.Mesh(
      new THREE.RingGeometry(0.2, 0.4, 24),
      new THREE.MeshBasicMaterial({ color: 0xdff6ff, transparent: true, opacity: 0.85, side: THREE.DoubleSide }),
    );
    g.rotation.x = -Math.PI / 2;
    g.position.copy(pos); g.position.y = this.waterY(pos.x, pos.z) + 0.02;
    this.scene.add(g);
    this.rings = this.rings ?? [];
    this.rings.push({ mesh: g, t: 0, scale });
  }
  updateRings(dt) {
    if (!this.rings) return;
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i]; r.t += dt;
      const s = 1 + r.t * 4 * r.scale;
      r.mesh.scale.setScalar(s);
      r.mesh.material.opacity = Math.max(0, 0.85 - r.t * 1.1);
      if (r.t > 0.9) { this.scene.remove(r.mesh); r.mesh.geometry.dispose(); this.rings.splice(i, 1); }
    }
  }

  /* ---------- ob-havo zarralari ---------- */
  ensurePrecip(type) {
    if (this.precipType === type) return;
    if (this.precip) { this.scene.remove(this.precip); this.precip.geometry.dispose(); this.precip.material.dispose(); this.precip = null; }
    this.precipType = type;
    if (type !== 'rain' && type !== 'snow') return;
    const n = type === 'rain' ? 2600 : 1600;
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 90;
      pos[i * 3 + 1] = Math.random() * 40;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      color: type === 'rain' ? 0xaad4e8 : 0xffffff,
      size: type === 'rain' ? 0.16 : 0.24, transparent: true, opacity: type === 'rain' ? 0.55 : 0.85, depthWrite: false,
    });
    this.precip = new THREE.Points(geo, mat);
    this.scene.add(this.precip);
  }
  updatePrecip(dt, wind) {
    if (!this.precip) return;
    const arr = this.precip.geometry.attributes.position.array;
    const speed = this.precipType === 'rain' ? 34 : 3.4;
    for (let i = 0; i < arr.length; i += 3) {
      arr[i + 1] -= speed * dt;
      arr[i] += wind * 4 * dt * (this.precipType === 'rain' ? 1 : 2.4);
      arr[i + 2] += Math.sin(this.clock * 0.7 + i) * 0.4 * dt;
      if (arr[i + 1] < -2) { arr[i + 1] = 38; arr[i] = (Math.random() - 0.5) * 90; arr[i + 2] = (Math.random() - 0.5) * 90; }
    }
    this.precip.geometry.attributes.position.needsUpdate = true;
    this.precip.position.copy(this.camera.position);
    this.precip.position.y = 0;
  }

  /* ---------- har kadr ---------- */
  update(dt, { time, weather, camPos }) {
    this.clock += dt;
    const u = this.waterMat.uniforms;
    u.uTime.value = this.clock;
    u.uWave.value += ((weather?.data.wave ?? 0.3) - u.uWave.value) * Math.min(1, dt * 0.8);
    u.uVis.value += ((weather?.data.visibility ?? 1) - u.uVis.value) * Math.min(1, dt);
    u.uCam.value.copy(camPos ?? this.camera.position);
    u.uSunDir.value.copy(this.sunDir ?? new THREE.Vector3(0, 1, 0));
    u.uSunColor.value.copy(this.sun.color);

    // kun/tun
    const el = time.sunElevation;
    const dayK = Math.max(0, Math.min(1, (el + 0.12) / 0.5));
    const az = time.sunAzimuth;
    this.sunDir = new THREE.Vector3(Math.cos(az) * 0.7, Math.max(0.06, el), Math.sin(az) * 0.7).normalize();
    this.sun.position.copy(this.sunDir).multiplyScalar(180).add(this.camera.position);
    this.sun.target.position.copy(this.camera.position);
    const sunCol = new THREE.Color().setHSL(0.09 + 0.03 * dayK, 0.75, 0.55 + 0.25 * dayK);
    this.sun.color.copy(sunCol);
    this.sun.intensity = 0.15 + 2.4 * dayK;
    this.hemi.intensity = 0.12 + 0.5 * dayK;
    this.skyMat.uniforms.uSunDir.value.copy(this.sunDir);
    this.skyMat.uniforms.uSunColor.value.copy(sunCol);
    this.skyMat.uniforms.uStars.value = Math.max(0, 1 - dayK * 2.4) * (weather?.current === 'clear' ? 1 : 0.15);
    const p = this.palette;
    const top = new THREE.Color(p.top).multiplyScalar(0.18 + 0.82 * dayK);
    const hor = new THREE.Color(p.horizon).multiplyScalar(0.25 + 0.75 * dayK);
    if (el < 0.12 && el > -0.16) hor.lerp(new THREE.Color(0xff8a4a), 0.5);  // tong/shom
    this.skyMat.uniforms.uTop.value.copy(top);
    this.skyMat.uniforms.uHorizon.value.copy(hor);
    this.sky.position.copy(this.camera.position);

    // tuman / ob-havo
    const fogD = (weather?.data.fog ?? 0) * 0.03 + 0.0022 + (1 - (weather?.data.visibility ?? 1)) * 0.012;
    this.scene.fog.density += (fogD - this.scene.fog.density) * Math.min(1, dt);
    this.scene.fog.color.copy(hor);

    // chaqmoq
    const lf = weather?.lightning ?? 0;
    this.flash.intensity = lf * 4.5;
    if (lf > 0.5) {
      this.flash.position.copy(this.camera.position).add(new THREE.Vector3((Math.random() - 0.5) * 60, 90, (Math.random() - 0.5) * 60));
      this.flash.target.position.copy(this.camera.position);
    }

    this.ensurePrecip(weather?.current === 'rain' || weather?.current === 'thunder' ? 'rain'
      : weather?.current === 'snow' ? 'snow'
        : weather?.current === 'storm' ? 'rain' : 'none');
    this.updatePrecip(dt, weather?.data.wind ?? 0.2);

    this._timeUniform.value = this.clock;
    this._windUniform.value = weather?.data.wind ?? 0.3;
    if (this.casinoNeon) this.casinoNeon.rotation.z += dt * 1.2;
    if (this.grillFire) this.grillFire.intensity = 1.2 + Math.sin(this.clock * 9) * 0.35;
    if (this.bossMarker) { this.bossMarker.rotation.z += dt * 0.6; this.bossMarker.position.y = 0.2 + Math.sin(this.clock * 1.6) * 0.16; }

    this.updateAmbientFish(dt);
    this.updateProjectiles(dt);
    this.updateRings(dt);
  }

  resize() {
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(innerWidth, innerHeight);
  }
  render() { this.renderer.render(this.scene, this.camera); }
}

export { mulberry32 as worldRng, fbm, vnoise };
