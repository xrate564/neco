/**
 * ui.js — HUD, ekranlar (do'kon/kazino/inventar/sozlamalar/kodeks/orollar), toast.
 */
import { CFG, SIZE_ORDER, RARITY_ORDER, WEAPON_IDS } from './core/balance.js';
import { SPECIES, ISLANDS, BAITS, CHARMS, fishPrice } from './core/fishData.js';
import { WEAPONS, weaponStats, upgradeCost } from './core/weapons.js';
import { shopCatalog, charmCatalog, purchase, upgradeWeapon, sellFish, VENDORS, canUnlockIsland, unlockIsland, restockVendors } from './core/shop.js';
import { spinRoulette, resolveRoulette, spinSlots, Blackjack, PokerGame, SLOT_SYMBOLS, colorOf } from './core/casino.js';
import { applyI18n, t, setLang, LANGS } from './i18n.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };

export class UI {
  constructor(app) {
    this.app = app;
    this.openScreen = null;
    this.bets = [];
    this.bet = 50;
    this.casinoTab = 'roulette';
    this.shopTab = 'weapon';
    this._toastCd = 0;
    this.rouletteSpinning = false;
    this.net = { won: 0, lost: 0 };
    this._bind();
  }

  /* ============ umumiy ============ */
  refreshLang() {
    // til tanlovini i18n moduliga sinxronlash (aks holda tarjima eski tilda qoladi)
    setLang(this.app.state.settings.lang || 'uz');
    applyI18n(document);
    $('#controls-help').innerHTML = t('controls');
    $$('.lang-switch button').forEach((b) => b.classList.toggle('on', b.dataset.lang === this.app.state.settings.lang));
    if (this.openScreen) this.renderScreen(this.openScreen);
  }

  show(id) {
    $$('#screens .screen').forEach((s) => s.classList.add('hidden'));
    this.openScreen = id;
    if (id) {
      const s = $('#' + id);
      s?.classList.remove('hidden');
      this.renderScreen(id);
      this.app.player.unlock();
    }
  }
  hide() { this.openScreen = null; $$('#screens .screen').forEach((s) => s.classList.add('hidden')); }
  get blocked() { return !!this.openScreen && this.openScreen !== 'menu'; }

  toast(text, kind = '') {
    const box = $('#toasts');
    const n = el('div', 'toast ' + kind, text);
    box.appendChild(n);
    setTimeout(() => { n.style.opacity = '0'; n.style.transition = '.4s'; setTimeout(() => n.remove(), 400); }, 3600);
    while (box.children.length > 5) box.firstChild.remove();
  }

  killfeed(text) {
    const box = $('#killfeed');
    const n = el('div', 'kf', text);
    box.appendChild(n);
    setTimeout(() => n.remove(), 5000);
  }

  showPrompt(it) {
    const p = $('#prompt');
    if (!it) { p.classList.add('hidden'); return; }
    p.classList.remove('hidden');
    $('#prompt-text').textContent = t(it.label) + (it.action.startsWith('travel:') ? ` ${ISLANDS[it.island]?.name ?? ''}` : '');
  }

  showCastPower(on) { $('#cast-power').classList.toggle('hidden', !on); }
  setCastPower(p) { $('#cast-power-bar').style.setProperty('--p', Math.round(p * 100) + '%'); }
  showStrike(on) {
    const c = $('#crosshair');
    if (on) { c.style.transform = 'translate(-50%,-50%) scale(2.1)'; c.style.filter = 'hue-rotate(120deg) brightness(1.6)'; }
    else { c.style.transform = ''; c.style.filter = ''; }
  }

  showFight(f, on) {
    $('#fish-fight').classList.toggle('hidden', !on);
    if (!on) return;
    const sp = f.species;
    $('#ff-name').textContent = sp.name;
    $('#ff-name').className = 'rarity-' + sp.rarity;
    $('#ff-rarity').textContent = this.app.rarityLabel(sp.rarity);
    $('#ff-rarity').className = 'chip rarity-' + sp.rarity;
    $('#ff-tier').textContent = t(`size.${f.tier}`);
    $('#ff-weight').textContent = `${f.weight} kg`;
    $('#ff-hint').textContent = t('tipFight');
  }

  updateFight(f) {
    const zone = $('#ff-zone'), fish = $('#ff-fish');
    zone.style.left = (f.zonePos * 100) + '%';
    zone.style.width = (f.zoneWidth * 100) + '%';
    zone.classList.toggle('hot', f.tension > 0.8);
    fish.style.left = (f.fishPos * 100) + '%';
    $('#ff-tension').style.width = (f.tension * 100) + '%';
    $('#ff-progress').style.width = (Math.max(0, f.progress) * 100) + '%';
    $('#ff-line').style.width = (Math.max(0, f.lineHP) * 100) + '%';
  }

  showBoss(name, hp, maxHP, phase) {
    const b = $('#boss-bar');
    if (!name) { b.classList.add('hidden'); return; }
    b.classList.remove('hidden');
    $('#boss-name').textContent = `${t('boss')} — ${name}`;
    $('#boss-hp').style.width = (hp / maxHP * 100) + '%';
    $('#boss-phase').textContent = `${Math.ceil(hp)} / ${maxHP} · ⚡ ${phase}/3`;
  }

  /* ============ HUD ============ */
  updateHUD() {
    const s = this.app.state, app = this.app;
    $('#hud-money').textContent = CFG.money.symbol + Math.round(s.money);
    $('#hud-island').textContent = ISLANDS[s.island]?.name ?? '—';
    $('#hud-time').textContent = app.time.clock + ' · ' + t('phases.' + app.time.phase);
    $('#hud-weather').textContent = (app.weather.data.icon ?? '') + ' ' + t('weather.' + app.weather.current);
    $('#hud-luck').textContent = s.luck.value;
    $('#hud-luck-bar').style.width = s.luck.value + '%';
    $('#hud-hp').style.width = (s.hp / s.maxHP * 100) + '%';
    $('#hud-stam').style.width = (this.app.player.stamina / CFG.player.stamina * 100) + '%';
    $('#hud-cooler').textContent = `${s.cooler.count}/${s.cooler.cap}`;
    const w = this.app.player.weaponId;
    const lv = s.levels[w] ?? 1;
    const clip = this.app.combat.clipOf(w);
    const ammo = WEAPONS[w].ammo ? `${clip === Infinity ? '∞' : clip}/${s.ammo[WEAPONS[w].ammo] ?? 0}` : '';
    $('#hud-weapon').textContent = `${WEAPONS[w].name} · Lv${lv} ${ammo}`;

    // kompas
    const yaw = ((-this.app.player.yaw * 180 / Math.PI) % 360 + 360) % 360;
    const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    let strip = '';
    for (let d = -180; d <= 180; d += 15) {
      const a = ((yaw + d) % 360 + 360) % 360;
      const label = a % 45 === 0 ? dirs[Math.round(a / 45) % 8] : (a % 15 === 0 ? '|' : '');
      strip += `<span style="display:inline-block;width:16px;text-align:center">${label}</span>`;
    }
    $('#compass-strip').innerHTML = strip;
    $('#compass-strip').style.left = '0px';

    // kooperativ
    const list = $('#coop-list');
    const players = this.app.net ? this.app.net.list() : [];
    list.innerHTML = `<li><span>${this.app.playerName} (you)</span><span>${Math.round(s.hp)} HP</span></li>` +
      players.map((p) => `<li><span>${p.name ?? p.id}</span><span>${Math.round(p.hp ?? 0)} HP</span></li>`).join('');
  }

  /* ============ ekranlar ============ */
  _bind() {
    $('#btn-play').onclick = () => this.app.startGame();
    $('#btn-coop').onclick = () => this.show('coopPanel');
    $('#btn-islands').onclick = () => this.show('islands');
    $('#btn-settings').onclick = () => this.show('settings');
    $('#btn-codex').onclick = () => this.show('codex');
    $('#btn-resume').onclick = () => this.app.resume();
    $('#btn-save').onclick = () => this.app.saveGame(true);
    $('#btn-quit').onclick = () => this.app.toMenu();
    $$('.lang-switch button').forEach((b) => {
      b.onclick = () => { this.app.state.settings.lang = b.dataset.lang; setLang(b.dataset.lang); this.refreshLang(); this.app.audio.play('ui_click'); };
    });
    $$('#screens .x').forEach((b) => { b.onclick = () => this.app.resume(); });
    addEventListener('keydown', (e) => {
      if (this.app.mode !== 'play') return;
      const map = { Tab: 'inv', KeyB: 'shop', KeyQ: 'casino' };
      if (map[e.code]) { e.preventDefault(); this.openScreen === map[e.code] ? this.app.resume() : this.show(map[e.code]); }
      if (e.code === 'Escape' && this.openScreen) this.app.resume();
    });
  }

  renderScreen(id) {
    if (id === 'shop') this.renderShop();
    else if (id === 'casino') this.renderCasino();
    else if (id === 'inv') this.renderInventory();
    else if (id === 'settings') this.renderSettings();
    else if (id === 'codex') this.renderCodex();
    else if (id === 'islands') this.renderIslands();
    else if (id === 'coopPanel') this.renderCoop();
  }

  /* ---------- do'kon ---------- */
  renderShop() {
    const s = this.app.state;
    $('#shop-money').textContent = CFG.money.symbol + Math.round(s.money);
    const tabs = [['weapon', t('weapon')], ['bait', '🪱'], ['ammo', '🔫'], ['gear', '🎒'], ['charm', '🍀']];
    $('#shop-tabs').innerHTML = tabs.map(([k, l]) => `<button data-tab="${k}" class="${this.shopTab === k ? 'on' : ''}">${l}</button>`).join('');
    $$('#shop-tabs button').forEach((b) => { b.onclick = () => { this.shopTab = b.dataset.tab; this.renderShop(); }; });

    let items = shopCatalog(s).filter((i) => i.tag === this.shopTab);
    if (this.shopTab === 'charm') items = charmCatalog();
    const body = $('#shop-body');
    body.innerHTML = `<div class="grid">${items.map((i) => this._shopCard(i)).join('')}</div>` +
      (this.shopTab === 'weapon' ? this._upgradePanel() : '');

    $$('#shop-body [data-buy]').forEach((b) => {
      b.onclick = () => {
        const item = items.find((x) => x.id === b.dataset.buy && x.kind === b.dataset.kind);
        const r = purchase(s, item, +b.dataset.qty || 1);
        if (!r.ok) this.toast(t(r.reason === 'no_money' ? 'need' : 'owned') + (r.cost ? ` $${r.cost}` : ''), 'bad');
        else {
          this.app.audio.play('coins', { volume: 0.5 }); this.toast(`−$${r.cost}`, 'good');
          if (item.effect?.heal) this.app.player.hp = this.app.state.hp;   // medkit sinxroni
        }
        this.renderShop(); this.updateHUD();
      };
    });
    $$('#shop-body [data-up]').forEach((b) => {
      b.onclick = () => {
        const r = upgradeWeapon(s, b.dataset.up);
        if (r.ok) { this.app.audio.play('coins', { volume: 0.5 }); this.toast(`${WEAPONS[b.dataset.up].name} → Lv${r.level}`, 'good'); }
        else this.toast(r.reason === 'max_level' ? t('maxLevel') : t('need') + ' $' + (r.cost ?? ''), 'bad');
        this.renderShop(); this.updateHUD();
      };
    });
  }

  _shopCard(i) {
    const owned = i.kind === 'weapon' && this.app.state.weapons[i.id];
    const label = i.kind === 'weapon' ? WEAPONS[i.id].name : t(i.desc);
    return `<div class="card ${owned ? 'owned' : ''}">
      <h4>${label}</h4>
      <p>${t('weapons.' + i.id) || t(i.desc) || ''}</p>
      <p class="price">$${i.price}${i.pack ? ` × ${i.pack}` : ''}</p>
      ${owned ? `<span class="owned">${t('owned')}</span>` : `<button class="buy" data-buy="${i.id}" data-kind="${i.kind}" data-qty="${i.kind === 'ammo' || i.kind === 'bait' ? 1 : 1}">${t('buy')}</button>`}
    </div>`;
  }

  _upgradePanel() {
    const s = this.app.state;
    const rows = Object.keys(s.weapons).map((id) => {
      const lv = s.levels[id] ?? 1;
      const st = weaponStats(id, lv);
      const cost = upgradeCost(lv);
      const max = lv >= CFG.weapons.maxLevel;
      return `<tr><td><b>${WEAPONS[id].name}</b><br><span class="lv">Lv ${lv}/${CFG.weapons.maxLevel}</span></td>
        <td>DMG ${st.dmg}<br><span class="stat">RPM ${st.rpm} · MAG ${st.mag || '—'}</span></td>
        <td>${max ? `<span class="owned">${t('maxLevel')}</span>` : `<button data-up="${id}">${t('upgrade')} $${cost}</button>`}</td></tr>`;
    }).join('');
    return `<h3 style="margin:16px 0 6px">${t('upgrade')}</h3><table><thead><tr><th>${t('weapon')}</th><th>Stats</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  /* ---------- kazino ---------- */
  renderCasino() {
    const s = this.app.state;
    $('#casino-money').textContent = CFG.money.symbol + Math.round(s.money);
    const tabs = [['roulette', t('roulette')], ['slots', t('slots')], ['blackjack', t('blackjack')], ['poker', t('poker')]];
    $('#casino-tabs').innerHTML = tabs.map(([k, l]) => `<button data-ct="${k}" class="${this.casinoTab === k ? 'on' : ''}">${l}</button>`).join('');
    $$('#casino-tabs button').forEach((b) => { b.onclick = () => { this.casinoTab = b.dataset.ct; this.renderCasino(); }; });
    const body = $('#casino-body');
    body.innerHTML = `<p class="stat" style="text-align:center">${t('casinoIntro')}</p>`;
    if (this.casinoTab === 'roulette') this._renderRoulette(body);
    else if (this.casinoTab === 'slots') this._renderSlots(body);
    else if (this.casinoTab === 'blackjack') this._renderBlackjack(body);
    else this._renderPoker(body);
  }

  _betRow() {
    return `<div class="bet-row">${[10, 50, 200, 1000].map((v) => `<button data-bet="${v}" class="${this.bet === v ? 'on' : ''}">$${v}</button>`).join('')}
      <span class="stat">${t('bet')}: <b class="price">$${this.bet}</b></span></div>`;
  }
  _bindBets(root) {
    $$('[data-bet]', root).forEach((b) => { b.onclick = () => { this.bet = +b.dataset.bet; this.renderCasino(); }; });
  }
  _gamble(amount) {
    const s = this.app.state;
    if (s.money < amount) { this.toast(t('need'), 'bad'); return false; }
    s.money -= amount; s.stats.spent += amount;
    return true;
  }
  _payout(amount) {
    const s = this.app.state;
    s.money += amount;
    if (amount > 0) { s.stats.earned += amount; s.stats.casinoWon += amount; this.net.won += amount; }
    else this.net.lost += 0;
  }
  _resultLine(win) {
    this.app.audio.play(win > 0 ? 'coins' : 'ui_click', { volume: 0.7 });
    return `<p class="stat" style="text-align:center;font-size:16px">${win > 0 ? `<b style="color:var(--good)">${t('youWin')} +$${win}</b>` : win < 0 ? `<b style="color:var(--bad)">${t('youLose')} −$${this.bet}</b>` : t('push')}</p>`;
  }

  _renderRoulette(root) {
    root.insertAdjacentHTML('beforeend', `<div class="cas">
      <div class="needle"></div>
      <div class="roulette" id="wheel"><div class="hub" id="wheel-num">–</div></div>
      <div class="bet-row">
        <button data-rb="red" style="background:#c0392b">RED ×2</button>
        <button data-rb="black" style="background:#222">BLACK ×2</button>
        <button data-rb="green">0 ×36</button>
        <button data-rb="even">EVEN ×2</button>
        <button data-rb="odd">ODD ×2</button>
        <button data-rb="low">1–18 ×2</button>
        <button data-rb="high">19–36 ×2</button>
      </div>
      ${this._betRow()}
      <button id="spin-btn" class="big">${t('spin')}</button>
      <div id="r-out"></div>
    </div>`);
    this._bindBets(root);
    $$('#casino-body [data-rb]').forEach((b) => {
      b.onclick = () => {
        const type = b.dataset.rb;
        const i = this.bets.findIndex((x) => x.type === type);
        if (i >= 0) this.bets.splice(i, 1); else this.bets.push({ type, amount: this.bet });
        b.classList.toggle('on');
      };
    });
    $('#spin-btn').onclick = () => {
      if (this.rouletteSpinning) return;
      if (!this.bets.length) { this.toast(t('bet'), 'bad'); return; }
      const total = this.bets.reduce((a, b) => a + b.amount, 0);
      if (!this._gamble(total)) return;
      this.rouletteSpinning = true;
      const spin = spinRoulette();
      const wheel = $('#wheel');
      const idx = spin.wheelIndex < 0 ? 0 : spin.wheelIndex;
      const deg = 360 * 5 + (360 - idx * (360 / 37));
      wheel.style.transform = `rotate(${deg}deg)`;
      $('#spin-btn').disabled = true;
      setTimeout(() => {
        const r = resolveRoulette(this.bets, spin);
        $('#wheel-num').textContent = spin.number;
        $('#wheel-num').style.color = spin.color === 'red' ? '#ff6b6b' : spin.color === 'green' ? '#6ee86e' : '#eee';
        $('#r-out').innerHTML = this._resultLine(r.payout - total) + `<p class="stat" style="text-align:center">${r.detail.map((d) => `${d.type}: ${d.win ? '+$' + d.win : '—'}`).join(' · ')}</p>`;
        this._payout(r.payout);
        this.rouletteSpinning = false;
        $('#spin-btn').disabled = false;
        this.updateHUD(); $('#casino-money').textContent = CFG.money.symbol + Math.round(this.app.state.money);
      }, 3700);
    };
  }

  _renderSlots(root) {
    root.insertAdjacentHTML('beforeend', `<div class="cas">
      <div class="slots">${[0, 1, 2].map(() => `<div class="reel">🐟</div>`).join('')}</div>
      ${this._betRow()}
      <button id="slot-btn" class="big">${t('spin')}</button><div id="s-out"></div></div>`);
    this._bindBets(root);
    $('#slot-btn').onclick = () => {
      if (!this._gamble(this.bet)) return;
      const reels = $$('#casino-body .reel');
      reels.forEach((r) => r.classList.add('spin'));
      let n = 0;
      const iv = setInterval(() => { reels.forEach((r) => r.textContent = SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]); if (++n > 12) clearInterval(iv); }, 70);
      setTimeout(() => {
        const res = spinSlots();
        reels.forEach((r, i) => { r.classList.remove('spin'); r.textContent = res.reels[i]; });
        const win = Math.round(this.bet * res.mult);
        $('#s-out').innerHTML = this._resultLine(win - this.bet);
        this._payout(win);
        this.updateHUD(); $('#casino-money').textContent = CFG.money.symbol + Math.round(this.app.state.money);
      }, 1100);
    };
  }

  _renderBlackjack(root) {
    if (!this.bj || this.bj.done === true) this.bj = null;
    const hand = (cards, hide) => `<div class="cards">${cards.map((c, i) => {
      if (hide && i === 1) return `<div class="pc back">?</div>`;
      return `<div class="pc ${c.red ? 'red' : ''}"><span>${c.r}${c.s}</span><small>${c.r}${c.s}</small></div>`;
    }).join('')}</div>`;
    let html = `<div class="cas">`;
    if (!this.bj) {
      html += `${this._betRow()}<button id="bj-deal" class="big">${t('deal')}</button>`;
    } else {
      const b = this.bj;
      html += `<p class="stat">${t('dealerHand')}: <b>${b.done ? this.handVal(b.dealer) : this.cardVal(b.dealer[0])}</b></p>${hand(b.dealer, !b.done)}`;
      html += `<p class="stat">${t('yourHand')}: <b>${this.handVal(b.player)}</b></p>${hand(b.player, false)}`;
      if (!b.done) html += `<div class="bet-row">
        <button id="bj-hit">${t('hit')}</button><button id="bj-stand">${t('stand')}</button>
        ${b.player.length === 2 ? `<button id="bj-double">${t('double')}</button>` : ''}</div>`;
      else html += `<p class="stat" style="font-size:16px">${t(b.result.reason)} — ${b.result.payout > 0 ? `<b style="color:var(--good)">+$${b.result.payout}</b>` : `<b style="color:var(--bad)">−$${b.bet}</b>`}</p>
        <button id="bj-deal" class="big">${t('deal')}</button>`;
    }
    html += `</div>`;
    root.insertAdjacentHTML('beforeend', html);
    this._bindBets(root);

    const deal = () => {
      if (!this._gamble(this.bet)) return;
      this.bj = new Blackjack().deal(this.bet);
      if (this.bj.done) { this._payout(this.bj.result.payout); this.app.audio.play(this.bj.result.payout > 0 ? 'coins' : 'ui_click'); }
      this.renderCasino(); this.updateHUD();
    };
    $('#bj-deal') && ($('#bj-deal').onclick = deal);
    $('#bj-hit') && ($('#bj-hit').onclick = () => { this.bj.hit(); if (this.bj.done) this._payout(this.bj.result.payout); this.renderCasino(); this.updateHUD(); });
    $('#bj-stand') && ($('#bj-stand').onclick = () => { this.bj.stand(); this._payout(this.bj.result.payout); this.renderCasino(); this.updateHUD(); });
    $('#bj-double') && ($('#bj-double').onclick = () => {
      if (!this._gamble(this.bet)) return;
      this.bj.double(); this._payout(this.bj.result.payout); this.renderCasino(); this.updateHUD();
    });
  }
  cardVal(c) { return c.r === 'A' ? 11 : ['J', 'Q', 'K'].includes(c.r) ? 10 : +c.r; }
  handVal(h) { let v = h.reduce((a, c) => a + this.cardVal(c), 0); let a = h.filter((c) => c.r === 'A').length; while (v > 21 && a--) v -= 10; return v; }

  _renderPoker(root) {
    const hand = (cards, held, me) => `<div class="cards">${cards.map((c, i) => `
      <div class="pc ${c.red ? 'red' : ''} ${held?.[i] ? 'held' : ''}" ${me ? `data-hold="${i}"` : ''} style="${held?.[i] ? 'outline:3px solid var(--acc)' : ''}">
        <span>${c.r}${c.s}</span><small>${c.r}${c.s}</small></div>`).join('')}</div>`;
    let html = `<div class="cas">`;
    if (!this.pk) {
      html += `${this._betRow()}<button id="pk-deal" class="big">${t('deal')}</button>`;
    } else {
      const p = this.pk;
      html += `<p class="stat">${t('dealerHand')}</p>${p.phase === 'showdown' ? hand(p.dealer) : hand(p.dealer.map(() => ({ r: '?', s: '♠' })))}`;
      html += `<p class="stat">${t('yourHand')} ${p.phase === 'draw' ? `· ${t('hold')}` : ''}</p>${hand(p.player, p.held, p.phase === 'draw')}`;
      if (p.phase === 'draw') html += `<button id="pk-ex" class="big">${t('draw')}</button>`;
      else html += `<p class="stat" style="font-size:15px">${p.result.playerEval.name} vs ${p.result.dealerEval.name}<br>
        ${p.result.winner === 'player' ? `<b style="color:var(--good)">${t('youWin')} +$${p.result.payout}</b>` : p.result.winner === 'dealer' ? `<b style="color:var(--bad)">${t('youLose')}</b>` : t('push')}</p>
        <button id="pk-deal" class="big">${t('deal')}</button>`;
    }
    html += `</div>`;
    root.insertAdjacentHTML('beforeend', html);
    this._bindBets(root);
    $('#pk-deal') && ($('#pk-deal').onclick = () => {
      if (!this._gamble(this.bet)) return;
      this.pk = new PokerGame().deal(this.bet);
      this.renderCasino(); this.updateHUD();
    });
    $$('#casino-body [data-hold]').forEach((c) => { c.onclick = () => { this.pk.toggleHold(+c.dataset.hold); this.renderCasino(); }; });
    $('#pk-ex') && ($('#pk-ex').onclick = () => {
      this.pk.exchange();
      this._payout(this.pk.result.payout);
      this.app.audio.play(this.pk.result.payout > 0 ? 'coins' : 'ui_click');
      this.renderCasino(); this.updateHUD();
    });
  }

  /* ---------- inventar ---------- */
  renderInventory() {
    const s = this.app.state;
    const rows = s.cooler.items.map((it) => {
      const sp = SPECIES.find((x) => x.id === it.speciesId);
      const price = fishPrice({ species: it.speciesId, tier: it.tier, weight: it.weight, method: it.method, trickMult: it.trickMult ?? 1, vendor: 'fishMarket', cooked: it.cooked, lucky: it.luckyMult ?? 1 });
      return `<tr>
        <td><span class="rarity-${sp.rarity}">${sp.name}</span><br><span class="stat">${t(`size.${it.tier}`)} · ${it.weight} kg</span></td>
        <td>${it.cooked ? `<span class="owned">${t('cooked')}</span>` : t('raw')}<br><span class="stat">${t('weapons.' + it.method) ? it.method : it.method}</span></td>
        <td class="price">$${price}</td>
        <td><button data-cook="${it.uid}">${t('cook')}</button> <button data-sellone="${it.uid}">${t('sell')}</button></td></tr>`;
    }).join('');
    const vendorBtns = Object.keys(VENDORS).map((v) => `<button data-sellall="${v}">${t('sellAll')} → ${VENDORS[v].name} (×${VENDORS[v].mult})</button>`).join(' ');
    $('#inv-body').innerHTML = `
      <h3>❄ ${t('cooler')} — ${s.cooler.count}/${s.cooler.cap} · ${t('balance')} <span class="price">$${s.cooler.totalValue()}</span></h3>
      <table><thead><tr><th>${t('codex')}</th><th>${t('raw')}</th><th>$</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="4" class="stat">—</td></tr>`}</tbody></table>
      <div class="bet-row" style="margin-top:10px">${vendorBtns}</div>
      <h3 style="margin-top:18px">🔥 ${t('useGrill')} — ${t('fuel')} ${Math.round(s.grill.fuel)}%</h3>
      <div class="bet-row"><button id="grill-fuel">${t('addFuel')} (+50)</button>
        ${s.grill.queue.map((q) => `<span class="stat">⏳ ${q.t.toFixed(1)}s</span>`).join('')}</div>
      <h3 style="margin-top:18px">🔦 ${t('lanternMode')}: ${s.lantern.mode} · ${t('battery')} ${Math.round(s.lantern.battery)}%</h3>
      <div class="bet-row">
        <button id="lan-mode">${t('lanternMode')}</button>
        ${s.lantern.colors.map((c) => `<button data-lcolor="${c}" style="background:${c};width:34px"></button>`).join('')}
        <button id="lan-charge">${t('recharge')}</button>
      </div>
      <h3 style="margin-top:18px">📊 ${t('stats.playtime')}</h3>
      <table><tbody>${Object.entries(s.stats).map(([k, v]) => `<tr><td>${t('stats.' + k) || k}</td><td>${typeof v === 'number' ? (k === 'playtime' ? Math.round(v / 60) + ' min' : (k === 'biggest' ? v + ' kg' : Math.round(v))) : (v?.speciesId ?? '—')}</td></tr>`).join('')}</tbody></table>`;

    $$('#inv-body [data-cook]').forEach((b) => { b.onclick = () => { const r = s.grill.start(s.cooler, b.dataset.cook); if (!r.ok) this.toast(t(r.reason === 'no_fuel' ? 'fuel' : 'cooked'), 'bad'); this.renderInventory(); }; });
    $$('#inv-body [data-sellone]').forEach((b) => {
      b.onclick = () => {
        const it = s.cooler.items.find((x) => x.uid === b.dataset.sellone);
        const price = fishPrice({ species: it.speciesId, tier: it.tier, weight: it.weight, method: it.method, trickMult: it.trickMult ?? 1, vendor: 'fishMarket', cooked: it.cooked, lucky: it.luckyMult ?? 1 });
        const r = sellFish(s, 'fishMarket', it, price);
        if (r.ok) { s.cooler.remove(it.uid); this.app.audio.play('coins'); this.toast(`+$${r.money}`, 'good'); }
        this.renderInventory(); this.updateHUD();
      };
    });
    $$('#inv-body [data-sellall]').forEach((b) => {
      b.onclick = () => {
        const v = b.dataset.sellall;
        const res = s.cooler.sellAll(v);
        s.money += res.money; s.stats.earned += res.money; s.stats.sold += res.count;
        s.vendorStock[v] = Math.max(0, (s.vendorStock[v] ?? VENDORS[v].cap) - res.count);
        this.app.audio.play('coins');
        this.toast(`${res.count} × → +$${res.money}`, 'good');
        this.renderInventory(); this.updateHUD();
      };
    });
    $('#grill-fuel').onclick = () => { s.grill.addFuel(50); this.renderInventory(); };
    $('#lan-mode').onclick = () => { s.lantern.cycleMode(); this.renderInventory(); };
    $('#lan-charge').onclick = () => { s.lantern.recharge(); this.renderInventory(); };
    $$('#inv-body [data-lcolor]').forEach((b) => { b.onclick = () => { s.lantern.setColor(b.dataset.lcolor); this.app.applyLantern(); this.renderInventory(); }; });
  }

  /* ---------- sozlamalar ---------- */
  renderSettings() {
    const s = this.app.state.settings;
    const slider = (k, label, min, max, step) => `<div class="sw"><span style="width:170px">${label}</span>
      <input type="range" min="${min}" max="${max}" step="${step}" value="${s[k]}" data-set="${k}"><b id="v-${k}">${s[k]}</b></div>`;
    $('#settings-body').innerHTML = `
      ${slider('master', t('master'), 0, 1, 0.05)}
      ${slider('sfx', t('sfx'), 0, 1, 0.05)}
      ${slider('music', t('music'), 0, 1, 0.05)}
      ${slider('sens', t('sens'), 0.2, 3, 0.1)}
      ${slider('fov', t('fov'), 60, 110, 1)}
      <div class="sw"><span style="width:170px">${t('invertY')}</span><input type="checkbox" data-chk="invertY" ${s.invertY ? 'checked' : ''}></div>
      <div class="sw"><span style="width:170px">${t('pvpSetting')}</span><input type="checkbox" data-chk="pvp" ${s.pvp ? 'checked' : ''}></div>
      <div class="sw"><span style="width:170px">${t('quality')}</span>
        <select data-sel="quality">${['low', 'medium', 'high'].map((q) => `<option value="${q}" ${s.quality === q ? 'selected' : ''}>${q}</option>`).join('')}</select></div>
      <div class="sw"><span style="width:170px">${t('langLabel')}</span>
        <select id="lang-sel">${LANGS.map((l) => `<option value="${l}" ${s.lang === l ? 'selected' : ''}>${l.toUpperCase()}</option>`).join('')}</select></div>
      <div class="sw"><span style="width:170px">Yandex</span><span class="stat">${this.app.ya.available ? 'SDK ✓' : t('offline')}</span></div>
      <div class="bet-row" style="margin-top:12px">
        <button id="set-save">${t('save')}</button>
        <button id="set-cloud">☁ ${t('cloudSaved')}</button>
        <button id="set-lb">${t('leaderboard')}</button>
      </div>
      <div id="lb-out"></div>`;
    $$('#settings-body [data-set]').forEach((r) => {
      r.oninput = () => { s[r.dataset.set] = +r.value; $('#v-' + r.dataset.set).textContent = r.value; this.app.applySettings(); };
    });
    $$('#settings-body [data-chk]').forEach((c) => { c.onchange = () => { s[c.dataset.chk] = c.checked; this.app.applySettings(); }; });
    $('#lang-sel').onchange = (e) => { s.lang = e.target.value; setLang(s.lang); this.refreshLang(); this.renderSettings(); };
    $('#set-save').onclick = () => { this.app.saveGame(true); this.toast(t('ok'), 'good'); };
    $('#set-cloud').onclick = async () => { const r = await this.app.saveCloud(); this.toast(r.ok ? `${t('cloudSaved')} (${r.kb} KB)` : r.reason, r.ok ? 'good' : 'bad'); };
    $('#set-lb').onclick = async () => {
      const rows = await this.app.ya.getScores(10);
      $('#lb-out').innerHTML = `<table><thead><tr><th>#</th><th></th><th></th></tr></thead><tbody>${rows.map((r) => `<tr><td>${r.rank}</td><td>${r.name}</td><td>${r.score}</td></tr>`).join('') || '<tr><td colspan=3 class=stat>—</td></tr>'}</tbody></table>`;
    };
  }

  /* ---------- kodeks ---------- */
  renderCodex() {
    const s = this.app.state;
    const prog = s.codexProgress();
    $('#codex-count').textContent = `${prog.seen}/${prog.total} (${prog.pct}%)`;
    const rows = SPECIES.map((sp) => {
      const c = s.codex[sp.id];
      return `<tr>
        <td><span class="rarity-${sp.rarity}">${c ? sp.name : '???'}</span></td>
        <td>${this.app.rarityLabel(sp.rarity)}</td>
        <td>${c ? c.count : 0}</td>
        <td>${c ? c.best + ' kg · ' + t(`size.${c.bestTier}`) : '—'}</td>
        <td>${sp.armed ? '🔫' : ''}</td></tr>`;
    }).join('');
    $('#codex-body').innerHTML = `<table><thead><tr><th>${t('codex')}</th><th>${t('luck')}</th><th>#</th><th>${t('stats.biggest')}</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  /* ---------- orollar ---------- */
  renderIslands() {
    const s = this.app.state;
    $('#islands-body').innerHTML = `<div class="grid">${ISLANDS.map((isle) => {
      const un = s.unlockedIslands.includes(isle.id);
      const bossDone = s.defeatedBosses.includes(isle.id);
      const can = canUnlockIsland(s, isle.id);
      return `<div class="card ${un ? '' : 'locked'}">
        <h4>${isle.name} ${un ? '✓' : '🔒'}</h4>
        <p>${t('islandDesc.' + isle.desc)}</p>
        <p class="stat">${t('weather.' + isle.weathers[0])} · ${isle.biome === 'salt' ? '🌊 salt' : '💧 fresh'}</p>
        <p class="stat">${t('boss')}: ${bossDone ? `<span class="owned">${t('bossDefeated')}</span>` : '⚔'}</p>
        ${un ? `<button data-go="${isle.id}">${isle.id === s.island ? '●' : t('travelTo')}</button>`
          : `<button data-unlock="${isle.id}" ${can.ok ? '' : 'disabled'}>${t('unlockIsland')} $${isle.unlockCost}</button>
             ${!can.ok && can.reason === 'boss_required' ? `<p class="stat">${t('bossRequired')}</p>` : ''}`}
      </div>`;
    }).join('')}</div>`;
    $$('#islands-body [data-go]').forEach((b) => { b.onclick = () => { this.app.travel(+b.dataset.go); this.app.resume(); }; });
    $$('#islands-body [data-unlock]').forEach((b) => {
      b.onclick = () => {
        const r = unlockIsland(s, +b.dataset.unlock);
        if (r.ok) { this.toast(`${t('islandUnlocked')} ${ISLANDS[r.island].name}`, 'gold'); this.app.audio.play('coins'); }
        else this.toast(t('bossRequired'), 'bad');
        this.renderIslands(); this.updateHUD();
      };
    });
  }

  /* ---------- kooperativ ---------- */
  renderCoop() {
    const box = $('#coop-body');
    if (!box) return;
    box.innerHTML = this._coopHTML();
    this._bindCoop();
  }
  _coopHTML() {
    const net = this.app.net;
    return `<h3>${t('coopTitle')}</h3>
      <div class="sw"><span style="width:150px">${t('netMode')}</span>
        <select id="net-mode">${['local', 'fusion', 'mirror'].map((m) => `<option value="${m}" ${net.mode === m ? 'selected' : ''}>${t('net' + m[0].toUpperCase() + m.slice(1))}</option>`).join('')}</select></div>
      <div class="sw"><span style="width:150px">${t('roomCode')}</span><input id="room-code" value="${net.room ?? 'FISH1'}" style="flex:1"></div>
      <div class="bet-row"><button id="net-create">${t('createRoom')}</button><button id="net-join">${t('joinRoom')}</button></div>
      <p class="stat">${t('playersInRoom')}: <b id="net-count">${net.count}/4</b> · ${t('pvpEnabled')}</p>
      <div id="net-list"></div>`;
  }
  _bindCoop() {
    $('#net-mode') && ($('#net-mode').onchange = (e) => { this.app.net.mode = e.target.value; });
    $('#net-create') && ($('#net-create').onclick = () => this.app.connectNet($('#room-code').value, true));
    $('#net-join') && ($('#net-join').onclick = () => this.app.connectNet($('#room-code').value, false));
  }
}
