/**
 * net.js — ko'p o'yinchi adapteri (maks 4 o'yinchi).
 *
 * Uchta transport:
 *  - local   : BroadcastChannel (bir brauzerda bir nechta tab — sandbox'da ishlaydi)
 *  - fusion  : Photon Fusion (stub — ulanish nuqtasi tayyor)
 *  - mirror  : Unity Mirror (stub)
 *
 * Interfeys transportdan mustaqil, shuning uchun keyin haqiqiy Photon/Mirror
 * implementatsiyasini almashtirish kifoya.
 */
import { CFG } from './core/balance.js';

const TICK = 1 / CFG.multiplayer.tickHz;

export class NetAdapter {
  constructor(mode = 'local') {
    this.mode = mode;
    this.players = new Map();      // id → {id, name, x,y,z, ry, weapon, hp, catchCount, lastSeen}
    this.selfId = 'p' + Math.random().toString(36).slice(2, 8);
    this.room = null;
    this.host = false;
    this.connected = false;
    this.rejected = false;
    this.selfName = 'Fisher';
    this.onEvent = () => {};
    this._ch = null;
    this._acc = 0;
  }

  async connect(room, name) {
    this.room = room;
    this.selfName = name ?? this.selfName;
    if (this.mode === 'local') {
      if (typeof BroadcastChannel === 'undefined') {
        this.connected = false;
        this.onEvent({ type: 'error', message: 'BroadcastChannel is not supported in this browser' });
        return false;
      }
      this._ch = new BroadcastChannel('htf_' + room);
      this._ch.onmessage = (e) => this._onMsg(e.data);
      this.connected = true;
      this.host = true;
      this._send({ type: 'hello', id: this.selfId, name });
      this.onEvent({ type: 'connected', mode: this.mode, room, selfId: this.selfId });
      return true;
    }
    // Photon Fusion / Mirror — brauzerda Photon WebGL SDK kerak.
    this.connected = false;
    this.onEvent({
      type: 'error',
      message: `${this.mode} transport is a stub: plug in Photon Fusion (Realtime/WebRTC) or Mirror here.`,
    });
    return false;
  }

  disconnect() {
    this._send({ type: 'bye', id: this.selfId });
    if (this._ch) { this._ch.close(); this._ch = null; }
    this.connected = false;
    this.players.clear();
  }

  _send(msg) {
    if (!this._ch) return;
    try { this._ch.postMessage({ ...msg, room: this.room, t: performance.now() }); } catch (e) { /* ignore */ }
  }

  _onMsg(m) {
    if (!m || m.room !== this.room || m.id === this.selfId) return;
    if (this.rejected) return;                    // xona rad etgan — eshitmaymiz
    if (m.type === 'reject' && (!m.to || m.to === this.selfId)) {
      this.rejected = true;
      this.players.clear();
      this.onEvent({ type: 'rejected', message: 'room_full' });
      return;
    }
    if (m.type === 'hello') {
      if (this.full) {                            // xona to'la (4) — aniq rad javobi
        this._send({ type: 'reject', id: this.selfId, to: m.id });
        return;
      }
      this._send({ type: 'welcome', id: this.selfId, to: m.id, name: m.name });
      this.players.set(m.id, { id: m.id, name: m.name, ...m.state, lastSeen: performance.now() });
      this.onEvent({ type: 'join', player: this.players.get(m.id) });
    } else if (m.type === 'welcome') {
      if (this.full) return;
      if (!this.players.has(m.id)) {
        this.players.set(m.id, { id: m.id, name: m.name, ...m.state, lastSeen: performance.now() });
        this.onEvent({ type: 'join', player: this.players.get(m.id) });
      }
    } else if (m.type === 'state') {
      const p = this.players.get(m.id);
      if (p) { Object.assign(p, m.state, { lastSeen: performance.now() }); }
      else if (!this.full) { this.players.set(m.id, { id: m.id, name: m.name, ...m.state, lastSeen: performance.now() }); this.onEvent({ type: 'join', player: this.players.get(m.id) }); }
    } else if (m.type === 'bye') {
      const p = this.players.get(m.id);
      this.players.delete(m.id);
      this.onEvent({ type: 'leave', player: p });
    } else if (m.type === 'event') {
      this.onEvent({ type: 'game', kind: m.kind, from: m.id, data: m.data });
    }
  }

  /** Har kadrda chaqiriladi: holatni yuborish + uzilib qolganlarni tozalash. */
  update(dt, selfState) {
    if (this.rejected) return;
    this._acc += dt;
    if (this._acc >= TICK) {
      this._acc = 0;
      if (this.connected) this._send({ type: 'state', id: this.selfId, name: selfState.name ?? this.selfName, state: selfState });
    }
    const now = performance.now();
    for (const [id, p] of [...this.players]) {
      if (now - p.lastSeen > 6000) { this.players.delete(id); this.onEvent({ type: 'leave', player: p }); }
    }
  }

  /** Boshqa o'yinchilar soni (maks 4 jami). */
  get count() { return this.players.size + 1; }
  get full() { return this.count >= CFG.multiplayer.maxPlayers; }
  canJoin() { return !this.full; }

  /** O'yin hodisasini hamma yuborish (tutish, o'ldirish, PvP zarba). */
  sendEvent(kind, data) {
    if (!this.connected || this.rejected) return false;
    this._send({ type: 'event', id: this.selfId, kind, data });
    return true;
  }

  /** PvP zarba: faqat PvP yoqilgan bo'lsa. */
  sendDamage(targetId, dmg, weapon) {
    if (!CFG.multiplayer.pvpDamage) return false;
    return this.sendEvent('damage', { target: targetId, dmg, weapon });
  }

  /** Boshqa o'yinchilarning massiv ko'rinishi (render uchun). */
  list() { return [...this.players.values()]; }
}
