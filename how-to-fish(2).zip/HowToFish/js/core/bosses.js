/**
 * bosses.js — Boss janglari: HP, fazalar, maxsus hujumlar. Sof mantiq.
 */
import { BOSS_BY_ISLAND, BOSSES, ISLANDS } from './fishData.js';

export const BOSS_ATTACKS = {
  charge:      { dmg: 22, cd: 6.0, windup: 0.9, range: 26, key: 'bossCharge' },
  summon:      { dmg: 0,  cd: 14,  windup: 1.4, count: 4, key: 'bossSummon' },
  whirlpool:   { dmg: 8,  cd: 11,  windup: 1.2, range: 18, pull: 6, key: 'bossWhirlpool' },
  ink:         { dmg: 10, cd: 9,   windup: 0.7, range: 20, blind: 4.0, key: 'bossInk' },
  frost_breath:{ dmg: 14, cd: 10,  windup: 1.1, range: 16, slow: 3.0, key: 'bossFrost' },
  acid_spit:   { dmg: 18, cd: 8,   windup: 0.6, range: 22, key: 'bossAcid' },
  tail_slam:   { dmg: 30, cd: 13,  windup: 1.0, range: 10, key: 'bossSlam' },
  lightning:   { dmg: 34, cd: 12,  windup: 1.5, range: 40, key: 'bossLightning' },
};

export function createBoss(islandId) {
  const def = BOSS_BY_ISLAND[islandId];
  if (!def) return null;
  return {
    ...def,
    islandId,
    hp: def.hp, maxHP: def.hp,
    phase: 1, enrage: 1,
    cooldowns: Object.fromEntries(def.attacks.map((a) => [a, 2 + Math.random() * 3])),
    windup: null, alive: true,
  };
}

export function bossPhase(b) {
  const p = b.hp / b.maxHP;
  return p > 0.66 ? 1 : p > 0.33 ? 2 : 3;
}

/**
 * @returns {{attack?:string, attackDef?:object, phaseChanged:boolean}}
 */
export function updateBoss(b, dt, ctx = {}) {
  if (!b.alive) return { phaseChanged: false };
  const prevPhase = b.phase;
  b.phase = bossPhase(b);
  // kam HP → yuqoriroq faza → tezroq/kuchliroq hujumlar
  b.enrage = 1 + (b.phase - 1) * 0.28;
  const phaseChanged = b.phase !== prevPhase;

  let chosen = null;
  for (const atk of b.attacks) {
    b.cooldowns[atk] -= dt * b.enrage;
    if (b.cooldowns[atk] <= 0) {
      const def = BOSS_ATTACKS[atk];
      const dist = ctx.distance ?? 999;
      const okRange = !def.range || dist <= def.range;
      if (okRange) { chosen = { id: atk, def }; break; }
      else b.cooldowns[atk] = 1.5;      // masofa yetmasa — qayta urinish
    }
  }
  if (chosen) {
    b.cooldowns[chosen.id] = chosen.def.cd / b.enrage;
    b.windup = { id: chosen.id, t: chosen.def.windup, def: chosen.def };
  }
  if (b.windup) {
    b.windup.t -= dt;
    if (b.windup.t <= 0) { const done = b.windup; b.windup = null; return { attack: done.id, attackDef: done.def, phaseChanged }; }
  }
  return { phaseChanged, phase: b.phase };
}

export function damageBoss(b, dmg) {
  if (!b.alive) return false;
  b.hp = Math.max(0, b.hp - dmg);
  if (b.hp <= 0) { b.alive = false; b.defeated = true; return true; }
  return false;
}

/** Boss mag'lubiyati → yangi orol ochiladi. */
export function unlockNextIsland(state, islandId) {
  const next = islandId + 1;
  if (next >= ISLANDS.length) return { unlocked: null, allDone: true };
  state.unlockedIslands = [...new Set([...(state.unlockedIslands ?? [0]), next])];
  return { unlocked: next, island: ISLANDS[next], allDone: false };
}

export function bossReward(b) {
  return { money: b.price, xp: Math.round(b.hp / 10), item: `charm_token_${b.island}` };
}

export const ALL_BOSSES = BOSSES;
