/**
 * time.js — kun/tun sikli + ob-havo. Sof mantiq (render world.js da).
 */
import { CFG } from './balance.js';
import { ISLANDS } from './fishData.js';

export const WEATHERS = {
  clear:   { bite: 1.00, visibility: 1.00, wave: 0.25, wind: 0.2, fog: 0.00, icon: '☀' },
  cloudy:  { bite: 1.10, visibility: 0.90, wave: 0.35, wind: 0.4, fog: 0.10, icon: '☁' },
  rain:    { bite: 1.35, visibility: 0.62, wave: 0.55, wind: 0.6, fog: 0.20, icon: '🌧' },
  thunder: { bite: 1.65, visibility: 0.52, wave: 0.75, wind: 0.8, fog: 0.22, icon: '⛈' },
  fog:     { bite: 0.80, visibility: 0.28, wave: 0.20, wind: 0.1, fog: 1.00, icon: '🌫' },
  snow:    { bite: 0.70, visibility: 0.60, wave: 0.30, wind: 0.5, fog: 0.30, icon: '❄' },
  wind:    { bite: 1.15, visibility: 0.95, wave: 0.90, wind: 1.0, fog: 0.02, icon: '🌬' },
  storm:   { bite: 1.80, visibility: 0.40, wave: 1.00, wind: 1.0, fog: 0.35, icon: '🌪' },
};

export function hourPhase(hour) {
  if (hour >= 5 && hour < 8) return 'dawn';
  if (hour >= 8 && hour < 17) return 'day';
  if (hour >= 17 && hour < 20) return 'dusk';
  return 'night';
}

export class WorldTime {
  constructor(hour = CFG.time.startHour, day = 1) {
    this.hour = hour; this.day = day; this._acc = 0;
  }
  update(dt) {
    this._acc += dt;
    const hoursPerSec = 24 / CFG.time.dayLengthSec;
    let h = this.hour + dt * hoursPerSec;
    while (h >= 24) { h -= 24; this.day += 1; }
    this.hour = h;
    return this.day;
  }
  get phase() { return hourPhase(this.hour); }
  get clock() {
    const hh = String(Math.floor(this.hour)).padStart(2, '0');
    const mm = String(Math.floor((this.hour % 1) * 60)).padStart(2, '0');
    return `${hh}:${mm}`;
  }
  get biteMult() { return CFG.time.biteByHour[this.phase]; }
  get isNight() { return this.phase === 'night'; }
  /** Quyosh balandligi (-1..1) — yorug'lik va osmon rangi uchun. */
  get sunElevation() { return Math.sin(((this.hour - 6) / 24) * Math.PI * 2); }
  get sunAzimuth() { return ((this.hour - 6) / 24) * Math.PI * 2; }
}

export class Weather {
  constructor(islandId = 0, seed = 1) {
    this.setIsland(islandId);
    this.rnd = mulberry32(seed);
    this.current = this.island.weathers[0];
    this.timer = 60 + this.rnd() * 90;
    this.intensity = 0.5;
    this.lightning = 0;      // chaqmoq chaqnashi (0..1)
    this._flashCd = 4;
  }
  setIsland(id) { this.island = ISLANDS[id] ?? ISLANDS[0]; }
  get data() { return WEATHERS[this.current] ?? WEATHERS.clear; }
  get name() { return this.current; }
  get biteMult() { return this.data.bite; }

  update(dt) {
    this.timer -= dt;
    this.intensity += (this.rnd() - 0.5) * dt * 0.25;
    this.intensity = Math.min(1, Math.max(0.2, this.intensity));
    this.lightning = Math.max(0, this.lightning - dt * 3.2);

    if ((this.current === 'thunder' || this.current === 'storm')) {
      this._flashCd -= dt;
      if (this._flashCd <= 0) { this.lightning = 1; this._flashCd = 3 + this.rnd() * 9; }
    }
    if (this.timer <= 0) this.roll();
    return this;
  }
  roll(force) {
    const list = this.island.weathers;
    if (force && list.includes(force)) { this.current = force; }
    else {
      // joriy ob-havodan keskin chiqmaslik uchun og'irlik
      let r = this.rnd();
      const stay = 0.35;
      if (r < stay && list.length > 1) this.current = this.current;
      else this.current = list[Math.floor(this.rnd() * list.length)];
    }
    this.timer = 55 + this.rnd() * 120;
    return this.current;
  }
  toJSON() { return { current: this.current, timer: this.timer, island: this.island.id }; }
}

export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
