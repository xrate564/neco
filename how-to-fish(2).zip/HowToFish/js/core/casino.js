/**
 * casino.js — Ruletka, Slot, Blackjack, 5-Card Draw Poker. Sof mantiq + testlanadigan RNG.
 */
import { CFG } from './balance.js';

export const ROULETTE_NUMBERS = [
  0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26,
];
export const RED_NUMBERS = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
export const colorOf = (n) => (n === 0 ? 'green' : RED_NUMBERS.has(n) ? 'red' : 'black');

/** Ruletka: 37 katak (0..36). */
export function spinRoulette(rnd = Math.random) {
  const n = Math.floor(rnd() * 37);
  return { number: n, color: colorOf(n), wheelIndex: ROULETTE_NUMBERS.indexOf(n) };
}
/** @param {Array<{type:'red'|'black'|'green'|'even'|'odd'|'low'|'high'|'number', value?:number, amount:number}>} bets */
export function resolveRoulette(bets, spin) {
  let payout = 0; const detail = [];
  for (const b of bets) {
    let win = 0;
    if (b.type === 'red' || b.type === 'black') win = spin.color === b.type ? b.amount * 2 : 0;
    else if (b.type === 'green') win = spin.color === 'green' ? b.amount * 36 : 0;
    else if (b.type === 'number') win = spin.number === b.value ? b.amount * 36 : 0;
    else if (b.type === 'even') win = spin.number !== 0 && spin.number % 2 === 0 ? b.amount * 2 : 0;
    else if (b.type === 'odd') win = spin.number % 2 === 1 ? b.amount * 2 : 0;
    else if (b.type === 'low') win = spin.number >= 1 && spin.number <= 18 ? b.amount * 2 : 0;
    else if (b.type === 'high') win = spin.number >= 19 && spin.number <= 36 ? b.amount * 2 : 0;
    payout += win;
    detail.push({ ...b, win });
  }
  return { payout, detail, spin };
}

/** Slot: 3 baraban, 8 belgi. */
export const SLOT_SYMBOLS = ['🐟','🎣','⭐','🍒','💎','7️⃣','🐙','🌊'];
export const SLOT_PAYTABLE = {
  '🐟': 3, '🎣': 5, '⭐': 8, '🍒': 2, '💎': 20, '7️⃣': 50, '🐙': 12, '🌊': 4,
};
export function spinSlots(rnd = Math.random) {
  const pick = () => SLOT_SYMBOLS[Math.floor(rnd() * SLOT_SYMBOLS.length)];
  const reels = [pick(), pick(), pick()];
  let mult = 0;
  if (reels[0] === reels[1] && reels[1] === reels[2]) mult = SLOT_PAYTABLE[reels[0]];
  else if (reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2]) mult = 1.5;
  return { reels, mult };
}

/** ---------- Blackjack ---------- */
const SUITS = ['♠','♥','♦','♣'];
const RANKS = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
export function makeDeck(rnd = Math.random) {
  const d = [];
  for (const s of SUITS) for (const r of RANKS) d.push({ r, s, red: s === '♥' || s === '♦' });
  for (let i = d.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [d[i], d[j]] = [d[j], d[i]]; }
  return d;
}
export const cardValue = (c) => (c.r === 'A' ? 11 : ['J','Q','K'].includes(c.r) ? 10 : parseInt(c.r, 10));
export function handValue(hand) {
  let v = hand.reduce((a, c) => a + cardValue(c), 0);
  let aces = hand.filter((c) => c.r === 'A').length;
  while (v > 21 && aces > 0) { v -= 10; aces--; }
  return v;
}
export const isBlackjack = (hand) => hand.length === 2 && handValue(hand) === 21;

export class Blackjack {
  constructor(rnd = Math.random, deck = null) { this.rnd = rnd; this.deck = deck ?? makeDeck(rnd); }
  draw() { if (this.deck.length < 15) this.deck = makeDeck(this.rnd); return this.deck.pop(); }
  deal(bet) {
    this.bet = bet;
    this.player = [this.draw(), this.draw()];
    this.dealer = [this.draw(), this.draw()];
    this.done = false;
    this.result = null;
    if (isBlackjack(this.player) || isBlackjack(this.dealer)) this.finish();
    return this;
  }
  hit() { this.player.push(this.draw()); if (handValue(this.player) >= 21) this.finish(); return this; }
  stand() { this.finish(); return this; }
  double() {
    if (this.player.length !== 2) return this;
    this.bet *= 2; this.player.push(this.draw()); this.finish(); return this;
  }
  finish() {
    while (handValue(this.dealer) < 17) this.dealer.push(this.draw());
    const p = handValue(this.player), d = handValue(this.dealer);
    let mult = 0; let reason = 'push';
    if (p > 21) { mult = 0; reason = 'bust'; }
    else if (isBlackjack(this.player) && !isBlackjack(this.dealer)) { mult = 2.5; reason = 'blackjack'; }
    else if (d > 21) { mult = 2; reason = 'dealer_bust'; }
    else if (p > d) { mult = 2; reason = 'win'; }
    else if (p < d) { mult = 0; reason = 'lose'; }
    this.result = { mult, reason, player: p, dealer: d, payout: Math.round(this.bet * mult) };
    this.done = true;
    return this;
  }
}

/** ---------- 5 Card Draw Poker (bitta raqib) ---------- */
export const POKER_HANDS = ['highCard','pair','twoPair','threeKind','straight','flush','fullHouse','fourKind','straightFlush'];
export function evaluatePoker(hand) {
  const vals = hand.map((c) => (c.r === 'A' ? 14 : c.r === 'K' ? 13 : c.r === 'Q' ? 12 : c.r === 'J' ? 11 : parseInt(c.r, 10))).sort((a, b) => b - a);
  const suits = hand.map((c) => c.s);
  const counts = {};
  vals.forEach((v) => { counts[v] = (counts[v] ?? 0) + 1; });
  const groups = Object.entries(counts).map(([v, n]) => ({ v: +v, n })).sort((a, b) => b.n - a.n || b.v - a.v);
  const flush = suits.every((s) => s === suits[0]);
  const uniq = [...new Set(vals)];
  let straight = false;
  if (uniq.length === 5) {
    straight = uniq[0] - uniq[4] === 4;
    if (!straight && uniq.join() === '14,5,4,3,2') straight = true; // wheel
  }
  let idx, tie = uniq[0];
  if (straight && flush) idx = 8;
  else if (groups[0].n === 4) { idx = 7; tie = groups[0].v; }
  else if (groups[0].n === 3 && groups[1]?.n === 2) { idx = 6; tie = groups[0].v; }
  else if (flush) idx = 5;
  else if (straight) idx = 4;
  else if (groups[0].n === 3) { idx = 3; tie = groups[0].v; }
  else if (groups[0].n === 2 && groups[1]?.n === 2) { idx = 2; tie = Math.max(groups[0].v, groups[1].v); }
  else if (groups[0].n === 2) { idx = 1; tie = groups[0].v; }
  else idx = 0;
  return { idx, name: POKER_HANDS[idx], tie, cards: hand };
}
export const POKER_PAYOUT = [0, 1, 2, 3, 5, 8, 12, 30, 80]; // ×bet

export class PokerGame {
  constructor(rnd = Math.random) { this.rnd = rnd; this.deck = makeDeck(rnd); }
  draw() { if (this.deck.length < 15) this.deck = makeDeck(this.rnd); return this.deck.pop(); }
  deal(bet) {
    this.bet = bet;
    this.player = [this.draw(), this.draw(), this.draw(), this.draw(), this.draw()];
    this.dealer = [this.draw(), this.draw(), this.draw(), this.draw(), this.draw()];
    this.held = [false, false, false, false, false];
    this.phase = 'draw';
    return this;
  }
  toggleHold(i) { this.held[i] = !this.held[i]; return this; }
  aiHolds() {
    const e = evaluatePoker(this.dealer);
    const counts = {};
    this.dealer.forEach((c) => { counts[c.r] = (counts[c.r] ?? 0) + 1; });
    this.dealer.forEach((c, i) => { this.heldAi = this.heldAi ?? []; this.heldAi[i] = (counts[c.r] ?? 0) > 1 || e.idx >= 4; });
    return this.heldAi;
  }
  exchange() {
    this.player.forEach((_, i) => { if (!this.held[i]) this.player[i] = this.draw(); });
    const ai = this.aiHolds();
    this.dealer.forEach((_, i) => { if (!ai[i]) this.dealer[i] = this.draw(); });
    this.phase = 'showdown';
    const pe = evaluatePoker(this.player), de = evaluatePoker(this.dealer);
    let winner;
    if (pe.idx !== de.idx) winner = pe.idx > de.idx ? 'player' : 'dealer';
    else winner = pe.tie !== de.tie ? (pe.tie > de.tie ? 'player' : 'dealer') : 'push';
    const payout = winner === 'player' ? Math.round(this.bet * 2 + this.bet * POKER_PAYOUT[pe.idx] * 0.2) : 0;
    this.result = { winner, payout, playerEval: pe, dealerEval: de };
    return this;
  }
}

/** Kazino statistikasi (house edge tekshiruvi uchun). Blackjack — oddiy strategiya boti. */
export function simulateHouseEdge(games = 20000, rnd = Math.random) {
  let bet = 0, ret = 0;
  const third = Math.floor(games / 3);
  for (let i = 0; i < third; i++) { const s = spinRoulette(rnd); const r = resolveRoulette([{ type: 'red', amount: 10 }], s); bet += 10; ret += r.payout; }
  for (let i = 0; i < third; i++) { const s = spinSlots(rnd); bet += 10; ret += 10 * s.mult; }
  const bj = new Blackjack(rnd);
  for (let i = 0; i < 2000; i++) {
    bj.deal(10);
    let guard = 0;
    // 17+ da to'xta, aks holda karta ol (soft 17 gacha)
    while (!bj.done && guard++ < 20) { if (handValue(bj.player) >= 17) bj.stand(); else bj.hit(); }
    bet += bj.bet; ret += bj.result.payout;
  }
  return { bet, ret, rtp: +(ret / bet).toFixed(4), edge: +(1 - ret / bet).toFixed(4) };
}
