/**
 * shop.js — iqtisod: do'kon, savdogarlar, narxlar, orol ochish.
 */
import { CFG } from './balance.js';
import { BAITS, CHARMS, ISLANDS } from './fishData.js';
import { WEAPONS, upgradeCost } from './weapons.js';

export const VENDORS = {
  fishMarket: { name: 'Fish Market', mult: 1.00, cap: 60, desc: 'vendorFishMarket', mood: 1.0 },
  blackMarket:{ name: 'Black Market', mult: 1.45, cap: 18, desc: 'vendorBlackMarket', mood: 1.0 },
  gourmet:    { name: 'Gourmet Chef', mult: 1.25, cap: 30, desc: 'vendorGourmet', mood: 1.0 },
  pier:       { name: 'Pier Trader', mult: 0.85, cap: 999, desc: 'vendorPier', mood: 1.0 },
};

/** Asosiy savdo katalogi: qurol, yem, o'q, asbob. */
export function shopCatalog(state) {
  const items = [];
  // qurollar
  for (const [id, w] of Object.entries(WEAPONS)) {
    if (w.price <= 0) continue;
    const owned = !!state.weapons[id];
    items.push({ kind: 'weapon', id, name: w.name, price: w.price, owned, desc: w.desc, tag: 'weapon' });
  }
  // yem
  for (const b of BAITS) if (b.price > 0) items.push({ kind: 'bait', id: b.id, name: b.id, price: b.price, desc: `bait_${b.id}`, tag: 'bait' });
  // o'q
  for (const [k, p] of Object.entries(CFG.weapons.ammoPrices)) items.push({ kind: 'ammo', id: k, name: k, price: p, desc: `ammo_${k}`, tag: 'ammo', pack: 30 });
  // asboblar
  items.push({ kind: 'gear', id: 'cooler_xl', name: 'XL Cooler', price: 2400, desc: 'coolerXL', tag: 'gear', effect: { coolerCap: 30 } });
  items.push({ kind: 'gear', id: 'grill_pro', name: 'Pro Grill', price: 1800, desc: 'grillPro', tag: 'gear', effect: { grillMult: 2.1 } });
  items.push({ kind: 'gear', id: 'lantern_up', name: 'Lantern Upgrade', price: 650, desc: 'lanternUp', tag: 'gear', effect: { lantern: 1 } });
  items.push({ kind: 'gear', id: 'line_kit', name: 'Reinforced Line Kit', price: 900, desc: 'lineKit', tag: 'gear', effect: { lineHP: 0.5 } });
  items.push({ kind: 'gear', id: 'medkit', name: 'Medkit', price: 260, desc: 'medkit', tag: 'gear', effect: { heal: 60 } });
  items.push({ kind: 'gear', id: 'armor', name: 'Fishing Vest', price: 1500, desc: 'armor', tag: 'gear', effect: { armor: 40 } });
  return items;
}

export function charmCatalog() { return CHARMS.map((c) => ({ kind: 'charm', id: c.id, name: c.id, price: c.price, desc: c.desc, luck: c.luck, tag: 'charm' })); }

/** Xarid tranzaksiyasi. state = { money, weapons, levels, ammo, owned, cooler, lantern, ... } */
export function purchase(state, item, qty = 1) {
  const cost = item.price * qty;
  if (state.money < cost) return { ok: false, reason: 'no_money', cost };
  if (item.kind === 'weapon' && state.weapons[item.id]) return { ok: false, reason: 'owned' };
  state.money -= cost;
  switch (item.kind) {
    case 'weapon': state.weapons[item.id] = true; state.levels[item.id] = 1; break;
    case 'bait':   state.baitCounts[item.id] = (state.baitCounts[item.id] ?? 0) + qty * 10; break;
    case 'ammo':   state.ammo[item.id] = (state.ammo[item.id] ?? 0) + (item.pack ?? 30) * qty; break;
    case 'charm':  state.charms.push(item.id); break;
    case 'gear':
      state.owned.push(item.id);
      applyGear(state, item.effect);
      break;
  }
  return { ok: true, cost, money: state.money };
}

export function applyGear(state, effect) {
  if (!effect) return;
  if (effect.coolerCap) state.cooler.cap = Math.max(state.cooler.cap, effect.coolerCap);
  if (effect.grillMult) state.grillMult = effect.grillMult;
  if (effect.lantern) state.lantern.level += 1;
  if (effect.lineHP) state.lineHPBonus = (state.lineHPBonus ?? 0) + effect.lineHP;
  if (effect.heal) state.hp = Math.min(state.maxHP, state.hp + effect.heal);
  if (effect.armor) state.armor = Math.min(100, (state.armor ?? 0) + effect.armor);
}

/** Qurolni yangilash (25 darajagacha). */
export function upgradeWeapon(state, id) {
  if (!state.weapons[id]) return { ok: false, reason: 'not_owned' };
  const lv = state.levels[id] ?? 1;
  if (lv >= CFG.weapons.maxLevel) return { ok: false, reason: 'max_level' };
  const cost = upgradeCost(lv);
  if (state.money < cost) return { ok: false, reason: 'no_money', cost };
  state.money -= cost;
  state.levels[id] = lv + 1;
  return { ok: true, level: lv + 1, cost, money: state.money };
}

/** Baliqni sotish: savdogarning cheklangan sig'imi va kayfiyati hisobga olinadi. */
export function sellFish(state, vendorId, item, price) {
  const v = VENDORS[vendorId];
  if (!v) return { ok: false, reason: 'no_vendor' };
  state.vendorStock[vendorId] = state.vendorStock[vendorId] ?? v.cap;
  if (state.vendorStock[vendorId] <= 0) return { ok: false, reason: 'vendor_full' };
  state.vendorStock[vendorId] -= 1;
  const paid = Math.round(price * v.mood);
  state.money += paid;
  state.stats.sold += 1;
  state.stats.earned += paid;
  return { ok: true, money: paid, total: state.money };
}

export function restockVendors(state) {
  for (const [k, v] of Object.entries(VENDORS)) state.vendorStock[k] = v.cap;
  // kayfiyat biroz o'zgaradi (narx tebranishi)
  for (const v of Object.values(VENDORS)) v.mood = +(0.9 + Math.random() * 0.25).toFixed(2);
}

export function canUnlockIsland(state, islandId) {
  const isle = ISLANDS[islandId];
  if (!isle) return { ok: false, reason: 'none' };
  if (state.unlockedIslands.includes(islandId)) return { ok: false, reason: 'already' };
  const prevBoss = `boss_${islandId - 1}`;
  const bossOk = islandId === 0 || state.defeatedBosses.includes(islandId - 1);
  if (!bossOk) return { ok: false, reason: 'boss_required', need: prevBoss };
  if (state.money < isle.unlockCost) return { ok: false, reason: 'no_money', need: isle.unlockCost };
  return { ok: true, cost: isle.unlockCost };
}

export function unlockIsland(state, islandId) {
  const c = canUnlockIsland(state, islandId);
  if (!c.ok) return c;
  state.money -= c.cost;
  state.unlockedIslands.push(islandId);
  return { ok: true, island: islandId, money: state.money };
}
