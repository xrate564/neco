/**
 * luck.js — Omad tizimi (0..100) + Lucky Charm do'koni.
 */
import { CFG } from './balance.js';
import { CHARMS } from './fishData.js';

export class LuckSystem {
  constructor() { this.base = 0; this.charms = []; this.tempBoost = 0; }
  get value() {
    const charmLuck = this.charms.reduce((a, id) => a + (CHARMS.find((c) => c.id === id)?.luck ?? 0), 0);
    return Math.round(Math.min(CFG.luck.charmBonusCap, this.base + charmLuck + this.tempBoost));
  }
  /** 0..100 omad → noyob baliq ehtimoli. 100 da ~0.95. */
  get rareChance() { return CFG.luck.rareChanceAt(this.value); }
  buy(charmId, money) {
    const c = CHARMS.find((x) => x.id === charmId);
    if (!c) return { ok: false, reason: 'not_found' };
    if (this.charms.includes(charmId)) return { ok: false, reason: 'owned' };
    if (money < c.price) return { ok: false, reason: 'no_money' };
    this.charms.push(charmId);
    return { ok: true, cost: c.price, luck: this.value, rareChance: this.rareChance };
  }
  addTemp(amount, seconds) { this.tempBoost += amount; this._t = (this._t ?? 0) + seconds; }
  update(dt) { if (this._t > 0) { this._t -= dt; if (this._t <= 0) { this.tempBoost = 0; this._t = 0; } } }
  toJSON() { return { base: this.base, charms: [...this.charms] }; }
  static from(d) { const l = new LuckSystem(); l.base = d?.base ?? 0; l.charms = [...(d?.charms ?? [])]; return l; }
}

/** Baliqning "yulduzli/lucky" bo'lishi — narx bonusi. */
export function rollLuckyFish(luckValue, rnd = Math.random) {
  const p = 0.02 + luckValue / 3000;   // 100 omad → ~5.3%
  if (rnd() > p) return { lucky: false, mult: 1 };
  return { lucky: true, mult: 1.5 + rnd() * 1.5 };
}
