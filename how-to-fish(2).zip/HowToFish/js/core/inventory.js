/**
 * inventory.js — ko'chma sovutgich (20 baliq), panjara (grill), chiroq.
 */
import { CFG } from './balance.js';
import { fishPrice, SPECIES_BY_ID } from './fishData.js';
import { LANTERN_COLORS, LANTERN_MODES } from './fishData.js';

let _uid = 1;
export const uid = () => `f${Date.now().toString(36)}${(_uid++).toString(36)}`;

export class Cooler {
  constructor(cap = CFG.economy.coolerCapacity) { this.cap = cap; this.items = []; }
  get count() { return this.items.length; }
  get full() { return this.items.length >= this.cap; }
  add(entry) {
    if (this.full) return { ok: false, reason: 'full' };
    const it = { uid: uid(), cooked: false, ...entry };
    this.items.push(it);
    return { ok: true, item: it };
  }
  remove(u) { const i = this.items.findIndex((x) => x.uid === u); if (i < 0) return null; return this.items.splice(i, 1)[0]; }
  totalValue(vendor = 'fishMarket') {
    return this.items.reduce((a, it) => a + fishPrice({ species: it.speciesId, tier: it.tier, weight: it.weight, method: it.method, trickMult: it.trickMult ?? 1, vendor, cooked: it.cooked, lucky: it.luckyMult ?? 1 }), 0);
  }
  sellAll(vendor = 'fishMarket') {
    const v = this.totalValue(vendor);
    const list = this.items.splice(0, this.items.length);
    return { money: v, count: list.length, items: list };
  }
  toJSON() { return { cap: this.cap, items: this.items }; }
  static from(d) { const c = new Cooler(d?.cap); c.items = [...(d?.items ?? [])]; return c; }
}

/** Ko'chma panjara — baliqni pishirish (narx ×1.75, vaqt 4s). */
export class Grill {
  constructor() { this.queue = []; this.fuel = 100; }
  start(cooler, u) {
    const it = cooler.items.find((x) => x.uid === u);
    if (!it) return { ok: false, reason: 'not_found' };
    if (it.cooked) return { ok: false, reason: 'already_cooked' };
    if (this.fuel < 12) return { ok: false, reason: 'no_fuel' };
    this.fuel -= 12;
    this.queue.push({ uid: u, t: CFG.economy.grillTime });
    return { ok: true, time: CFG.economy.grillTime };
  }
  update(dt, cooler) {
    const done = [];
    for (const q of this.queue) {
      q.t -= dt;
      if (q.t <= 0) {
        const it = cooler.items.find((x) => x.uid === q.uid);
        if (it) { it.cooked = true; done.push(it); }
      }
    }
    this.queue = this.queue.filter((q) => q.t > 0);
    return done;
  }
  addFuel(n = 50) { this.fuel = Math.min(100, this.fuel + n); }
  toJSON() { return { fuel: this.fuel }; }
  static from(d) { const g = new Grill(); g.fuel = d?.fuel ?? 100; return g; }
}

/** Ko'chma chiroq: rang, yorqinlik, rejimlar. */
export class Lantern {
  constructor() { this.on = false; this.mode = 'mid'; this.color = LANTERN_COLORS[0]; this.battery = 100; this.level = 1; }
  get modes() { return LANTERN_MODES; }
  get colors() { return LANTERN_COLORS; }
  toggle() { this.on = !this.on; return this.on; }
  cycleMode() { const i = LANTERN_MODES.indexOf(this.mode); this.mode = LANTERN_MODES[(i + 1) % LANTERN_MODES.length]; this.on = this.mode !== 'off'; return this.mode; }
  setColor(hex) { if (LANTERN_COLORS.includes(hex)) this.color = hex; return this.color; }
  get intensity() { return { off: 0, low: 0.5, mid: 1, high: 1.7, strobe: 1.4 }[this.mode] * (1 + (this.level - 1) * 0.12); }
  get range() { return CFG.economy.lanternBase.range * (1 + (this.level - 1) * 0.1); }
  update(dt, strobePhase = 0) {
    if (!this.on) return;
    const drain = { off: 0, low: 0.25, mid: 0.6, high: 1.1, strobe: 0.8 }[this.mode];
    this.battery = Math.max(0, this.battery - drain * dt);
    if (this.battery <= 0) this.on = false;
    this.strobe = this.mode === 'strobe' ? (Math.sin(strobePhase * 12) > 0 ? 1 : 0.05) : 1;
  }
  recharge() { this.battery = 100; }
  toJSON() { return { mode: this.mode, color: this.color, battery: this.battery, level: this.level }; }
  static from(d) { const l = new Lantern(); Object.assign(l, d ?? {}); return l; }
}

export function makeCatchEntry(catchData, ctx = {}) {
  const sp = typeof catchData.speciesId === 'string' ? SPECIES_BY_ID[catchData.speciesId] : catchData.speciesId;
  return {
    speciesId: sp.id,
    tier: catchData.tier,
    weight: catchData.weight,
    method: ctx.method ?? 'rod',
    trickMult: ctx.trickMult ?? 1,
    trickParts: ctx.trickParts ?? [],
    luckyMult: ctx.luckyMult ?? 1,
    island: ctx.island ?? 0,
    ts: Date.now(),
  };
}
