/**
 * weapons.js — 7 qurol, har biri 25 daraja, o'ldirish usuli + trick-shot bonuslari.
 */
import { CFG, WEAPON_IDS } from './balance.js';

export const WEAPONS = {
  rod: {
    name: 'Fishing Rod', kind: 'tool', dmg: 0, rpm: 0, mag: 0, range: 0, ammo: null,
    spread: 0, recoil: 0, price: 0,
    upgrades: { lineStrength: 6, castDistance: 0.03, reelSpeed: 0.035 },
    desc: 'rod',
  },
  fist: {
    name: 'Fists', kind: 'melee', dmg: 14, rpm: 130, mag: 0, range: 2.0, ammo: null,
    spread: 0, recoil: 0.05, price: 0, desc: 'fist',
  },
  knife: {
    name: 'Bowie Knife', kind: 'melee', dmg: 46, rpm: 150, mag: 0, range: 2.6, ammo: null,
    spread: 0, recoil: 0.04, price: 320, desc: 'knife',
  },
  pistol: {
    name: 'Ranger 9mm', kind: 'hitscan', dmg: 26, rpm: 420, mag: 12, range: 55, ammo: 'pistol',
    spread: 0.014, recoil: 0.055, price: 900, desc: 'pistol',
  },
  rifle: {
    name: 'Hunter .308', kind: 'hitscan', dmg: 78, rpm: 62, mag: 5, range: 160, ammo: 'rifle',
    spread: 0.004, recoil: 0.16, price: 2600, desc: 'rifle',
  },
  auto: {
    name: 'Tide AR-15', kind: 'hitscan', dmg: 34, rpm: 640, mag: 30, range: 110, ammo: 'auto',
    spread: 0.021, recoil: 0.075, price: 5200, desc: 'auto',
  },
  sniper: {
    name: 'Abyss .50', kind: 'hitscan', dmg: 210, rpm: 40, mag: 5, range: 320, ammo: 'sniper',
    spread: 0.0008, recoil: 0.32, price: 12500, desc: 'sniper', scoped: true,
  },
};

export function weaponLevelDmg(id, level) {
  const w = WEAPONS[id];
  if (!w) return 0;
  return +(w.dmg * (1 + (level - 1) * CFG.weapons.upgradeGain)).toFixed(1);
}
export function upgradeCost(level) {
  if (level >= CFG.weapons.maxLevel) return Infinity;
  return CFG.weapons.upgradeCost(level - 1);
}
/** 1..25 daraja uchun umumiy stat jadvali. */
export function weaponStats(id, level) {
  const w = WEAPONS[id];
  const k = 1 + (level - 1) * CFG.weapons.upgradeGain;
  return {
    id, level, name: w.name, kind: w.kind,
    dmg: +(w.dmg * k).toFixed(1),
    rpm: Math.round(w.rpm * (1 + (level - 1) * 0.012)),
    mag: w.mag ? Math.round(w.mag * (1 + (level - 1) * 0.016)) : 0,
    range: +(w.range * (1 + (level - 1) * 0.01)).toFixed(1),
    spread: +(w.spread * (1 - (level - 1) * 0.012)).toFixed(5),
    recoil: +(w.recoil * (1 - (level - 1) * 0.01)).toFixed(4),
    ammo: w.ammo, scoped: !!w.scoped,
  };
}

/**
 * O'q traektoriyasi: masofa bilan zarar pasayishi + headshot + trick-shot.
 * @param {object} ctx {weaponId, level, distance, headshot, scoped, playerAirborne, fishAirborne, moving, crouched, timeSinceAim}
 */
export function shotDamage(ctx) {
  const s = weaponStats(ctx.weaponId, ctx.level || 1);
  const w = WEAPONS[ctx.weaponId];
  let dmg = s.dmg;
  const falloff = 1 - Math.min(0.55, Math.max(0, ctx.distance - s.range * 0.35) / (s.range || 1));
  dmg *= falloff;
  if (ctx.headshot) dmg *= 1.6;
  if (w.scoped && ctx.scoped) dmg *= 1.15;
  return Math.round(dmg);
}

/** Trick-shot baholash → multiplikator + sabablar ro'yxati. */
export function trickShot(ctx) {
  const parts = [];
  let m = 1;
  const add = (mult, key) => { m *= mult; parts.push(key); };
  if (ctx.headshot) add(1.5, 'headshot');
  if (!ctx.scoped && WEAPONS[ctx.weaponId]?.scoped && ctx.distance > 25) add(2.0, 'noscope');
  if (ctx.playerAirborne) add(2.2, 'midair');
  if (ctx.fishAirborne) add(2.0, 'airborneTarget');
  if (ctx.distance > 80) add(1.8, 'longshot');
  else if (ctx.distance > 45) add(1.35, 'longshot');
  if (ctx.moving && ctx.distance > 25) add(1.4, 'runngun');
  if (ctx.weakspot) add(1.6, 'weakspot');
  return { mult: Math.min(CFG.kill.trickShotMaxMult, m), parts };
}

/** Yakuniy narx multiplikatori: usul × trick-shot. */
export function valueMultiplier(weaponId, trickMult = 1) {
  return (CFG.kill.methodMult[weaponId] ?? 1) * trickMult;
}

/** Baliqning "qurollangan"ligi: u ham o'q otadi. */
export function armedFishShot(species, distance, rnd = Math.random) {
  if (!species.armed) return null;
  const wid = species.armedWeapon || 'pistol';
  const s = weaponStats(wid, 6);
  const hitChance = Math.max(0.05, 0.75 - distance / 60);
  if (rnd() > hitChance) return { hit: false, dmg: 0, weapon: wid };
  return { hit: true, dmg: Math.round(s.dmg * 0.45), weapon: wid };
}

export const WEAPON_LIST = WEAPON_IDS.map((id, i) => ({ id, slot: i + 1, ...WEAPONS[id] }));
