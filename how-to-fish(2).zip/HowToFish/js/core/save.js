/**
 * save.js — holatni yaratish / seriyalash / tiklash (Yandex Cloud ≤200 KB).
 */
import { CFG } from './balance.js';
import { ISLANDS, SPECIES } from './fishData.js';
import { WEAPONS } from './weapons.js';
import { Cooler, Grill, Lantern } from './inventory.js';
import { LuckSystem } from './luck.js';

export function createInitialState() {
  return {
    version: 1,
    money: CFG.money.start,
    hp: CFG.player.maxHP, maxHP: CFG.player.maxHP, armor: 0,
    island: 0,
    unlockedIslands: [0],
    defeatedBosses: [],
    weapons: { rod: true, fist: true },
    levels: { rod: 1, fist: 1 },
    ammo: {},
    baitCounts: { worm: 20 },
    bait: 'worm',
    owned: [],
    charms: [],
    lineHPBonus: 0,
    grillMult: CFG.economy.grillMult,
    vendorStock: {},
    stats: { caught: 0, sold: 0, earned: 0, spent: 0, kills: 0, deaths: 0, biggest: 0, best: null, casinoWon: 0, casinoLost: 0, playtime: 0 },
    codex: {},           // speciesId → { count, best, bestTier }
    settings: { lang: 'uz', master: 0.8, sfx: 0.9, music: 0.35, sens: 1, invertY: false, fov: 75, quality: 'high', pvp: true },
    day: 1, hour: CFG.time.startHour,
  };
}

export class GameState {
  constructor(data) {
    Object.assign(this, createInitialState(), data ?? {});
    this.cooler = Cooler.from(data?.cooler);
    this.grill = Grill.from(data?.grill);
    this.lantern = Lantern.from(data?.lantern);
    this.luck = LuckSystem.from(data?.luck);
  }
  /** Faqat saqlanadigan maydonlar (ob'ekt/instanslarni oddiy JSON ga aylantiradi). */
  toJSON() {
    const { cooler, grill, lantern, luck, ...rest } = this;
    return {
      ...rest,
      cooler: cooler.toJSON(), grill: grill.toJSON(), lantern: lantern.toJSON(), luck: luck.toJSON(),
    };
  }
  serialize() { return JSON.stringify(this.toJSON()); }
  byteSize() { return new TextEncoder().encode(this.serialize()).length; }
  static fromJSON(str) { return new GameState(JSON.parse(str)); }

  addCatch(entry, price) {
    this.stats.caught += 1;
    if (entry.weight > this.stats.biggest) { this.stats.biggest = entry.weight; this.stats.best = { speciesId: entry.speciesId, tier: entry.tier, weight: entry.weight }; }
    const c = this.codex[entry.speciesId] ?? { count: 0, best: 0, bestTier: 'Plump' };
    c.count += 1;
    if (entry.weight > c.best) { c.best = entry.weight; c.bestTier = entry.tier; }
    this.codex[entry.speciesId] = c;
    return price;
  }
  codexProgress() {
    const seen = Object.keys(this.codex).length;
    return { seen, total: SPECIES.length, pct: +(seen / SPECIES.length * 100).toFixed(1) };
  }
}

/** Yandex Cloud chegarasini tekshirish. */
export function fitsYandexCloud(state) {
  const bytes = state.byteSize();
  return { bytes, kb: +(bytes / 1024).toFixed(2), ok: bytes <= CFG.save.yandexCloudMaxKB * 1024, limitKB: CFG.save.yandexCloudMaxKB };
}

const KEY = CFG.save.key;
export function localSave(state) {
  try { localStorage.setItem(KEY, state.serialize()); return { ok: true }; }
  catch (e) { return { ok: false, error: String(e) }; }
}
export function localLoad() {
  try {
    const s = localStorage.getItem(KEY);
    return s ? GameState.fromJSON(s) : null;
  } catch (e) { return null; }
}
