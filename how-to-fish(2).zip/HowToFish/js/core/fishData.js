/**
 * fishData.js — 52 baliq turi + 6 boss.
 * basePrice = 1.0 kg narxi ($). rarity + size + usul multiplikatorlari ustiga qo'yiladi.
 * islands: qaysi orollarda uchraydi (0-based index).
 * armed: true → baliq o'q otadi (qurollangan).
 */
import { CFG, SIZE_ORDER, RARITY_ORDER } from './balance.js';

const F = (id, name, rarity, kgMin, kgMax, basePrice, islands, opt = {}) => ({
  id, name, rarity, kgMin, kgMax, basePrice, islands,
  fight: opt.fight ?? 1.0,          // qarshilik kuchi (0.4 .. 2.5)
  speed: opt.speed ?? 1.0,
  armed: !!opt.armed,
  armedWeapon: opt.armedWeapon ?? null,
  depth: opt.depth ?? 'any',        // shallow | mid | deep | any
  biomes: opt.biomes ?? ['fresh'],
  night: opt.night ?? false,
});

export const SPECIES = [
  // ---------- COMMON (16) ----------
  F('perch', 'Perch', 'Common', 0.2, 1.4, 6, [0, 1, 3], { biomes: ['fresh'] }),
  F('roach', 'Roach', 'Common', 0.1, 0.9, 4, [0, 1, 3]),
  F('rudd', 'Rudd', 'Common', 0.1, 1.0, 4.5, [0]),
  F('bleak', 'Bleak', 'Common', 0.05, 0.3, 3, [0, 1, 3]),
  F('gudgeon', 'Gudgeon', 'Common', 0.05, 0.25, 3, [0, 3]),
  F('gudgeon_stone', 'Stone Loach', 'Common', 0.05, 0.2, 3.5, [0, 3, 4]),
  F('crucian', 'Crucian Carp', 'Common', 0.2, 1.8, 7, [0, 1, 3]),
  F('bream_small', 'Silver Bream', 'Common', 0.2, 1.6, 6, [0, 1, 3]),
  F('minnow', 'Minnow', 'Common', 0.02, 0.15, 2, [0, 1, 3, 4]),
  F('sunfish', 'Pumpkinseed', 'Common', 0.1, 0.7, 5, [0, 1]),
  F('sardine', 'Sardine', 'Common', 0.03, 0.2, 2.5, [2, 5], { biomes: ['salt'] }),
  F('anchovy', 'Anchovy', 'Common', 0.02, 0.12, 2, [2, 5], { biomes: ['salt'] }),
  F('herring', 'Herring', 'Common', 0.1, 0.6, 5, [2, 5], { biomes: ['salt'] }),
  F('mackerel', 'Mackerel', 'Common', 0.3, 1.6, 9, [2, 5], { biomes: ['salt'] }),
  F('goby', 'Round Goby', 'Common', 0.05, 0.35, 3.5, [0, 3]),
  F('sleeper', 'Sleeper Goby', 'Common', 0.05, 0.4, 3.5, [2, 5], { biomes: ['salt'] }),

  // ---------- UNCOMMON (14) ----------
  F('tench', 'Tench', 'Uncommon', 0.5, 3.2, 12, [0, 1, 3], { fight: 1.2 }),
  F('bream', 'Common Bream', 'Uncommon', 0.6, 4.0, 13, [0, 1, 3], { fight: 1.15 }),
  F('carp', 'Common Carp', 'Uncommon', 1.0, 12.0, 16, [0, 1, 3], { fight: 1.6 }),
  F('mirror_carp', 'Mirror Carp', 'Uncommon', 1.2, 16.0, 21, [0, 1], { fight: 1.8 }),
  F('grass_carp', 'Grass Carp', 'Uncommon', 1.5, 20.0, 19, [0, 3], { fight: 1.9 }),
  F('chub', 'Chub', 'Uncommon', 0.4, 3.5, 11, [1, 4], { fight: 1.3 }),
  F('barbel', 'Barbel', 'Uncommon', 0.5, 5.0, 15, [4, 3], { fight: 1.5 }),
  F('grayling', 'Grayling', 'Uncommon', 0.3, 2.0, 14, [1, 4], { speed: 1.5 }),
  F('trout_brown', 'Brown Trout', 'Uncommon', 0.4, 4.5, 22, [1, 4], { speed: 1.5 }),
  F('whitefish', 'Whitefish', 'Uncommon', 0.5, 4.0, 20, [1, 4], { speed: 1.4 }),
  F('cod', 'Atlantic Cod', 'Uncommon', 1.0, 15.0, 18, [5], { biomes: ['salt'], depth: 'deep' }),
  F('pollock', 'Pollock', 'Uncommon', 0.8, 9.0, 15, [5], { biomes: ['salt'], depth: 'mid' }),
  F('hake', 'Hake', 'Uncommon', 0.6, 6.0, 14, [5], { biomes: ['salt'], depth: 'deep' }),
  F('redfish', 'Red Snapper', 'Uncommon', 0.8, 8.0, 26, [2, 5], { biomes: ['salt'] }),

  // ---------- RARE (10) ----------
  F('pike', 'Northern Pike', 'Rare', 1.0, 22.0, 34, [0, 1, 3], { fight: 2.0, speed: 1.6 }),
  F('zander', 'Zander', 'Rare', 1.0, 14.0, 38, [0, 1, 3], { fight: 1.8, night: true }),
  F('catfish_small', 'Channel Catfish', 'Rare', 1.5, 20.0, 36, [0, 3], { fight: 1.9, night: true }),
  F('bass', 'Largemouth Bass', 'Rare', 0.8, 7.0, 30, [0, 3], { fight: 1.7 }),
  F('salmon', 'Atlantic Salmon', 'Rare', 2.0, 26.0, 52, [1, 4], { fight: 2.2, speed: 1.7 }),
  F('sturgeon_small', 'Sterlet', 'Rare', 1.0, 12.0, 60, [4], { fight: 2.0 }),
  F('eel', 'European Eel', 'Rare', 0.5, 6.0, 44, [0, 3], { fight: 1.6, night: true }),
  F('swordfish_young', 'Young Swordfish', 'Rare', 15, 90, 70, [2, 5], { biomes: ['salt'], fight: 2.3, speed: 1.8 }),
  F('tuna_yellow', 'Yellowfin Tuna', 'Rare', 20, 140, 78, [2, 5], { biomes: ['salt'], fight: 2.4, speed: 1.9 }),
  F('wreckfish', 'Wreckfish', 'Rare', 5, 40, 55, [5], { biomes: ['salt'], depth: 'deep' }),

  // ---------- EPIC (6) ----------
  F('muskellunge', 'Muskellunge', 'Epic', 4, 32, 120, [1, 4], { fight: 2.5, speed: 1.7 }),
  F('arapaima', 'Arapaima', 'Epic', 30, 200, 190, [3], { fight: 2.6 }),
  F('wels', 'Wels Catfish', 'Epic', 10, 130, 165, [0, 3], { fight: 2.4, night: true }),
  F('grouper', 'Giant Grouper', 'Epic', 40, 300, 210, [2, 5], { biomes: ['salt'], depth: 'deep', fight: 2.5, armed: true, armedWeapon: 'pistol' }),
  F('marlin_blue', 'Blue Marlin', 'Epic', 80, 500, 260, [2, 5], { biomes: ['salt'], fight: 2.8, speed: 2.1, armed: true, armedWeapon: 'rifle' }),
  F('halibut', 'Atlantic Halibut', 'Epic', 30, 260, 175, [5], { biomes: ['salt'], depth: 'deep', fight: 2.3 }),

  // ---------- LEGENDARY (4) ----------
  F('tuna_bluefin', 'Bluefin Tuna', 'Legendary', 100, 680, 620, [2, 5], { biomes: ['salt'], fight: 3.2, speed: 2.2, armed: true, armedWeapon: 'rifle' }),
  F('gt', 'Giant Trevally', 'Legendary', 20, 90, 480, [2, 5], { biomes: ['salt'], fight: 3.0, speed: 2.0, armed: true, armedWeapon: 'auto' }),
  F('sturgeon_beluga', 'Beluga Sturgeon', 'Legendary', 60, 900, 900, [4], { fight: 3.4, night: true }),
  F('oarfish', 'Giant Oarfish', 'Legendary', 80, 270, 760, [5], { biomes: ['salt'], depth: 'deep', fight: 2.9 }),

  // ---------- MYTHIC (2) ----------
  F('coelacanth', 'Coelacanth', 'Mythic', 30, 95, 2400, [5], { biomes: ['salt'], depth: 'deep', fight: 3.6, armed: true, armedWeapon: 'sniper' }),
  F('megalodon', 'Megalodon', 'Mythic', 400, 4200, 5200, [2, 5], { biomes: ['salt'], depth: 'deep', fight: 4.2, speed: 1.6, armed: true, armedWeapon: 'auto' }),
];

export const SPECIES_BY_ID = Object.fromEntries(SPECIES.map((s) => [s.id, s]));

/** Bosslar — har bir orolda bittadan. defeat → keyingi orol ochiladi. */
export const BOSSES = [
  { id: 'boss_catfish_king', island: 0, name: 'Catfish King', hp: 900, kg: 190, price: 1400, rarity: 'Legendary',
    attacks: ['charge', 'summon', 'whirlpool'], color: 0x5b4a2f },
  { id: 'boss_ice_pike_queen', island: 1, name: 'Ice Pike Queen', hp: 1500, kg: 260, price: 2600, rarity: 'Legendary',
    attacks: ['charge', 'frost_breath', 'summon'], color: 0x9fd8ff },
  { id: 'boss_shark_titan', island: 2, name: 'Shark Titan', hp: 2600, kg: 1400, price: 6800, rarity: 'Mythic',
    attacks: ['charge', 'ink', 'tail_slam', 'summon'], color: 0x6f7f8c, armed: true, armedWeapon: 'auto' },
  { id: 'boss_swamp_leviathan', island: 3, name: 'Swamp Leviathan', hp: 4200, kg: 2100, price: 11500, rarity: 'Mythic',
    attacks: ['charge', 'acid_spit', 'whirlpool', 'summon'], color: 0x3f6b3a, armed: true, armedWeapon: 'rifle' },
  { id: 'boss_storm_ancient', island: 4, name: 'Storm Ancient', hp: 7000, kg: 3400, price: 19000, rarity: 'Mythic',
    attacks: ['charge', 'lightning', 'summon', 'tail_slam'], color: 0x37415c, armed: true, armedWeapon: 'sniper' },
  { id: 'boss_abyss_emperor', island: 5, name: 'Abyss Emperor', hp: 12000, kg: 6200, price: 40000, rarity: 'Mythic',
    attacks: ['charge', 'ink', 'lightning', 'acid_spit', 'summon'], color: 0x1b1f2b, armed: true, armedWeapon: 'sniper' },
];
export const BOSS_BY_ISLAND = Object.fromEntries(BOSSES.map((b) => [b.island, b]));

/** Orollar: iqlim, baliq hovuzi, narx darajasi. */
export const ISLANDS = [
  { id: 0, name: 'Reed Lake',      biome: 'fresh', climate: 'temperate', size: 190, unlockCost: 0,
    weathers: ['clear', 'cloudy', 'rain', 'thunder'], vendors: ['fishMarket', 'pier'], desc: 'reedLake' },
  { id: 1, name: 'Cold Pine Bay',  biome: 'fresh', climate: 'cold',      size: 210, unlockCost: 1500,
    weathers: ['clear', 'cloudy', 'snow', 'wind'], vendors: ['fishMarket'], desc: 'coldPine' },
  { id: 2, name: 'Sunburn Atoll',  biome: 'salt',  climate: 'tropical',  size: 240, unlockCost: 6000,
    weathers: ['clear', 'rain', 'thunder', 'storm'], vendors: ['fishMarket', 'blackMarket'], desc: 'sunburn' },
  { id: 3, name: 'Foggy Swamp',    biome: 'fresh', climate: 'humid',     size: 200, unlockCost: 14000,
    weathers: ['fog', 'rain', 'thunder'], vendors: ['blackMarket', 'gourmet'], desc: 'foggySwamp' },
  { id: 4, name: 'Storm Peak',     biome: 'fresh', climate: 'alpine',    size: 180, unlockCost: 32000,
    weathers: ['storm', 'snow', 'wind', 'clear'], vendors: ['gourmet'], desc: 'stormPeak' },
  { id: 5, name: 'Deep Abyss',     biome: 'salt',  climate: 'abyssal',   size: 300, unlockCost: 80000,
    weathers: ['storm', 'fog', 'clear'], vendors: ['blackMarket', 'gourmet'], desc: 'deepAbyss' },
];

/** Yem (bait) — tishlash tezligi va noyoblik bonusi. */
export const BAITS = [
  { id: 'none',  price: 0 },
  { id: 'worm',  price: 8 },
  { id: 'shrimp',price: 26 },
  { id: 'glow',  price: 70 },
  { id: 'magic', price: 220 },
];

/** Omad tumori'lari (Lucky Charm do'koni). */
export const CHARMS = [
  { id: 'rabbit_foot', price: 400,   luck: 8,  desc: 'rabbitFoot' },
  { id: 'four_leaf',   price: 1200,  luck: 16, desc: 'fourLeaf' },
  { id: 'golden_hook', price: 3400,  luck: 26, desc: 'goldenHook' },
  { id: 'mermaid_tear',price: 8200,  luck: 38, desc: 'mermaidTear' },
  { id: 'dragon_scale',price: 19500, luck: 55, desc: 'dragonScale' },
  { id: 'kraken_eye',  price: 46000, luck: 80, desc: 'krakenEye' },
];

export const LANTERN_MODES = ['off', 'low', 'mid', 'high', 'strobe'];
export const LANTERN_COLORS = ['#fff2c4', '#ffd08a', '#8ad7ff', '#b0ff9e', '#ff8ad7'];

/* ---------- sofs matematik helperlar ---------- */

export const rollWeighted = (arr, keyFn, rnd = Math.random) => {
  const total = arr.reduce((a, x) => a + Math.max(0, keyFn(x)), 0);
  if (total <= 0) return arr[0];
  let r = rnd() * total;
  for (const x of arr) { r -= Math.max(0, keyFn(x)); if (r <= 0) return x; }
  return arr[arr.length - 1];
};

/** Hajm sinfini tortib olish: katta baliqlar kamroq, omad bilan ko'proq. */
export function rollSizeTier(luck = 0, rnd = Math.random) {
  const w = [
    46 - luck * 0.22,
    26 - luck * 0.08,
    15 + luck * 0.05,
    8 + luck * 0.09,
    3.6 + luck * 0.1,
    1.4 + luck * 0.1,
  ];
  return rollWeighted(SIZE_ORDER, (_, i) => w[i], rnd);
}

/** Orldagi hovuzdan tur tanlash (omad + yem + ob-havo hisobga olinadi). */
export function pickSpecies({ island = 0, luck = 0, bait = 'none', weather = 'clear', hour = 6, biomeFilter = null, rnd = Math.random } = {}) {
  const isle = ISLANDS[island] ?? ISLANDS[0];
  let pool = SPECIES.filter((s) => s.islands.includes(isle.id));
  if (biomeFilter) pool = pool.filter((s) => s.biomes.includes(biomeFilter));
  if (!pool.length) pool = SPECIES.filter((s) => s.islands.includes(isle.id) || s.islands.includes(0));

  const rareTarget = CFG.luck.rareChanceAt(luck);
  const boost = CFG.fishing.bite.baitRarityBoost[bait] ?? 0;

  const weightOf = (s) => {
    const R = CFG.rarity[s.rarity];
    let w = R.weight;
    if (R.rare) w *= 1 + rareTarget * 6 + boost * 8;
    else w *= 1 - Math.min(0.75, rareTarget * 0.7 + boost);
    // tungi baliqlar kechqurun ko'proq
    const nightish = hour < 6 || hour >= 19;
    if (s.night) w *= nightish ? 2.4 : 0.55;
    // ob-havo
    if (weather === 'rain') w *= s.rarity === 'Common' ? 0.85 : 1.25;
    if (weather === 'thunder' || weather === 'storm') w *= s.rarity === 'Mythic' ? 1.9 : 0.9;
    if (weather === 'snow') w *= s.biomes.includes('salt') ? 0.7 : 1.15;
    if (weather === 'fog') w *= 0.9;
    if (isle.climate === 'tropical' && s.biomes.includes('salt')) w *= 1.15;
    return Math.max(0.01, w);
  };
  return rollWeighted(pool, weightOf, rnd);
}

/** Yakuniy og'irlik (size tier + tur oralig'i). */
export function rollWeight(sp, tier, rnd = Math.random) {
  const st = CFG.sizes[tier] ?? CFG.sizes.Plump;
  const lo = Math.max(sp.kgMin, sp.kgMin * st.min);
  const hi = Math.max(lo + 0.01, Math.min(sp.kgMax * st.max, sp.kgMax * 2.2));
  const t = rnd() * rnd(); // kichikroq tomonga og'ish
  return +(lo + (hi - lo) * t).toFixed(2);
}

/** Sotish narxi. */
export function fishPrice({ species, tier, weight, method = 'rod', trickMult = 1, vendor = 'fishMarket', cooked = false, lucky = 1 }) {
  const sp = typeof species === 'string' ? SPECIES_BY_ID[species] : species;
  const st = CFG.sizes[tier] ?? CFG.sizes.Plump;
  const R = CFG.rarity[sp.rarity];
  let p = sp.basePrice * weight * st.priceMult * R.priceMult * CFG.kill.methodMult[method] * trickMult;
  if (sp.rarity === 'Mythic') p *= CFG.rarity.mythicValueBonus;   // Mythic = 50×
  if (cooked) p *= CFG.economy.grillMult;
  p *= CFG.economy.vendorMult[vendor] ?? 1;
  p *= lucky;
  return Math.round(p);
}
