/**
 * balance.js — butun o'yin balansi bitta joyda.
 * Bu fayl DOM/Three.js ga bog'liq emas → Node testlari to'g'ridan-to'g'ri tekshiradi.
 */

export const CFG = {
  money: { start: 500, symbol: '$' },

  player: {
    maxHP: 100, hpRegen: 1.2,           // HP / sekund (5 sekund zararsiz o'tgach)
    stamina: 100, sprintDrain: 18, staminaRegen: 9,
    walkSpeed: 3.4, sprintSpeed: 6.4, crouchSpeed: 1.7,
    eyeHeight: 1.68, radius: 0.4,
  },

  fishing: {
    bite: {
      baseMin: 3.0, baseMax: 14.0,       // sekund (multiplikatorlardan oldin)
      baitMult: { none: 1.0, worm: 0.85, shrimp: 0.65, glow: 0.45, magic: 0.3 },
      baitRarityBoost: { none: 0, worm: 0.05, shrimp: 0.12, glow: 0.2, magic: 0.35 },
    },
    strikeWindow: 1.1,                   // sekund — "!" paydo bo'lgach bosish oynasi
    fight: {
      zoneBase: 0.46,                    // zonaning asosiy kengligi (bar ulushi)
      zoneMinByWeight: 0.13,             // eng katta baliq uchun zona
      reelSpeed: 0.45,                   // sekundiga progress (zona ichida)
      slipSpeed: 0.13,                   // zona tashqarisida progress yo'qotish
      tensionGain: 0.40,                 // sekundiga (bosib turganda)
      tensionRelease: 0.60,              // sekundiga (qo'yib yuborganda)
      tensionMax: 1.0,
      lineSnapTension: 1.0,
      escapeProgress: 0.0,               // progress 0 ga tushsa baliq qochadi
      pumpBonus: 0.045,                  // har bir "pump" (qo'yib yuborib qayta bosish) progress bonusi
      pumpRelief: 0.10,                  // pump tension ni kamaytiradi
      linePerFishHP: 0.0000015,          // baliq "HP" dan chiziqqa zarar (tension×dt)
      escapeTime: 75,                    // sekund — taym aut
    },
    rod: {
      castPowerMin: 0.35, castPowerMax: 1.0,
      castDistanceMin: 6, castDistanceMax: 34,
      lineStrengthBase: 100,             // chiziq mustahkamligi (yangilanish bilan o'sadi)
      reelLevels: 25,
    },
  },

  sizes: {
    // Hajm sinflari: og'irlik oralig'i × narx multiplikatori
    Plump:    { min: 0.7,  max: 1.15, priceMult: 1.0,  len: 0.85 },
    Hefty:    { min: 1.15, max: 1.6,  priceMult: 1.6,  len: 1.0  },
    Massive:  { min: 1.6,  max: 2.4,  priceMult: 2.6,  len: 1.25 },
    Colossal: { min: 2.4,  max: 3.6,  priceMult: 4.5,  len: 1.6  },
    Leviathan:{ min: 3.6,  max: 5.2,  priceMult: 8.0,  len: 2.1  },
    Mythic:   { min: 5.2,  max: 7.0,  priceMult: 14.0, len: 2.8  },
  },

  rarity: {
    // Kamdan-kam uchraydiganlik: bazaviy vazn va omad ta'siri
    Common:    { weight: 62, rare: false, color: '#9aa7b0', priceMult: 1.0 },
    Uncommon:  { weight: 24, rare: false, color: '#6ee86e', priceMult: 1.8 },
    Rare:      { weight: 9,  rare: true,  color: '#4ab8ff', priceMult: 3.5 },
    Epic:      { weight: 3.4,rare: true,  color: '#c07bff', priceMult: 7.0 },
    Legendary: { weight: 1.2,rare: true,  color: '#ffb02e', priceMult: 16.0 },
    Mythic:    { weight: 0.4,rare: true,  color: '#ff4fd8', priceMult: 34.0 },
    mythicValueBonus: 50,  // "Mythic baliq 50× qimmat" — qo'shimcha bonus
  },

  weapons: {
    maxLevel: 25,
    upgradeCost: (lv) => Math.round(120 * Math.pow(1.22, lv)), // lv 0..24
    upgradeGain: 0.09,          // har daraja +9% zarar
    ammoPrices: { pistol: 4, rifle: 7, auto: 5, sniper: 22 },
  },

  kill: {
    // O'ldirish usuli narxga ta'siri
    methodMult: { rod: 1.0, knife: 2.0, fist: 1.75, pistol: 1.1, rifle: 1.15, auto: 1.05, sniper: 1.6 },
    trickShotMaxMult: 12.0,
  },

  economy: {
    vendorMult: { fishMarket: 1.00, blackMarket: 1.45, gourmet: 1.25, pier: 0.85 },
    vendorStock: { fishMarket: 60, blackMarket: 18, gourmet: 30, pier: 999 },
    grillMult: 1.75, grillTime: 4.0,
    coolerCapacity: 20,
    lanternBase: { range: 14, modes: 3 },
  },

  luck: {
    // 100 omad → 95% noyob baliq
    rareChanceAt: (luck) => 0.05 + 0.9 * Math.pow(luck / 100, 1.15),
    decayPerDay: 6,
    charmBonusCap: 100,
  },

  time: {
    dayLengthSec: 480,      // 8 minut = 1 kun
    startHour: 6,
    biteByHour: {           // soat → tishlash multiplikatori
      night: 0.7, dawn: 1.35, day: 1.0, dusk: 1.45,
    },
  },

  multiplayer: { maxPlayers: 4, tickHz: 20, pvpDamage: true },

  save: { key: 'howtofish_save_v1', yandexCloudMaxKB: 200 },
};

export const SIZE_ORDER = ['Plump', 'Hefty', 'Massive', 'Colossal', 'Leviathan', 'Mythic'];
export const RARITY_ORDER = ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary', 'Mythic'];
export const WEAPON_IDS = ['rod', 'fist', 'knife', 'pistol', 'rifle', 'auto', 'sniper'];
