/**
 * fishing.js — qarmoq otish + tension mini-o'yini. 100% sof mantiq.
 *
 * Holatlar: idle → windup → airborne → sinking → waiting → strike → fight → done
 * updateFight() hech qachon Three.js/DOM ga tegmaydi → Node testida tekshiriladi.
 */
import { CFG, SIZE_ORDER } from './balance.js';
import { SPECIES_BY_ID, rollWeight, rollSizeTier, pickSpecies } from './fishData.js';

export const FISH_STATES = ['idle', 'windup', 'airborne', 'sinking', 'waiting', 'strike', 'fight', 'reeling_in', 'done'];

export function createFight({ speciesId, tier, luck = 0, rodLevel = 1, rnd = Math.random }) {
  const sp = SPECIES_BY_ID[speciesId];
  const weight = rollWeight(sp, tier, rnd);
  const F = CFG.fishing.fight;
  const fightPower = sp.fight * (0.85 + rnd() * 0.4) * (0.55 + (weight / Math.max(1, sp.kgMax)) ** 0.35 * 0.8);

  // Zona kengligi: katta/kuchli baliq → tor zona
  const sizeIdx = SIZE_ORDER.indexOf(tier);
  const zoneBase = Math.max(
    F.zoneMinByWeight,
    F.zoneBase * (1 - sizeIdx * 0.07) / (0.5 + fightPower * 0.26),
  );

  return {
    state: 'fight',
    speciesId, species: sp, tier, weight,
    fishHP: Math.max(1, Math.round(weight * (8 + sizeIdx * 6) * sp.fight)),
    progress: 0.12,          // 0..1 — tortib olish
    tension: 0.15,           // 0..1 — 1.0 da chiziq uziladi
    lineHP: 1,               // chiziq holati (1 = yangi)
    fishPos: 0.5,            // baliq markeri pozitsiyasi (0..1)
    zonePos: clamp(0.5 - zoneBase / 2, 0, 1 - zoneBase),
    zoneBase,
    zoneWidth: zoneBase,
    fightPower,
    reelSpeed: F.reelSpeed / (0.8 + fightPower * 0.4) * (1 + (rodLevel - 1) * 0.035),
    elapsed: 0,
    fishVel: (rnd() - 0.5) * 0.4,
    _wasReeling: false, pumps: 0,
    _dartCd: 0.8 + rnd() * 1.6,
    result: null,
  };
}

/**
 * @param {object} st  createFight() natijasi (o'zgartiriladi)
 * @param {number} dt  sekund
 * @param {{reeling?:boolean, zone?:number|null}} input
 *        reeling — sichqoncha bosib turilgan (tortish)
 *        zone    — sichqoncha X pozitsiyasi 0..1 (zonani boshqarish); null/undefined = avto-kuzatish
 * @returns {object} st
 */
export function updateFight(st, dt, input = {}) {
  if (st.state !== 'fight') return st;
  const F = CFG.fishing.fight;
  const reeling = !!input.reeling;
  st.elapsed += dt;

  /* --- baliq harakati: drift + vaqti-vaqti bilan "dart" --- */
  st._dartCd -= dt;
  if (st._dartCd <= 0) {
    const dir = rnd01() < 0.5 ? -1 : 1;
    st.fishVel = dir * (0.25 + rnd01() * 0.5) * (0.5 + Math.min(2.2, st.fightPower) * 0.3);
    st._dartCd = 0.8 + rnd01() * 2.4 / (0.6 + Math.min(2.2, st.fightPower) * 0.4);
  }
  st.fishVel *= (1 - dt * 0.5);                       // sekinlashish
  st.fishPos = clamp01(st.fishPos + st.fishVel * dt);
  if (st.fishPos <= 0.001 || st.fishPos >= 0.999) st.fishVel *= -0.6;   // chetdan qaytish

  /* --- zona boshqaruvi: o'yinchi sichqoncha bilan kuzatadi --- */
  // progress oshgani sari baliq charchaydi → zona torayadi (qiyinlashadi),
  // lekin baliq ham sekinlashadi
  const fatigue = 1 - clamp01(st.progress);
  st.zoneWidth = Math.max(F.zoneMinByWeight, st.zoneBase * (0.75 + 0.25 * fatigue));

  const follow = 13.0;                                 // zich kuzatish tezligi
  let target = input.zone;
  if (typeof target !== 'number' || Number.isNaN(target)) target = st.fishPos;   // avto-kuzatish (fallback)
  target = clamp(target - st.zoneWidth / 2, 0, 1 - st.zoneWidth);
  st.zonePos += (target - st.zonePos) * Math.min(1, follow * dt);
  // baliq dart qilganda zona biroz siljiydi (qarshilik)
  st.zonePos -= st.fishVel * dt * 0.10;
  st.zonePos = clamp(st.zonePos, 0, 1 - st.zoneWidth);

  const inZone = st.fishPos >= st.zonePos && st.fishPos <= st.zonePos + st.zoneWidth;

  /* --- taranglik (tension) --- */
  if (reeling) st.tension += F.tensionGain * dt * (inZone ? 0.8 : 1.45) * (0.7 + st.fightPower * 0.4);
  else st.tension -= F.tensionRelease * dt;
  st.tension = clamp(st.tension, 0, F.tensionMax);

  /* --- progress: uzluksiz tortish + "pump" (har bosishda qo'shimcha siljish) --- */
  if (reeling && inZone) st.progress += st.reelSpeed * dt;
  else if (reeling && !inZone) st.progress += st.reelSpeed * 0.12 * dt;
  else st.progress -= F.slipSpeed * dt * (0.5 + Math.min(2.5, st.fightPower) * 0.35);

  // qo'yib yuborish → qayta bosish = "pump" bonusi (tension past bo'lgandagina samarali)
  const pump = reeling && !st._wasReeling;
  if (pump) {
    // pump faqat zona ichida samarali (aks holda zonasiz "pump" qilish oson bo'lib qoladi)
    if (inZone) {
      if (st.tension < 0.9) st.progress += F.pumpBonus / (0.7 + st.fightPower * 0.3);
      st.tension = Math.max(0, st.tension - F.pumpRelief);   // pump faqat zona ichida tension ni bo'shatadi
    }
    st.pumps += 1;
  }
  st._wasReeling = reeling;

  // progress 0 ga tushsa va o'yinchi qaytara olmasa → baliq qochadi
  st.progress = Math.max(0, st.progress);

  /* --- chiziq eskirishi --- */
  st.lineHP -= st.tension * dt * F.linePerFishHP * st.fishHP;
  st.lineHP = Math.max(0, st.lineHP);

  /* --- yakun --- */
  if (st.tension >= F.lineSnapTension) st.result = { ok: false, reason: 'line_snap' };
  else if (st.progress <= 0) st.result = { ok: false, reason: 'escaped' };
  else if (st.elapsed >= F.escapeTime) st.result = { ok: false, reason: 'timeout' };
  else if (st.lineHP <= 0) st.result = { ok: false, reason: 'line_broken' };
  else if (st.progress >= 1) st.result = { ok: true, reason: 'caught' };

  if (st.result) st.state = 'done';
  return st;
}

/** Qarmoq otish holat mashinasi. */
export class CastMachine {
  constructor(opts = {}) {
    this.state = 'idle';
    this.power = 0; this.t = 0; this.dist = 0;
    this.rodLevel = opts.rodLevel ?? 1;
    this.bobber = { x: 0, y: 0, z: 0 };
    this.onState = opts.onState ?? (() => {});
    this.onEnterFight = null;
  }
  setRodLevel(l) { this.rodLevel = l; }
  startWindup() { if (this.state !== 'idle') return false; this._set('windup'); this.power = 0; this.t = 0; return true; }
  update(dt) {
    this.t += dt;
    if (this.state === 'windup') {
      this.power = Math.min(1, this.t / 1.1);
    } else if (this.state === 'airborne') {
      if (this.t > this._flight) this._set('sinking');
    } else if (this.state === 'sinking') {
      if (this.t > 0.5) this._set('waiting');
    } else if (this.state === 'strike') {
      if (this.t > CFG.fishing.strikeWindow) { this.result = { ok: false, reason: 'missed_strike' }; this._set('done'); }
    }
    return this;
  }
  release() {
    if (this.state !== 'windup') return null;
    const p = CFG.fishing.rod.castPowerMin + this.power * (CFG.fishing.rod.castPowerMax - CFG.fishing.rod.castPowerMin);
    this.dist = CFG.fishing.rod.castDistanceMin + (CFG.fishing.rod.castDistanceMax - CFG.fishing.rod.castDistanceMin) * p * (1 + (this.rodLevel - 1) * 0.01);
    this._flight = 0.35 + this.dist * 0.028;
    this._set('airborne');
    return this.dist;
  }
  bite() { if (this.state !== 'waiting') return false; this._set('strike'); return true; }
  hookFish() {
    if (this.state !== 'strike') return false;
    this._set('fight');
    this.onEnterFight?.();     // jangni boshlash (FishingSystem.beginFight)
    return true;
  }
  reset() { this.state = 'idle'; this.result = null; this.t = 0; this.power = 0; }
  _set(s) { this.state = s; this.t = 0; this.onState(s, this); }
}

/** Tishlash kutilish vaqti: ob-havo/vaqt/yem/omad ta'siri. */
export function biteDelay({ weather = 'clear', hour = 6, bait = 'none', luck = 0, rnd = Math.random } = {}) {
  const b = CFG.fishing.bite;
  const base = b.baseMin + rnd() * (b.baseMax - b.baseMin);
  const wm = (WEATHER_BITE[weather] ?? 1);
  const hm = CFG.time.biteByHour[hourPhase(hour)] ?? 1;
  const bm = b.baitMult[bait] ?? 1;
  const lm = 1 - luck / 400;                 // omad → biroz tezroq
  return Math.max(0.8, base * wm * (1 / hm) * bm * lm);
}
const WEATHER_BITE = { clear: 1, cloudy: 0.9, rain: 0.74, thunder: 0.6, fog: 1.25, snow: 1.42, wind: 0.87, storm: 0.55 };
export function hourPhase(h) { return h >= 5 && h < 8 ? 'dawn' : h >= 8 && h < 17 ? 'day' : h >= 17 && h < 20 ? 'dusk' : 'night'; }

/** Bir tutish natijasini to'liq hisoblash (tur+hajm+og'irlik). */
export function rollCatch({ island, luck, bait, weather, hour, rnd = Math.random }) {
  const sp = pickSpecies({ island, luck, bait, weather, hour, rnd });
  const tier = rollSizeTier(luck, rnd);
  const fight = createFight({ speciesId: sp.id, tier, luck, rnd });
  return { species: sp, speciesId: sp.id, tier, weight: fight.weight, fight };
}

export function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
export function clamp01(v) { return clamp(v, 0, 1); }
let rnd01 = Math.random;
/** Test determinizmi uchun RNG ni almashtirish. */
export function setFightRng(fn) { rnd01 = fn ?? Math.random; }
