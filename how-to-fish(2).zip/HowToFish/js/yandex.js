/**
 * yandex.js — Yandex Games SDK ko'prigi.
 * SDK bo'lmasa (masalan localhost'da) — localStorage + soxta liderbord fallback.
 *
 * Yandex Games talablari:
 *  - Cloud save ≤ 200 KB          → fitsYandexCloud() bilan tekshiriladi
 *  - Leaderboard                  → setScore / getScores
 *  - Rewarded video / interstitial→ showRewarded / showInterstitial
 *  - In-App purchases             → buy / getPurchases
 *  - GameplayStart / GameplayStop → gameplayStart / gameplayStop
 */
import { CFG } from './core/balance.js';
import { fitsYandexCloud } from './core/save.js';

const LB_NAME = 'howtofish_best';

export class YandexBridge {
  constructor() {
    this.ysdk = null;
    this.player = null;
    this.lb = null;
    this.available = false;
    this.paid = false;
    this.mock = {
      scores: JSON.parse(localStorage.getItem('htf_mock_lb') || '[]'),
      purchases: JSON.parse(localStorage.getItem('htf_mock_iap') || '[]'),
    };
  }

  async init() {
    if (typeof window === 'undefined' || !window.YaGames) {
      this.available = false;
      return { ok: false, mode: 'offline' };
    }
    try {
      this.ysdk = await window.YaGames.init();
      this.available = true;
      try {
        this.player = await this.ysdk.getPlayer({ scopes: false });
      } catch (e) { this.player = null; }
      try {
        this.lb = await this.ysdk.getLeaderboards();
      } catch (e) { this.lb = null; }
      return { ok: true, mode: 'yandex', name: this.player?.getName?.() ?? 'guest' };
    } catch (e) {
      this.available = false;
      return { ok: false, mode: 'offline', error: String(e) };
    }
  }

  get playerName() {
    if (this.player?.getName) return this.player.getName();
    return localStorage.getItem('htf_name') || 'Fisher';
  }
  setPlayerName(n) {
    if (this.player?.setName) { try { this.player.setName(n); } catch (e) {} }
    localStorage.setItem('htf_name', n);
  }

  /* ---------- Cloud save ---------- */
  async saveCloud(state) {
    const fit = fitsYandexCloud(state);
    if (!fit.ok) return { ok: false, reason: 'too_big', ...fit };
    const data = state.serialize();
    if (this.available && this.player) {
      try { await this.player.setData({ save: data }, true); return { ok: true, mode: 'cloud', ...fit }; }
      catch (e) { return { ok: false, reason: 'cloud_error', error: String(e), ...fit }; }
    }
    localStorage.setItem(CFG.save.key + '_cloud', data);
    return { ok: true, mode: 'local', ...fit };
  }

  async loadCloud() {
    if (this.available && this.player) {
      try {
        const d = await this.player.getData(['save']);
        if (d && d.save) return { ok: true, data: d.save, mode: 'cloud' };
      } catch (e) { /* fallthrough */ }
    }
    const d = localStorage.getItem(CFG.save.key + '_cloud');
    return d ? { ok: true, data: d, mode: 'local' } : { ok: false };
  }

  /* ---------- Leaderboards ---------- */
  async setScore(score, extra = {}) {
    if (this.available && this.lb) {
      try { await this.lb.setLeaderboardScore(LB_NAME, Math.round(score)); return { ok: true }; }
      catch (e) { return { ok: false, error: String(e) }; }
    }
    const list = this.mock.scores;
    list.push({ name: this.playerName, score: Math.round(score), ...extra, ts: Date.now() });
    list.sort((a, b) => b.score - a.score);
    this.mock.scores = list.slice(0, 50);
    localStorage.setItem('htf_mock_lb', JSON.stringify(this.mock.scores));
    return { ok: true, mock: true };
  }

  async getScores(limit = 10) {
    if (this.available && this.lb) {
      try {
        const r = await this.lb.getLeaderboardEntries(LB_NAME, { quantityTop: limit, includeUser: true, quantityAround: 3 });
        return (r.entries || []).map((e) => ({ name: e.player?.publicName ?? '—', score: e.score, rank: e.rank }));
      } catch (e) { return []; }
    }
    return this.mock.scores.slice(0, limit).map((e, i) => ({ name: e.name, score: e.score, rank: i + 1 }));
  }

  /* ---------- Ads ---------- */
  showRewarded(onReward) {
    if (this.available && this.ysdk?.adv) {
      let granted = false;
      this.ysdk.adv.showRewardedVideo({
        callbacks: {
          onOpen: () => {},
          onRewarded: () => { granted = true; onReward?.(); },
          onClose: () => { if (!granted) onReward?.(false); },
          onError: () => onReward?.(false),
        },
      });
      return true;
    }
    // Fallback: 3 sekundlik "reklama"
    setTimeout(() => onReward?.(true), 900);
    return false;
  }

  showInterstitial() {
    if (this.available && this.ysdk?.adv) {
      try { this.ysdk.adv.showFullscreenAdv({ callbacks: {} }); return true; } catch (e) {}
    }
    return false;
  }

  /* ---------- In-App purchases ---------- */
  async getPurchases() {
    if (this.available && this.ysdk?.getPayments) {
      try {
        const pay = await this.ysdk.getPayments();
        const prods = await pay.getCatalog();
        const owned = await pay.getPurchases();
        const ids = new Set(owned.map((p) => p.productID));
        return prods.map((p) => ({ id: p.id, title: p.title, price: p.priceValue, owned: ids.has(p.id) }));
      } catch (e) { return []; }
    }
    return [
      { id: 'remove_ads', title: 'Remove Ads', price: 1.99, owned: this.mock.purchases.includes('remove_ads') },
      { id: 'starter_pack', title: 'Starter Pack', price: 0.99, owned: this.mock.purchases.includes('starter_pack') },
      { id: 'golden_rod', title: 'Golden Rod Skin', price: 2.99, owned: this.mock.purchases.includes('golden_rod') },
    ];
  }

  async buy(productId) {
    if (this.available && this.ysdk?.getPayments) {
      try {
        const pay = await this.ysdk.getPayments();
        const p = await pay.purchase({ id: productId });
        this.paid = true;
        return { ok: true, purchase: p };
      } catch (e) { return { ok: false, error: String(e) }; }
    }
    if (!this.mock.purchases.includes(productId)) this.mock.purchases.push(productId);
    localStorage.setItem('htf_mock_iap', JSON.stringify(this.mock.purchases));
    return { ok: true, mock: true };
  }

  /* ---------- Lifecycle ---------- */
  gameplayStart() { if (this.available) { try { this.ysdk.features.GameplayAPI?.start(); } catch (e) {} } }
  gameplayStop() { if (this.available) { try { this.ysdk.features.GameplayAPI?.stop(); } catch (e) {} } }
  loadingReady() { if (this.available) { try { this.ysdk.features.LoadingAPI?.ready(); } catch (e) {} } }
}

export const yandex = new YandexBridge();
