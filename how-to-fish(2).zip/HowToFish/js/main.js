/**
 * main.js — o'yin orchestratori: holat, sikl, kiritish, boss jangi, ob-havo,
 * kooperativ, Yandex Games.
 */
import * as THREE from 'three';
import { CFG } from './core/balance.js';
import { SPECIES, ISLANDS, BOSSES, BOSS_BY_ISLAND, fishPrice } from './core/fishData.js';
import { WorldTime, Weather } from './core/time.js';
import { GameState, localLoad, localSave } from './core/save.js';
import { createBoss, updateBoss, damageBoss, unlockNextIsland, bossReward, BOSS_ATTACKS } from './core/bosses.js';
import { restockVendors, VENDORS } from './core/shop.js';
import { World } from './world.js';
import { Player } from './player.js';
import { Combat } from './weapons.js';
import { FishingSystem } from './fishing.js';
import { UI } from './ui.js';
import { audio } from './audio.js';
import { NetAdapter } from './net.js';
import { yandex } from './yandex.js';
import { setLang, t } from './i18n.js';

class App {
  constructor() {
    this.state = localLoad() ?? new GameState();
    setLang(this.state.settings.lang || 'uz');
    // test/CI rejimi: kichik render + katta dt qadami (SwiftShader sekin bo'ladi)
    this.testMode = new URLSearchParams(location.search).has('test');
    this.t = t;
    this.mode = 'menu';
    this.playerName = 'Fisher';
    this.lastSell = 0;

    this.world = new World(document.getElementById('gl'));
    this.player = new Player(this.world);
    this.audio = audio;
    this.time = new WorldTime(this.state.hour ?? CFG.time.startHour, this.state.day ?? 1);
    this.weather = new Weather(this.state.island, 4242);
    this.ui = new UI(this);
    this.net = new NetAdapter('local');
    this.ya = yandex;
    this.combat = new Combat(this.world, this.state, audio, this.player);
    this.fishing = new FishingSystem(this, this.player);
    this.remoteMeshes = new Map();
    this.bossState = null;

    this.player.setWeapon('rod');

    this._bindInput();
    this.applySettings();
    this._startLoop();

    this.boot();
  }

  /* ---------------- boot ---------------- */
  async boot() {
    if (this.testMode) {
      this.world.renderer.setPixelRatio(0.5);
      this.world.renderer.shadowMap.enabled = false;
      this.world.renderer.setSize(420, 300, false);
      this.world.camera.aspect = 420 / 300;
      this.world.camera.updateProjectionMatrix();
    }
    await audio.init();
    const r = await yandex.init();
    this.playerName = yandex.playerName;
    yandex.loadingReady();
    document.getElementById('loader').classList.add('hidden');
    document.getElementById('menu-foot').innerHTML =
      `${SPECIES.length} ${t('codex')} · ${BOSSES.length} ${t('boss')} · ${ISLANDS.length} ${t('islands')}<br>` +
      `${r.mode === 'yandex' ? 'Yandex SDK ✓' : t('offline')} · ${this.net.mode}`;
    this.ui.refreshLang();
    this.ui.updateHUD();
    // ambient baliqlar (menyu foni)
    this.world.spawnAmbientFish(SPECIES.filter((s) => s.islands.includes(0)), 12);
    this._menuCam = 0;
  }

  rarityLabel(r) { return t(`rarity.${r}`); }
  /** UI toast'iga qisqa yo'l — butun kod `app.toast(...)` deb chaqiradi. */
  toast(text, kind) { return this.ui.toast(text, kind); }
  killfeed(text) { return this.ui.killfeed(text); }

  /* ---------------- o'yinni boshlash ---------------- */
  async startGame() {
    this.mode = 'play';
    this.ui.hide();
    document.getElementById('hud').classList.remove('hidden');
    this.player.lock();
    audio.resume();
    audio.init().then(() => this._setAmbient());
    yandex.gameplayStart();
    this.world.buildIsland(this.state.island);
    this.player.pos.copy(this.world.spawnPoint());
    this._setAmbient();
    this.ui.toast(t('welcome'), 'good');
    this.ui.updateHUD();
    if (!this.state.seenAd) {
      setTimeout(() => this.offerAd(), 25000);
    }
  }

  toMenu() {
    this.mode = 'menu';
    this.ui.show('menu');
    document.getElementById('hud').classList.add('hidden');
    yandex.gameplayStop();
  }
  resume() {
    this.ui.hide();
    if (this.mode === 'play') this.player.lock();
  }
  pause() { if (this.mode === 'play') { this.player.unlock(); this.ui.show('pause'); } }

  /* ---------------- kiritish ---------------- */
  _bindInput() {
    const cv = this.world.canvas;
    cv.addEventListener('mousedown', (e) => {
      audio.resume();
      if (this.mode !== 'play' || this.ui.openScreen) return;
      if (!this.player.locked) { this.player.lock(); return; }
      if (e.button === 2) { this._scope(true); return; }
      if (e.button !== 0) return;
      if (this.player.weaponId === 'rod') this.fishing.pressButton();
      else this.combat.press(this.player);
    });
    addEventListener('mouseup', (e) => {
      if (e.button === 2) { this._scope(false); return; }
      if (e.button !== 0) return;
      if (this.player.weaponId === 'rod') this.fishing.releaseButton();
      else this.combat.release();
    });
    cv.addEventListener('contextmenu', (e) => e.preventDefault());

    addEventListener('keydown', (e) => {
      if (e.code === 'Escape') { this.ui.openScreen ? this.resume() : this.pause(); return; }
      if (this.mode !== 'play' || this.ui.openScreen) return;
      if (/^Digit[1-7]$/.test(e.code)) {
        const id = ['rod', 'fist', 'knife', 'pistol', 'rifle', 'auto', 'sniper'][+e.code.slice(5) - 1];
        if (this.state.weapons[id]) { this.player.setWeapon(id); this.combat.scoped = false; audio.play('ui_click', { volume: 0.35 }); }
      }
      if (e.code === 'KeyR') { if (this.combat.reload()) this.ui.toast('↻', ''); }
      if (e.code === 'KeyE') this.interact();
      if (e.code === 'KeyF') { this.state.lantern.toggle(); this.applyLantern(); this.ui.toast('🔦 ' + this.state.lantern.mode, ''); }
      if (e.code === 'KeyG') this.cookSelected();
      if (e.code === 'KeyM') { audio.muted = !audio.muted; this._setAmbient(); }
    });
  }

  _scope(on) {
    if (this.player.weaponId !== 'sniper') return;
    this.combat.scoped = on;
    this.world.camera.fov = on ? 22 : this.state.settings.fov;
    this.world.camera.updateProjectionMatrix();
  }

  interact() {
    const it = this.player.interactTarget;
    if (!it) return;
    audio.play('ui_click');
    const [kind, arg] = it.action.split(':');
    if (kind === 'vendor') { this._vendor = arg; this.ui.shopTab = 'weapon'; this.ui.show('shop'); this._openVendorSell(arg); }
    else if (kind === 'casino') this.ui.show('casino');
    else if (kind === 'shop') { this.ui.shopTab = arg === 'charm' ? 'charm' : 'weapon'; this.ui.show('shop'); }
    else if (kind === 'grill') this.cookSelected();
    else if (kind === 'travel') this.travel(+arg);
    else if (kind === 'boss') this.startBoss();
  }

  _openVendorSell(v) {
    // savdogar oynasida sovutgichni sotish tugmasi
    setTimeout(() => {
      const body = document.getElementById('shop-body');
      if (!body) return;
      const s = this.state;
      const box = document.createElement('div');
      box.innerHTML = `<h3 style="margin:16px 0 6px">${t('cooler')} — ${s.cooler.count}/${s.cooler.cap} · <span class="price">$${s.cooler.totalValue(v)}</span></h3>
        <div class="bet-row"><button id="vendor-sellall" class="big">${t('sellAll')} (×${VENDORS[v].mult})</button>
        <button id="vendor-ad">📺 ${t('adReward')}</button></div><div id="vendor-out"></div>`;
      body.prepend(box);
      document.getElementById('vendor-sellall').onclick = () => {
        const res = s.cooler.sellAll(v);
        const mult = VENDORS[v].mult * (VENDORS[v].mood ?? 1);
        const money = Math.round(res.money * mult);
        s.money += money; s.stats.earned += money; s.stats.sold += res.count;
        s.vendorStock[v] = Math.max(0, (s.vendorStock[v] ?? VENDORS[v].cap) - res.count);
        this.lastSell = money;
        audio.play('coins');
        document.getElementById('vendor-out').innerHTML = `<p class="stat">${res.count} × → <b class="price">+$${money}</b></p>`;
        this.ui.updateHUD();
        yandex.setScore(Math.round(s.stats.biggest * 100));
      };
      document.getElementById('vendor-ad').onclick = () => this.offerAd();
    }, 30);
  }

  offerAd() {
    const ov = document.getElementById('yandex-overlay');
    ov.classList.remove('hidden');
    document.getElementById('ya-title').textContent = '📺';
    document.getElementById('ya-msg').textContent = t('adReward');
    const btn = document.getElementById('ya-btn');
    btn.textContent = t('adWatch');
    btn.onclick = () => {
      yandex.showRewarded((ok) => {
        ov.classList.add('hidden');
        if (ok !== false) {
          const bonus = Math.max(150, Math.round(this.lastSell * 1 || this.state.money * 0.05));
          this.state.money += bonus;
          this.ui.toast(`+$${bonus}`, 'gold');
          audio.play('coins');
          this.ui.updateHUD();
        }
      });
      this.state.seenAd = true;
    };
  }

  /* ---------------- panjara ---------------- */
  cookSelected() {
    const it = this.state.cooler.items.find((x) => !x.cooked);
    if (!it) { this.ui.toast(t('cooked'), ''); return; }
    const r = this.state.grill.start(this.state.cooler, it.uid);
    if (!r.ok) { this.ui.toast(t('fuel'), 'bad'); return; }
    this.ui.toast(`🔥 ${r.time}s`, 'good');
    audio.play('ui_click', { volume: 0.4 });
  }

  /* ---------------- orol almashtirish ---------------- */
  travel(id) {
    if (!this.state.unlockedIslands.includes(id)) { this.ui.toast(t('locked'), 'bad'); return; }
    this.state.island = id;
    this.weather.setIsland(id);
    this.weather.roll();
    this.world.buildIsland(id);
    this.player.pos.copy(this.world.spawnPoint());
    this._setAmbient();
    restockVendors(this.state);
    this.bossState = null;
    this.world.despawnBoss();
    this.ui.showBoss(null);
    this.ui.toast(`⛵ ${ISLANDS[id].name}`, 'gold');
    this.ui.updateHUD();
    this.saveGame();
  }

  /* ---------------- chiroq ---------------- */
  applyLantern() {
    const l = this.state.lantern;
    if (!this._lanternLight) {
      this._lanternLight = new THREE.SpotLight(0xfff2c4, 0, 40, 0.55, 0.4, 1.4);
      this._lanternTarget = new THREE.Object3D();
      this.world.scene.add(this._lanternLight, this._lanternTarget);
      this._lanternLight.target = this._lanternTarget;
    }
    this._lanternLight.color.set(l.color);
    this._lanternLight.distance = l.range;
    this._lanternLight.userData = { l };
  }

  /* ---------------- ambient ovoz ---------------- */
  _setAmbient() {
    const w = this.weather.data;
    const night = this.time.isNight;
    audio.setAmbient({
      water: this.mode === 'play' ? 0.28 : 0.2,
      birds: night ? 0.02 : 0.12 * (w.visibility ?? 1),
      reeds: 0.06 * (w.wind ?? 0.3) * (this.world.island.climate === 'abyssal' ? 0 : 1),
      rain: ['rain', 'thunder', 'storm'].includes(this.weather.current) ? 0.3 : 0,
      wind: (w.wind ?? 0.2) * 0.22,
    });
  }

  /* ---------------- boss ---------------- */
  startBoss() {
    const def = BOSS_BY_ISLAND[this.state.island];
    if (!def) return;
    if (this.state.defeatedBosses.includes(this.state.island)) { this.ui.toast(t('bossDefeated'), 'good'); return; }
    this.bossState = createBoss(this.state.island);
    this.world.spawnBoss(def);
    this.world.boss.mesh.userData.combat = 'boss';
    this.world.boss.mesh.userData.bossRef = this.bossState;
    this.world.bossMarker.visible = false;
    this.combat.setTargets(this.collectTargets());
    this.ui.showBoss(def.name, this.bossState.hp, this.bossState.maxHP, 1);
    audio.play('boss_roar', { volume: 0.9 });
    this.ui.toast(`⚔ ${def.name} — ${this.bossState.maxHP} HP`, 'bad');
  }

  updateBoss(dt) {
    if (!this.bossState || !this.bossState.alive || this.bossState.hold) return;
    const b = this.bossState;
    const mesh = this.world.boss.mesh;
    const toPlayer = this.player.cam.position.clone().sub(mesh.position);
    const dist = toPlayer.length();

    const res = updateBoss(b, dt, { distance: dist });
    if (res.phaseChanged) { audio.play('boss_roar', { volume: 0.7 }); this.ui.toast(`⚠ ${t('boss')} ${b.phase}/3`, 'bad'); }

    // harakat: o'yinchiga yaqinlashish + aylanish
    const dir = toPlayer.clone().normalize();
    const speed = (b.phase === 3 ? 5.2 : b.phase === 2 ? 4.0 : 2.8) * b.enrage;
    if (dist > 9) mesh.position.addScaledVector(dir, speed * dt);
    mesh.position.y = this.world.waterY(mesh.position.x, mesh.position.z) - 0.6 + Math.sin(this.world.clock * 2) * 0.4;
    mesh.rotation.y = Math.atan2(dir.x, dir.z) - Math.PI / 2;
    if (mesh.userData.tail) mesh.userData.tail.rotation.y = Math.sin(this.world.clock * 5) * 0.6;

    if (res.attack) this.bossAttack(res.attack, res.attackDef, mesh);
    this.ui.showBoss(b.name, b.hp, b.maxHP, b.phase);
  }

  bossAttack(id, def, mesh) {
    const p = this.player;
    audio.play(id === 'lightning' ? 'thunder' : 'boss_roar', { volume: 0.45, rate: 1.4 });
    this.ui.toast('⚠ ' + t(def.key), 'bad');
    switch (id) {
      case 'charge': {
        const d = p.cam.position.distanceTo(mesh.position);
        if (d < def.range) { p.damage(def.dmg, 'boss'); this.world.splashAt(mesh.position, 3); }
        break;
      }
      case 'summon': {
        for (let i = 0; i < (def.count ?? 3); i++) {
          const sp = SPECIES.filter((s) => s.islands.includes(this.state.island))[Math.floor(Math.random() * 10)];
          if (!sp) continue;
          const m = this.world.makeFishMesh(sp, 'Hefty');
          m.position.copy(mesh.position).add(new THREE.Vector3((Math.random() - 0.5) * 8, 0, (Math.random() - 0.5) * 8));
          m.userData.combat = 'fish';
          m.userData.fightRef = {
            species: sp, tier: 'Hefty', weight: (sp.kgMin + sp.kgMax) / 2,
            fishHP: 60, progress: 0.5, tension: 0, lineHP: 1, fishPos: 0.5, zonePos: 0.4, zoneWidth: 0.2, fightPower: 1, elapsed: 0, state: 'fight',
          };
          m.userData.airborne = true;
          this.world.scene.add(m);
          this._minions = this._minions ?? [];
          this._minions.push(m);
        }
        this.combat.setTargets(this.collectTargets());
        break;
      }
      case 'whirlpool': {
        const d = p.cam.position.distanceTo(mesh.position);
        if (d < def.range) {
          const pull = mesh.position.clone().sub(p.cam.position).normalize().multiplyScalar(def.pull * 0.016);
          p.pos.add(pull);
          p.damage(def.dmg * 0.2, 'boss');
        }
        this.world.splashAt(mesh.position, 4);
        break;
      }
      case 'ink': {
        this._blind = def.blind;
        p.damage(def.dmg, 'boss');
        break;
      }
      case 'frost_breath': { this._slow = def.slow; p.damage(def.dmg, 'boss'); break; }
      case 'acid_spit': {
        this.world.spawnProjectile(mesh.position.clone(), p.cam.position.clone(), 0x9dff5a, 28);
        p.damage(def.dmg, 'boss');
        break;
      }
      case 'tail_slam': {
        if (p.cam.position.distanceTo(mesh.position) < def.range) { p.damage(def.dmg, 'boss'); p.kickRecoil(0.25); }
        break;
      }
      case 'lightning': {
        this.weather.lightning = 1;
        audio.thunder(60);
        p.damage(def.dmg, 'boss');
        this.world.spawnProjectile(new THREE.Vector3(p.cam.position.x, 60, p.cam.position.z), p.cam.position.clone(), 0xbfe6ff, 120);
        break;
      }
    }
  }

  killBoss() {
    const b = this.bossState;
    if (!b) return;
    const rew = bossReward(b);
    this.state.money += rew.money;
    this.state.stats.earned += rew.money;
    this.state.defeatedBosses.push(this.state.island);
    const u = unlockNextIsland(this.state, this.state.island);
    this.world.despawnBoss();
    this.bossState = null;
    this.world.bossMarker.visible = true;
    this.ui.showBoss(null);
    this.combat.setTargets(this.collectTargets());
    audio.play('coins', { volume: 1 });
    this.ui.toast(`🏆 ${t('bossDefeated')} +$${rew.money}`, 'gold');
    if (u.unlocked != null) this.ui.toast(`🔓 ${t('islandUnlocked')} ${u.island.name}`, 'gold');
    this.ui.updateHUD();
    this.saveGame(true);
  }

  /* ---------------- nishonlar ---------------- */
  collectTargets() {
    const list = [];
    if (this.world.boss) list.push(this.world.boss.mesh);
    for (const m of this._minions ?? []) list.push(m);
    if (this.fishing.fishMesh) list.push(this.fishing.fishMesh);
    for (const m of this.remoteMeshes.values()) list.push(m);
    return list;
  }

  /* ---------------- kooperativ ---------------- */
  async connectNet(room, host) {
    this.net.mode = this.net.mode || 'local';
    const ok = await this.net.connect(room || 'FISH1', this.playerName);
    if (ok) { this.ui.toast(`${t('connected')} · ${room}`, 'good'); this.net.sendEvent('hello', { name: this.playerName }); }
    this.ui.renderScreen('islands');
  }

  updateNet(dt) {
    if (!this.net.connected) return;
    this.net.update(dt, {
      name: this.playerName,
      x: +this.player.pos.x.toFixed(2), y: +this.player.pos.y.toFixed(2), z: +this.player.pos.z.toFixed(2),
      ry: +this.player.yaw.toFixed(2), hp: Math.round(this.state.hp), weapon: this.player.weaponId, island: this.state.island,
    });
    // uzoq o'yinchilarni chizish
    for (const p of this.net.list()) {
      let m = this.remoteMeshes.get(p.id);
      if (!m) {
        m = new THREE.Group();
        const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 1.0, 4, 8), new THREE.MeshStandardMaterial({ color: 0x3fa7d6, roughness: 0.8 }));
        body.position.y = 0.9; body.castShadow = true;
        const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), new THREE.MeshStandardMaterial({ color: 0xd9a274, roughness: 0.7 }));
        head.position.y = 1.72; head.name = 'weakspot';
        m.add(body, head);
        m.userData.combat = 'player';
        m.userData.netId = p.id;
        this.world.scene.add(m);
        this.remoteMeshes.set(p.id, m);
        this.ui.killfeed(`${p.name ?? p.id} ${t('playerJoined')}`);
        this.combat.setTargets(this.collectTargets());
      }
      m.position.lerp(new THREE.Vector3(p.x ?? 0, (p.y ?? 1) - 1.6, p.z ?? 0), Math.min(1, dt * 8));
      m.rotation.y = p.ry ?? 0;
    }
    for (const [id, m] of [...this.remoteMeshes]) {
      if (!this.net.players.has(id)) { this.world.scene.remove(m); this.remoteMeshes.delete(id); this.combat.setTargets(this.collectTargets()); }
    }
  }

  /* ---------------- saqlash ---------------- */
  saveGame(verbose) {
    this.state.hour = this.time.hour;
    this.state.day = this.time.day;
    const r = localSave(this.state);
    if (verbose) this.ui.toast(r.ok ? t('ok') : 'ERR', r.ok ? 'good' : 'bad');
    return r;
  }
  async saveCloud() {
    const r = await yandex.saveCloud(this.state);
    if (r.ok) this.ui.toast(`${t('cloudSaved')} · ${r.kb}/${r.limitKB} KB`, 'good');
    return r;
  }

  applySettings() {
    const s = this.state.settings;
    audio.setVolume('master', s.master);
    audio.setVolume('sfx', s.sfx);
    audio.setVolume('music', s.music);
    this.player.sens = s.sens;
    this.player.invertY = s.invertY;
    this.world.camera.fov = this.combat?.scoped ? 22 : s.fov;
    this.world.camera.updateProjectionMatrix();
    const q = s.quality;
    this.world.renderer.setPixelRatio(q === 'low' ? 0.7 : q === 'medium' ? 1 : Math.min(devicePixelRatio, 2));
    this.world.renderer.shadowMap.enabled = q !== 'low';
  }

  /* ---------------- asosiy sikl ---------------- */
  _startLoop() {
    let last = performance.now();
    const maxDt = this.testMode ? 0.25 : 0.05;
    const tick = (now) => {
      const dt = Math.min(maxDt, (now - last) / 1000);
      last = now;
      this.frame(dt);
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  frame(dt) {
    this.time.update(dt);
    this.weather.update(dt);
    if (this.time.day !== this._lastDay) {
      this._lastDay = this.time.day;
      restockVendors(this.state);
      this.state.luck.base = Math.max(0, this.state.luck.base - CFG.luck.decayPerDay);
      this.saveGame();
    }

    if (this.mode === 'play') {
      this.state.stats.playtime += dt;
      this.state.hp = this.player.hp;   // HUD / save / koop sinxroni
      this.player.update(dt * (this._slow > 0 ? 0.55 : 1));
      this._slow = Math.max(0, (this._slow ?? 0) - dt);
      this._blind = Math.max(0, (this._blind ?? 0) - dt);

      this.fishing.update(dt);

      this.combat.update(dt, this.player);
      this.updateBoss(dt);
      this.updateNet(dt);

      // panjara navbati
      const done = this.state.grill.update(dt, this.state.cooler);
      for (const it of done) this.ui.toast(`🍳 ${t('cooked')}!`, 'good');

      // omad vaqtinchalik bonusi
      this.state.luck.update(dt);

      // chiroq
      const l = this.state.lantern;
      l.update(dt, this.world.clock);
      if (this._lanternLight) {
        this._lanternLight.position.copy(this.player.cam.position);
        const f = this.player.forward;
        this._lanternTarget.position.copy(this.player.cam.position).addScaledVector(f, 8);
        this._lanternLight.intensity = l.on ? l.intensity * (l.strobe ?? 1) * 2.4 : 0;
      }

      // chaqmoq tovushi
      if (this.weather.lightning > 0.98 && !this._thunderQueued) {
        this._thunderQueued = true;
        audio.thunder(120 + Math.random() * 500);
        setTimeout(() => { this._thunderQueued = false; }, 4000);
      }

      this._setAmbientThrottled(dt);
      this.ui.showPrompt(this.player.interactTarget);
      if (this.fishing.machine.state === 'windup') this.ui.setCastPower(this.fishing.machine.power);
      this.ui.updateHUD();
    } else {
      // menyu kamerasi — orol atrofida aylanadi
      this._menuCam = (this._menuCam ?? 0) + dt * 0.06;
      const r = 46;
      this.world.camera.position.set(Math.cos(this._menuCam) * r, 14 + Math.sin(this._menuCam * 0.7) * 3, Math.sin(this._menuCam) * r);
      this.world.camera.lookAt(0, 2, 0);
    }

    this.world.update(dt, { time: this.time, weather: this.weather, camPos: this.world.camera.position });
    // ko'rinish (siyoh)
    this.world.renderer.toneMappingExposure = this._blind > 0 ? 0.12 : 1.05;
    this.world.render();
  }

  _setAmbientThrottled(dt) {
    this._ambCd = (this._ambCd ?? 0) - dt;
    if (this._ambCd <= 0) { this._ambCd = 2.5; this._setAmbient(); }
  }
}

/* ---------------- zarar/o'lim bog'lanishi ---------------- */
const app = new App();
window.app = app;

app.player.onDamage = (amount, from) => {
  document.getElementById('gl').style.boxShadow = `inset 0 0 120px rgba(255,40,40,${Math.min(0.75, amount / 40)})`;
  setTimeout(() => { document.getElementById('gl').style.boxShadow = ''; }, 180);
  if (from !== 'player') return;
  app.ui.killfeed(`${t('youDied')}`);
};
app.player.onDeath = () => {
  app.state.stats.deaths += 1;
  const ov = document.getElementById('yandex-overlay');
  ov.classList.remove('hidden');
  document.getElementById('ya-title').textContent = '💀';
  document.getElementById('ya-msg').textContent = t('youDied');
  const btn = document.getElementById('ya-btn');
  btn.textContent = t('respawn');
  btn.onclick = () => {
    ov.classList.add('hidden');
    app.player.respawn();
    app.state.hp = app.player.hp;
    app.player.lock();
  };
};
app.player.onStep = () => audio.play('step', { volume: 0.25, rate: 0.9 + Math.random() * 0.25 });

app.combat.onKill = (info) => {
  if (info.target === 'boss') {
    const dead = damageBoss(app.bossState, info.dmg);
    app.ui.killfeed(`⚔ ${Math.round(info.dmg)}${info.trick.mult > 1 ? ` ×${info.trick.mult.toFixed(1)}` : ''}`);
    if (dead) app.killBoss();
  } else if (info.target === 'fish') {
    const r = app.fishing.killFishByWeapon(info.ref, info.dmg, info.trick, info.weapon);
    if (r) {
      app.ui.killfeed(`${info.ref.userData.fightRef?.species?.name ?? ''} +$${r.price}`);
      app.net?.sendEvent('kill', { speciesId: r.entry.speciesId, weapon: info.weapon });
    } else app.ui.killfeed(`⚔ ${Math.round(info.dmg)}`);
  } else if (info.target === 'player') {
    if (app.state.settings.pvp && app.net.connected) {
      app.net.sendDamage(info.ref, info.dmg, info.weapon);
      app.ui.killfeed(`🎯 → ${info.ref} ${info.dmg}`);
    }
  }
};

app.net.onEvent = (e) => {
  if (e.type === 'game') {
    if (e.kind === 'damage' && e.data.target === app.net.selfId && app.state.settings.pvp) {
      app.player.damage(e.data.dmg, 'player');
      app.ui.killfeed(`💥 ${e.data.weapon} ${e.data.dmg}`);
    }
    if (e.kind === 'catch') app.ui.killfeed(`🎣 ${e.data.name ?? ''} · ${e.data.speciesId} ${e.data.weight}kg`);
  } else if (e.type === 'join') app.ui.killfeed(`${e.player.name ?? e.player.id} ${t('playerJoined')}`);
  else if (e.type === 'leave') app.ui.killfeed(`${e.player?.name ?? ''} ${t('playerLeft')}`);
  else if (e.type === 'error') app.ui.toast(e.message, 'bad');
  else if (e.type === 'rejected') app.ui.toast("✕ 4/4 — xona to'liq", "bad");
};

// sahifadan chiqishda saqlash
addEventListener('beforeunload', () => app.saveGame());
setInterval(() => { if (app.mode === 'play') app.saveGame(); }, 30000);
