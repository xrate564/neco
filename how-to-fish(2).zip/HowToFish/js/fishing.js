/**
 * fishing.js (runtime) — CastMachine + fight mini-o'yinini 3D dunyo va UI bilan bog'laydi.
 */
import * as THREE from 'three';
import { CFG } from './core/balance.js';
import { CastMachine, updateFight, createFight, rollCatch, biteDelay, clamp01 } from './core/fishing.js';
import { fishPrice } from './core/fishData.js';
import { rollLuckyFish } from './core/luck.js';

export class FishingSystem {
  constructor(app, player = null) {
    this.app = app;
    this.world = app.world;
    this.player = player ?? app.player;
    this.state = app.state;
    this.machine = new CastMachine({ rodLevel: 1, onState: (s) => this.onState(s) });
    this.machine.onEnterFight = () => { if (!this.current) this.beginFight(); };
    this.cast = { active: false, holding: false };
    this.bobberPos = new THREE.Vector3();
    this.biteTimer = 0;
    this.current = null;         // joriy jang
    this.fishMesh = null;
    this._lineSnapShown = false;
    this._reelingHeld = false;
  }

  get busy() { return this.machine.state !== 'idle'; }

  pressButton() {
    if (this.machine.state === 'strike') { this.hook(); return; }
    if (this.machine.state === 'fight') { this.player.playReel(true); return; }
    if (this.machine.state === 'idle') {
      this.machine.setRodLevel(this.state.levels.rod ?? 1);
      this.machine.startWindup();
      this.cast.holding = true;
      this.app.ui.showCastPower(true);
    }
  }

  releaseButton() {
    if (this.machine.state === 'windup') {
      const d = this.machine.release();
      this.cast.holding = false;
      this.app.ui.showCastPower(false);
      this.player.playCast(this.machine.power);
      this._launchBobber(d);
      this.app.audio.play('reel_click', { volume: 0.4 });
    } else if (this.machine.state === 'fight') {
      this.player.playReel(false);
    }
  }

  _launchBobber(dist) {
    const p = this.player;
    const dir = new THREE.Vector3(-Math.sin(p.yaw), 0, -Math.cos(p.yaw));
    this.bobberPos.copy(p.cam.position).addScaledVector(dir, dist);
    this.bobberPos.y = 0;
    this.machine.bobber = { x: this.bobberPos.x, y: 0, z: this.bobberPos.z };
    this.player.setLine(this.bobberPos);
  }

  onState(s) {
    if (s === 'waiting') {
      this.scheduleBite();
      this.app.audio.play('splash', { volume: 0.8 });
      this.world.splashAt(this.bobberPos, 1.2);
    } else if (s === 'strike') {
      this.app.audio.play('bite_bell', { volume: 0.9 });
      this.app.ui.showStrike(true);
    } else if (s === 'done' && this.machine.result?.reason === 'missed_strike') {
      this.app.ui.showStrike(false);
      this.app.toast(this.app.t('missed'), 'bad');
      this.reset();
    } else if (s === 'idle') {
      this.player.setLine(null);
    }
  }

  scheduleBite() {
    const st = this.state;
    const bait = (st.baitCounts[st.bait] ?? 0) > 0 ? st.bait : 'none';
    this.biteTimer = biteDelay({
      weather: this.app.weather.current,
      hour: this.app.time.hour,
      bait, luck: st.luck.value,
    });
  }

  hook() {
    if (!this.machine.hookFish()) return;
    // beginFight() onEnterFight orqali chaqiriladi
  }

  /** Jangni boshlash: tur/hajm/og'irlik tanlanadi va mini-o'yin ochiladi. */
  beginFight() {
    if (this.current) return this.current;
    this.app.ui.showStrike(false);
    const st = this.state;
    const bait = (st.baitCounts[st.bait] ?? 0) > 0 ? st.bait : 'none';
    const rolled = rollCatch({
      island: st.island, luck: st.luck.value, bait,
      weather: this.app.weather.current, hour: this.app.time.hour,
    });
    const fight = createFight({
      speciesId: rolled.speciesId, tier: rolled.tier,
      luck: st.luck.value, rodLevel: st.levels.rod ?? 1,
    });
    fight.lineHP = 1 + (st.lineHPBonus ?? 0);
    this.current = fight;
    this.app.ui.showFight(fight, true);
    this.player.playReel(true);
    this.player.fightMode = true;
    // baliq mesh'i suv ostida
    this.fishMesh = this.world.makeFishMesh(fight.species, fight.tier);
    this.fishMesh.position.copy(this.bobberPos).add(new THREE.Vector3(0, -0.6, 0));
    this.fishMesh.userData.combat = 'fish';
    this.fishMesh.userData.fightRef = fight;
    this.world.scene.add(this.fishMesh);
    this.app.combat.setTargets(this.app.collectTargets());
    if (fight.species.armed) this.app.toast(this.app.t('armedFish'), 'bad');
    return fight;
  }

  update(dt) {
    this.machine.update(dt);

    // poplavok suvda tebranadi
    if (this.machine.state !== 'idle') {
      this.bobberPos.y = this.world.waterY(this.bobberPos.x, this.bobberPos.z)
        + (this.machine.state === 'strike' ? -0.22 + Math.sin(performance.now() * 0.03) * 0.08 : 0.06);
      this.player.setLine(this.bobberPos);
    }

    if (this.machine.state === 'waiting') {
      this.biteTimer -= dt;
      // baliq poplavokka yaqinlashadi
      if (this.fishMesh) {
        const to = this.bobberPos.clone().sub(this.fishMesh.position);
        this.fishMesh.position.addScaledVector(to.normalize(), dt * 1.2);
        this.fishMesh.rotation.y = Math.atan2(to.x, to.z);
      }
      if (this.biteTimer <= 0) {
        // yaqinlashuvchi baliqni ko'rsatish
        this._spawnApproachFish();
        this.machine.bite();
      }
    }

    if (this.machine.state === 'fight' && this.current) {
      const input = {
        reeling: this._reelingHeld,
        zone: this.player.mouseNormX,
      };
      const before = this.current.progress;
      updateFight(this.current, dt, input);
      this.app.ui.updateFight(this.current);
      // 3D: baliq poplavok atrofida tebranadi
      if (this.fishMesh) {
        const off = (this.current.fishPos - 0.5) * 7;
        this.fishMesh.position.lerp(this.bobberPos.clone().add(new THREE.Vector3(off, -0.5 - this.current.progress * 0.5, off * 0.3)), Math.min(1, dt * 6));
        this.fishMesh.rotation.y = Math.sin(this.current.elapsed * 3) * 0.6 + Math.PI / 2;
      }
      if (this.current.progress > before) this.app.audio.play('reel_click', { volume: 0.22, rate: 1.6 });
      // qurollangan baliq javob beradi
      if (this.current.species.armed) {
        this._retaliateCd = (this._retaliateCd ?? 3) - dt;
        if (this._retaliateCd <= 0) {
          this._retaliateCd = 4 + Math.random() * 5;
          const d = this.fishMesh ? this.fishMesh.position.distanceTo(this.player.cam.position) : 12;
          const shot = this.app.combat.armedFishRetaliate(this.current.species, d, this.player);
          if (shot?.hit) {
            this.app.toast(this.app.t('fishShotYou'), 'bad');
            this.world.spawnProjectile(this.fishMesh.position.clone(), this.player.cam.position.clone(), 0xff8844, 45);
          }
        }
      }
      if (this.current.state === 'done') this.finish();
    }
  }

  _spawnApproachFish() {
    if (this.fishMesh) return;
    // vizual "yaqinlashish" — kichik soya
    const st = this.state;
    const rolled = rollCatch({ island: st.island, luck: st.luck.value, bait: st.bait, weather: this.app.weather.current, hour: this.app.time.hour });
    this.fishMesh = this.world.makeFishMesh(rolled.species, 'Plump');
    const a = Math.random() * 6.28;
    this.fishMesh.position.copy(this.bobberPos).add(new THREE.Vector3(Math.cos(a) * 6, -0.8, Math.sin(a) * 6));
    this.world.scene.add(this.fishMesh);
  }

  finish() {
    const f = this.current;
    const res = f.result;
    this.app.ui.showFight(null, false);
    this.player.playReel(false);

    if (res.ok) {
      const lucky = rollLuckyFish(this.state.luck.value);
      const trickMult = 1;
      const entry = {
        speciesId: f.speciesId, tier: f.tier, weight: f.weight,
        method: 'rod', trickMult, luckyMult: lucky.mult,
        island: this.state.island, ts: Date.now(),
      };
      const price = fishPrice({
        species: f.speciesId, tier: f.tier, weight: f.weight, method: 'rod',
        trickMult, vendor: 'fishMarket', lucky: lucky.mult,
      });
      const add = this.state.cooler.add(entry);
      if (!add.ok) this.app.toast(this.app.t('coolerFull'), 'bad');
      else {
        this.state.addCatch(entry, price);
        this.app.audio.play('fish_flop', { volume: 0.9 });
        this.app.toast(`${this.app.rarityLabel(f.species.rarity)} · ${this.app.t(`size.${f.tier}`)} · ${f.weight} kg ≈ $${price}`, 'gold');
        this.app.net?.sendEvent('catch', { speciesId: f.speciesId, tier: f.tier, weight: f.weight, name: this.app.playerName });
      }
      this.world.splashAt(this.bobberPos, 2);
    } else {
      const msg = { line_snap: 'lineSnap', escaped: 'escaped', timeout: 'timeout', line_broken: 'lineBroken' }[res.reason] ?? 'escaped';
      this.app.toast(this.app.t(msg), 'bad');
      if (res.reason === 'line_snap') this.app.audio.play('line_snap', { volume: 0.9 });
    }
    this.reset();
  }

  reset() {
    if (this.fishMesh) { this.world.scene.remove(this.fishMesh); this.fishMesh = null; }
    this.current = null;
    this.player.fightMode = false;
    this.machine.reset();
    this.player.setLine(null);
    this.app.combat.setTargets(this.app.collectTargets());
  }

  /** O'q bilan baliqni o'ldirish → usul bo'yicha narx. */
  killFishByWeapon(fishMesh, dmg, trick, weaponId) {
    const ref = fishMesh.userData.fightRef;
    const sp = ref?.species ?? null;
    if (!sp) return null;
    ref.fishHP = (ref.fishHP ?? 10) - dmg;
    if (ref.fishHP > 0) return null;
    const entry = {
      speciesId: sp.id, tier: ref.tier, weight: ref.weight,
      method: weaponId, trickMult: trick.mult, luckyMult: 1,
      island: this.state.island, ts: Date.now(),
    };
    const price = fishPrice({
      species: sp.id, tier: ref.tier, weight: ref.weight, method: weaponId,
      trickMult: trick.mult, vendor: 'fishMarket',
    });
    const add = this.state.cooler.add(entry);
    if (add.ok) {
      this.state.addCatch(entry, price);
      this.state.stats.kills += 1;
      this.app.toast(`${sp.name} × ${this.app.t(`size.${ref.tier}`)} — ${trick.parts.length ? trick.parts.map((p) => this.app.t(`trick.${p}`)).join(' + ') : ''} ≈ $${price}`, 'gold');
    }
    this.world.scene.remove(fishMesh);
    if (this.current === ref) this.reset();
    else this.app.combat.setTargets(this.app.collectTargets());
    return { entry, price };
  }
}
