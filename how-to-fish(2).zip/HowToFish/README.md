# HOW TO FISH — 3D kooperativ baliq ovlash o'yini

Brauzer (WebGL) uchun to'liq o'ynaladigan prototip. **Three.js + toza ES-modullar**,
build-stepsiz. Barcha tizimlar sof mantiq modulida (`js/core/*`) — Node'da 76 ta unit-test +
7 ta multiplayer test, haqiqiy Chrome'da 42 ta browser-test va 2 tabli koop test bilan tekshirilgan.

> Til: **UZ / RU / EN** (menyuda va sozlamalarda almashtiriladi).

---

## Ishga tushirish

```bash
cd HowToFish
python3 tools/serve.py 8080        # yoki: npx serve -l 8080
# brauzerda: http://localhost:8080
```

Live preview (sandbox) allaqachon `0.0.0.0:8080` da ishlayapti.

### Testlar

```bash
node tests/logic.test.mjs                     # 76 ta mantiqiy test (DOM'siz)
node tests/net.test.mjs                       # 7 ta multiplayer test (xona limiti, PvP, prune)
node tests/browser.test.mjs [url]             # haqiqiy Chrome + WebGL smoke-test (42 assert)
node tests/coop.test.mjs                      # 2 tabli haqiqiy koop test (sinxron, PvP, killfeed)
python3 tools/gen_audio.py                    # protsedural WAV ovozlarini qayta generatsiya
```

---

## Xususiyatlar (spesifikatsiya bo'yicha)

### Kamera / qahramon
- Birinchi shaxs, pointer-lock, WASD, sprint/stamina, crouch, kamera tebranishi (head-bob).
- Viewmodel: qo'llar, qarmoq, pichoq, 4 xil qurol; **otish/tortish/otish-kuch (cast) animatsiyalari**,
  recoil, muzzle-flash, g'altak aylanishi, "pump" animatsiya.

### Baliq ovlash mexanikasi
- Sichqoncha bosib turish → otish kuchi → qarmoq parabolada uchadi → poplavok suvga tushadi.
- Tishlash vaqti: **ob-havo × kun fazasi × yem × omad** (sof formula, `core/fishing.js:biteDelay`).
- Baliq yaqinlashadi (3D mesh suv ostida), "!" paydo bo'lganda bosish oynasi (1.1 s).
- **Mini-o'yin (tension)**: gorizontal barda baliq markeri chaqmoqday dart qiladi;
  sichqoncha bilan **zonani baliqda ushlaysiz** (jangda kamera qulflanadi — sichqoncha faqat zonani
  boshqaradi), bosib turish = tortish + tension o'sishi;
  tension = 1.0 → **chiziq uziladi**; progress = 0 → baliq qochadi; zona ichida
  qo'yib-yuborib qayta bosish = **"pump" bonusi**. Hammasi `core/fishing.js:updateFight()` da,
  300+ simulyatsiya bilan balansi tekshirilgan (katta baliq ≈ 15 s kurash).
- Baliq chiziqqa zarar keltiradi (line HP), qarmoq darajasi zona/reel/line statlarini oshiradi.

### Baliqlar
- **52 tur** (`core/fishData.js`), 6 rarity: Common→Mythic; har tur uchun og'irlik oralig'i,
  kurash kuchi, tezlik, biome (fresh/salt), tungi faollik, orol hovuzi.
- Hajm sinflari: **Plump, Hefty, Massive, Colossal, Leviathan, Mythic** — narx multiplikatori bilan.
- **Mythic = 50× qimmat** (`rarity.mythicValueBonus`, test bilan tasdiqlangan).
- **Qurollangan baliqlar** (🔫): grouper/marlin/tuna/GT/coelacanth/megalodon va boshqalar —
  ular sizga o'q otadi (pistol→sniper), javob o'q bilan zarar olasiz.

### Qurol tizimi
- 7 qurol: **qarmoq, musht, pichoq, to'pponcha, miltiq, avtomat, snayper**.
- Har biri **25 daraja** yangilanadi (DMG/RPM/MAG/range/spread/recoil o'sadi).
- O'ldirish usuli narxga ta'sir: **pichoq ×2**, musht ×1.75, snayper ×1.6 ...
- **Trick-shot bonuslari**: headshot ×1.5, **no-scope ×2**, **havoda otish ×2.2**,
  havodagi nishon ×2, uzoq masofa ×1.8, yugurib otish ×1.4, weakspot ×1.6 — jami ≤ ×12.

### Kazino
- **Ruletka** (0–36, red/black/green/even/odd/low/high, 36×/2×), animatsion g'ildirak.
- **Slot mashinasi** (8 belgi, 3 baraban, jackpot 50×).
- **Blackjack** (hit/stand/double, 2.5× blackjack).
- **Poker — 5 Card Draw** (hold/exchange, qo'l baholash: high card → straight flush).
- House edge test bilan o'lchangan (RTP 0.78–0.999). "Baliqni pulga aylantirish yoki yo'qotish" ✔.

### Iqtisod
- Tutish → sovutgich → savdogarga sotish → pul → do'kon.
- **4 NPC savdogar, turli narx/sig'im**: Fish Market ×1.0/60, Black Market ×1.45/18,
  Gourmet ×1.25/30, Pier ×0.85/∞; kayfiyat (mood) har kuni tebranadi, sig'im cheklangan.
- Do'kon: qurol, yem (5 tur), o'q (4 tur), asboblar (XL sovutgich, Pro panjara, chiroq up, line kit,
  medkit, zirh) + **Lucky Charm do'koni** (6 tumor).

### Inventar
- **Ko'chma sovutgich — 20 baliq** (slot-list, narx hisobi, sotish).
- **Ko'chma panjara (Campfire Grill)** — pishirish ×1.75 (Pro bilan ×2.1), yoqilg'i, navbat.
- **Ko'chma chiroq** — 5 rejim (off/low/mid/high/strobe), 5 rang, batareya, daraja;
  haqiqiy SpotLight sifatida dunyoni yoritadi.

### Ob-havo va vaqt
- **Kun/tun sikli** (8 min = 1 kun): tong/kunduz/shom/tun, quyosh/oy, yulduzlar, tong-shom rangi.
- **8 ob-havo**: ochiq, bulutli, yomg'ir, **momaqaldiroq** (chaqmoq + momaqaldiroq tovushi),
  **qor**, tuman, shamol, **bo'ron**. Zarralar (yomg'ir/qor), tuman zichligi, to'lqin balandligi.
- Ob-havo tishlashga ta'sir qiladi (bo'ron ×1.8, qor ×0.7 ...).
- **Har orolning o'z iqlimi** (6 iqlim) va o'z suv/osmon palitrasi.

### Omad tizimi
- Omad 0–100; **100 omadda 95% noyob baliq** (`luck.rareChanceAt`, test bilan tasdiqlangan).
- Lucky Charm do'koni: quyon oyog'i (+8) → kraken ko'zi (+80).
- Omad har kuni biroz pasayadi; vaqtinchalik boost'lar bor.

### Boss janglari
- **Har orolda 1 boss** (6 ta): Catfish King → Abyss Emperor.
- **HP tizimi + 3 faza** (enrage), **maxsus hujumlar**: charge, summon, whirlpool, ink,
  frost breath, acid spit, tail slam, lightning.
- Boss qurollangan bo'lishi mumkin (o'q qaytaradi).
- **Boss mag'lub → keyingi orol ochiladi** (+ pul mukofoti), test bilan tekshirilgan.

### Ko'p o'yinchi
- **4 kishigacha kooperativ** (`CFG.multiplayer.maxPlayers = 4`, test).
- Transport adapteri (`js/net.js`): hozir **BroadcastChannel** (bir brauzerda 2+ tab —
  sandbox'da ishlaydi); **Photon Fusion va Mirror uchun stub-konstruktorlar tayyor** —
  `connect(mode='fusion')` chaqirilganda aniq ko'rsatma qaytaradi; interfeys bir xil,
  almashtirish nuqtasi bitta fayl.
- Holat sinxroni (20 Hz), join/leave, **PvP** (sozlamada o'chiriladi): o'yinchilar
  bir-birini otishi mumkin (headshot weakspot bilan).

### Yandex Games
- `js/yandex.js` — to'liq ko'prik: `init`, **leaderboard** (`setScore/getScores`),
  **cloud save ≤ 200 KB** (hajm test bilan tekshiladi: `fitsYandexCloud`),
  **rewarded/interstitial reklama**, **In-App purchases** (`getPurchases/buy`),
  `GameplayStart/Stop`, `LoadingAPI.ready`.
- SDK yo'q bo'lsa (localhost/sandbox) — **offline fallback**: localStorage + mock
  liderbord/IAP, o'yin to'liq ishlayveradi.
- Nashr qo'llanmasi: `docs/YANDEX.md`.

### Vizual / ovoz
- Realistik yoritish: ACES tone-mapping, soyalar, quyosh rangi sikli, suvda quyosh aksi,
  fresnel, caustics, qirg'oq ko'pigi; qamish shamolda shader orqali tebranadi.
- **Ovozlar protsedural generatsiya qilingan** (21 WAV, `tools/gen_audio.py`):
  suv shovqini (loop), qushlar (loop), qamish shitirlashi (loop), yomg'ir/shamol (loop),
  momaqaldiroq, 4 xil qurol ovozi, splash, g'altak, tishlash qo'ng'irog'i, chiziq uzilishi,
  baliq pirpirashi, boss nidosi, qadam, UI, tanga.

### Platforma
- Sof statik sayt → **WebGL**, Yandex Games talabiga mos (SDK tashqaridan inject qilinadi).
- Saqlash: localStorage (auto, 30 s) + Yandex Cloud.

---

## Boshqaruv

| Tugma | Amal |
|---|---|
| WASD | yurish |
| Sichqoncha | qarash |
| ChB (bosib turish) | qarmoq: otish kuchi → otish; jangda: tortish |
| Sichqoncha harakati (jangda) | zonani baliqda ushlash |
| 1–7 | qurol tanlash |
| R | o'q to'ldirish |
| O'ChB | snayper optikasi |
| E | o'zaro ta'sir (savdogar/kazino/qayiq/boss) |
| Tab / B / Q | inventar / do'kon / kazino |
| F | chiroq |
| G | panjara |
| Esc | pauza |

---

## Arxitektura

```
HowToFish/
├── index.html            # sahifa + importmap (three CDN) + HUD/screen markup
├── css/style.css
├── assets/audio/*.wav    # protsedural ovozlar
├── js/
│   ├── core/             # DOM'siz sof mantiq (Node-test qilinadi)
│   │   ├── balance.js    # BUTUN balans: narxlar, koef., limitlar
│   │   ├── fishData.js   # 52 tur, 6 boss, 6 orol, yem, tumor
│   │   ├── fishing.js    # CastMachine + updateFight (tension mini-o'yin)
│   │   ├── weapons.js    # 7 qurol, 25 lvl, trick-shot, armed-fish
│   │   ├── casino.js     # ruletka/slot/blackjack/poker (RTP test)
│   │   ├── bosses.js     # HP, faza, 8 xil hujum, unlock
│   │   ├── inventory.js  # sovutgich/panjara/chiroq
│   │   ├── shop.js       # savdogarlar, xarid, orol ochish
│   │   ├── luck.js       # 0–100 omad, 95% qoidasi
│   │   ├── time.js       # kun/tun + 8 ob-havo (iqlim bo'yicha)
│   │   └── save.js       # holat, ≤200 KB tekshiruvi
│   ├── world.js          # Three.js: relef, suv/osmon shader, ob-havo, prop'lar
│   ├── player.js         # FPS nazorat + viewmodel animatsiyalar
│   ├── fishing.js        # mini-o'yinni 3D + UI bilan bog'lash
│   ├── weapons.js        # hitscan/melee runtime
│   ├── ui.js             # HUD + ekranlar (do'kon/kazino/...)
│   ├── net.js            # ko'p o'yinchi adapteri (local/fusion*/mirror*)
│   ├── yandex.js         # SDK ko'prigi + offline fallback
│   ├── audio.js          # WebAudio: loop kanallari, 3D pan, synth
│   ├── i18n.js           # UZ/RU/EN lug'at
│   └── main.js           # orchestrator (sikl, boss jangi, hodisalar)
├── tests/
│   ├── logic.test.mjs    # 76 unit-test
│   └── browser.test.mjs  # 42 browser assert (Puppeteer + SwiftShader)
├── tools/
│   ├── gen_audio.py      # WAV generator (kutubxonasiz)
│   └── serve.py          # statik server (0.0.0.0)
└── docs/                 # skrinshotlar + YANDEX.md
```

**Muhim prinsip:** butun o'yin matematikasi (`js/core/*`) renderdan ajratilgan —
shuning uchun balans Unity/Godot portiga **tayyor qiymatlar jadvali** sifatida ko'chadi.

---

## Ma'lum cheklovlar (halol ravishda)

1. **Photon Fusion / Mirror** — brauzerda server talab qiladi; adapter interfeysi tayyor,
   stub izohli. Lokal koop BroadcastChannel orqali to'liq ishlaydi (2+ tab oching).
2. Vizual uslub — **stylized low-poly realizm** (protsedural geometriya). Haqiqiy
   AAA-teksturalar Yandex'da og'irlik qiladi; suv/osmon shaderlari real-time.
3. Ovozlar protsedural (fayl hajmini kichik tutish uchun). Yandex'da OGG'ga konvert
   qilish tavsiya etiladi (`tools/gen_audio.py` → ffmpeg).
4. Multiplayer'da boss janglari har bir klientda lokal hisoblanadi (host-authoritative
   emas) — Photon'ga o'tganda `net.js` interfeysi orqali host rejim qo'shiladi.
