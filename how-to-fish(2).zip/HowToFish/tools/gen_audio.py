#!/usr/bin/env python3
"""
gen_audio.py — protsedural ovoz fayllari (16-bit mono/stereo WAV, 44.1 kHz).
Hech qanday tashqi kutubxona kerak emas:  python3 tools/gen_audio.py
"""
import math, os, random, struct, wave

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'assets', 'audio')
os.makedirs(OUT, exist_ok=True)


def write_wav(name, samples, sr=SR, stereo=False):
    path = os.path.join(OUT, name)
    with wave.open(path, 'wb') as w:
        w.setnchannels(2 if stereo else 1)
        w.setsampwidth(2)
        w.setframerate(sr)
        frames = bytearray()
        if stereo:
            for l, r in samples:
                frames += struct.pack('<hh', int(max(-1, min(1, l)) * 32767), int(max(-1, min(1, r)) * 32767))
        else:
            for s in samples:
                frames += struct.pack('<h', int(max(-1, min(1, s)) * 32767))
        w.writeframes(bytes(frames))
    print(f'  {name:22s} {len(samples)/sr:5.2f}s  {os.path.getsize(path)/1024:6.0f} KB')


def noise(n, rng):
    return [rng.uniform(-1, 1) for _ in range(n)]


def env(i, n, a=0.01, d=0.3):
    """attack-decay envelope, 0..1"""
    t = i / n
    at = int(a * n)
    if i < at:
        return i / max(1, at)
    return max(0.0, 1.0 - (i - at) / max(1, (n - at))) ** d


def lowpass(xs, k=0.15):
    y, out = 0.0, []
    for x in xs:
        y += k * (x - y)
        out.append(y)
    return out


def highpass(xs, k=0.1):
    y, prev_x, prev_y, out = 0.0, 0.0, 0.0, []
    for x in xs:
        y = k * (prev_y + x - prev_x)
        out.append(y)
        prev_x, prev_y = x, y
    return out


def normalize(xs, peak=0.9):
    m = max((abs(x) for x in xs), default=1.0) or 1.0
    return [x / m * peak for x in xs]


def mix(*tracks):
    n = max(len(t) for t in tracks)
    out = [0.0] * n
    for t in tracks:
        for i, v in enumerate(t):
            out[i] += v
    return out


rng = random.Random(20260919)

# ---------------- 1. Suv shovqini (loop, stereo) ----------------
def water(sec=8.0):
    n = int(SR * sec)
    raw = noise(n, rng)
    lp = lowpass(raw, 0.06)
    out = []
    for i in range(n):
        t = i / SR
        # sekin "to'lqin" modulyatsiyasi
        m = 0.55 + 0.30 * math.sin(2 * math.pi * 0.11 * t) + 0.15 * math.sin(2 * math.pi * 0.037 * t + 1.3)
        out.append(lp[i] * m * 0.85)
    # qirg'oq "shapaloq"lari
    for _ in range(int(sec * 1.4)):
        c = rng.randint(0, n - 4000)
        L = rng.randint(2500, 7000)
        f = rng.uniform(500, 1400)
        for i in range(L):
            e = math.sin(math.pi * i / L) ** 2
            out[c + i] += e * 0.10 * math.sin(2 * math.pi * f * i / SR) * rng.uniform(0.6, 1.0)
    return normalize(out, 0.55)


stereo = list(zip(water(), water()))
write_wav('water_loop.wav', stereo, stereo=True)

# ---------------- 2. Qushlar (loop) ----------------
def birds(sec=10.0):
    n = int(SR * sec)
    out = [0.0] * n
    for _ in range(int(sec * 2.2)):
        c = rng.randint(0, n - 9000)
        chirps = rng.randint(2, 6)
        for k in range(chirps):
            off = c + int(k * rng.uniform(0.06, 0.16) * SR)
            L = int(rng.uniform(0.035, 0.09) * SR)
            f0 = rng.uniform(1800, 4200)
            sweep = rng.uniform(-900, 1400)
            ph = 0.0
            for i in range(L):
                if off + i >= n:
                    break
                ph += 2 * math.pi * (f0 + sweep * i / L) / SR
                e = math.sin(math.pi * i / L) ** 1.5
                out[off + i] += 0.22 * e * (math.sin(ph) + 0.3 * math.sin(2 * ph))
    return normalize(out, 0.5)


write_wav('birds_loop.wav', birds())

# ---------------- 3. Qamish shitirlashi (loop) ----------------
def reeds(sec=6.0):
    n = int(SR * sec)
    raw = noise(n, rng)
    hp = highpass(raw, 0.35)
    out = []
    for i in range(n):
        t = i / SR
        m = 0.35 + 0.65 * max(0.0, math.sin(2 * math.pi * 0.21 * t) * math.sin(2 * math.pi * 0.073 * t + 0.7))
        out.append(hp[i] * m * 0.5)
    return normalize(out, 0.35)


write_wav('reeds_loop.wav', reeds())

# ---------------- 4. Yomg'ir (loop) ----------------
def rain(sec=6.0):
    n = int(SR * sec)
    raw = noise(n, rng)
    hp = highpass(raw, 0.5)
    out = [x * 0.5 for x in hp]
    for _ in range(int(sec * 90)):   # alohida tomchilar
        c = rng.randint(0, n - 900)
        L = rng.randint(250, 900)
        f = rng.uniform(900, 3200)
        for i in range(L):
            e = math.exp(-6 * i / L)
            out[c + i] += 0.10 * e * math.sin(2 * math.pi * f * i / SR)
    return normalize(out, 0.5)


write_wav('rain_loop.wav', rain())

# ---------------- 5. Bo'ron shamoli (loop) ----------------
def wind(sec=8.0):
    n = int(SR * sec)
    raw = noise(n, rng)
    lp = lowpass(raw, 0.035)
    out = []
    for i in range(n):
        t = i / SR
        m = 0.4 + 0.6 * abs(math.sin(2 * math.pi * 0.09 * t) * math.sin(2 * math.pi * 0.031 * t + 2.1))
        out.append(lp[i] * m * 3.2)
    return normalize(out, 0.5)


write_wav('wind_loop.wav', wind())

# ---------------- 6. Momaqaldiroq ----------------
def thunder(sec=5.0):
    n = int(SR * sec)
    raw = noise(n, rng)
    lp = lowpass(raw, 0.02)
    out = []
    for i in range(n):
        t = i / SR
        e = math.exp(-1.6 * t) * (1 + 0.6 * math.sin(2 * math.pi * 1.7 * t))
        out.append(lp[i] * e * 6.0)
    return normalize(out, 0.85)


write_wav('thunder.wav', thunder())

# ---------------- 7. Qurol ovozlari ----------------
def gunshot(sec=0.55, body=900, crack=0.05, tail=0.30, level=1.0):
    n = int(SR * sec)
    out = [0.0] * n
    # "crack" — yuqori chastotali portlash
    L = int(SR * crack)
    for i in range(L):
        e = math.exp(-40 * i / L)
        out[i] += level * e * rng.uniform(-1, 1)
    # "body" — o'rta chastota
    L = int(SR * 0.09)
    ph = 0.0
    for i in range(L):
        e = math.exp(-22 * i / L)
        ph += 2 * math.pi * (body * (1 - 0.5 * i / L)) / SR
        out[i] += level * 0.9 * e * math.sin(ph)
    # "tail" — aks sado
    tl = int(SR * tail)
    raw = noise(tl, rng)
    lp = lowpass(raw, 0.05)
    for i in range(tl):
        e = math.exp(-7 * i / tl)
        out[i] += level * 0.35 * e * lp[i] * 3
    return normalize(out, 0.95)


write_wav('shot_pistol.wav', gunshot(0.40, 800, 0.035, 0.22, 0.85))
write_wav('shot_rifle.wav', gunshot(0.75, 620, 0.06, 0.45, 1.0))
write_wav('shot_auto.wav', gunshot(0.34, 900, 0.03, 0.18, 0.8))
write_wav('shot_sniper.wav', gunshot(1.20, 420, 0.08, 0.85, 1.0))

# ---------------- 8. Boshqa effektlar ----------------
def splash(sec=0.9):
    n = int(SR * sec)
    out = [0.0] * n
    raw = noise(n, rng)
    bp = highpass(lowpass(raw, 0.4), 0.25)
    for i in range(n):
        e = math.exp(-5.5 * i / n)
        out[i] = bp[i] * e * 2.2
    L = int(SR * 0.05)
    for i in range(L):
        out[i] += 0.5 * math.exp(-30 * i / L) * rng.uniform(-1, 1)
    return normalize(out, 0.8)


write_wav('splash.wav', splash())


def reel_click(sec=0.07, f=2600):
    n = int(SR * sec)
    out = []
    for i in range(n):
        e = math.exp(-55 * i / n)
        out.append(e * (math.sin(2 * math.pi * f * i / SR) + 0.5 * rng.uniform(-1, 1)))
    return normalize(out, 0.5)


write_wav('reel_click.wav', reel_click())


def bite_bell(sec=0.8):
    n = int(SR * sec)
    out = []
    for i in range(n):
        t = i / SR
        e = math.exp(-4 * t)
        out.append(e * 0.6 * (math.sin(2 * math.pi * 1180 * t) + 0.5 * math.sin(2 * math.pi * 1770 * t)
                              + 0.25 * math.sin(2 * math.pi * 2360 * t)))
    return normalize(out, 0.6)


write_wav('bite_bell.wav', bite_bell())


def ui_click(sec=0.09):
    n = int(SR * sec)
    out = []
    for i in range(n):
        e = math.exp(-45 * i / n)
        out.append(e * (math.sin(2 * math.pi * 1500 * i / SR) * 0.7 + rng.uniform(-1, 1) * 0.3))
    return normalize(out, 0.4)


write_wav('ui_click.wav', ui_click())


def coins(sec=0.9):
    n = int(SR * sec)
    out = [0.0] * n
    for k in range(6):
        c = int(k * 0.055 * SR + rng.uniform(0, 0.02) * SR)
        L = int(0.16 * SR)
        f = rng.uniform(2100, 3400)
        for i in range(L):
            if c + i >= n:
                break
            e = math.exp(-16 * i / L)
            out[c + i] += 0.28 * e * (math.sin(2 * math.pi * f * i / SR) + 0.4 * math.sin(2 * math.pi * f * 1.51 * i / SR))
    return normalize(out, 0.6)


write_wav('coins.wav', coins())


def slash(sec=0.28):
    n = int(SR * sec)
    raw = noise(n, rng)
    bp = highpass(raw, 0.6)
    out = []
    for i in range(n):
        t = i / n
        e = math.sin(math.pi * t) ** 0.7
        out.append(bp[i] * e * 1.8)
    return normalize(out, 0.6)


write_wav('slash.wav', slash())


def punch(sec=0.22):
    n = int(SR * sec)
    out = []
    ph = 0.0
    for i in range(n):
        e = math.exp(-18 * i / n)
        ph += 2 * math.pi * (180 * (1 - 0.6 * i / n)) / SR
        out.append(e * (math.sin(ph) + 0.4 * rng.uniform(-1, 1)))
    return normalize(out, 0.8)


write_wav('punch.wav', punch())


def step(sec=0.16):
    n = int(SR * sec)
    raw = noise(n, rng)
    lp = lowpass(raw, 0.12)
    out = []
    for i in range(n):
        e = math.exp(-14 * i / n)
        out.append(lp[i] * e * 5)
    return normalize(out, 0.45)


write_wav('step.wav', step())


def line_snap(sec=0.35):
    n = int(SR * sec)
    out = [0.0] * n
    for i in range(int(0.02 * SR)):
        out[i] += 0.9 * math.exp(-60 * i / n) * rng.uniform(-1, 1)
    L = int(0.25 * SR)
    ph = 0.0
    for i in range(L):
        e = math.exp(-9 * i / L)
        ph += 2 * math.pi * (320 - 180 * i / L) / SR
        out[i] += 0.4 * e * math.sin(ph)
    return normalize(out, 0.8)


write_wav('line_snap.wav', line_snap())


def fish_flop(sec=0.7):
    n = int(SR * sec)
    out = [0.0] * n
    raw = noise(n, rng)
    lp = lowpass(raw, 0.2)
    for k in range(4):
        c = int(k * 0.14 * SR)
        L = int(0.1 * SR)
        for i in range(L):
            if c + i >= n:
                break
            e = math.exp(-12 * i / L)
            out[c + i] += 0.5 * e * lp[i] * 4
    return normalize(out, 0.7)


write_wav('fish_flop.wav', fish_flop())


def boss_roar(sec=2.2):
    n = int(SR * sec)
    out = []
    ph = ph2 = 0.0
    for i in range(n):
        t = i / n
        e = math.sin(math.pi * t) ** 0.6
        f = 70 + 40 * math.sin(2 * math.pi * 3.1 * t)
        ph += 2 * math.pi * f / SR
        ph2 += 2 * math.pi * f * 1.5 / SR
        out.append(e * 0.55 * (math.sin(ph) + 0.4 * math.sin(ph2) + 0.25 * rng.uniform(-1, 1)))
    return normalize(out, 0.85)


write_wav('boss_roar.wav', boss_roar())

print(f'\nOK: {OUT}')
