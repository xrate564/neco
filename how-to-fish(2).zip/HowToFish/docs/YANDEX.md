# Yandex Games'ka nashr qilish qo'llanmasi

## 1. Tayyorlash

```bash
# ovoz hajmini kamaytirish (tavsiya): WAV → OGG
cd HowToFish/assets/audio
for f in *.wav; do ffmpeg -i "$f" -c:a libvorbis -q:a 4 "${f%.wav}.ogg"; done
# keyin js/audio.js da FILES yuklashda '.ogg' ni afzal ko'ring (fallback '.wav')
```

O'yin **sof statik fayllar** — build/pack kerak emas. Butun `HowToFish/` papkasini
ZIP qiling (`node_modules` va `tests` siz — faqat o'yin fayllari):

```
index.html, css/, js/, assets/audio/
```

## 2. SDK

- `js/yandex.js` `window.YaGames` ni kutadi. Yandex platformasi sahifaga
  `/sdk.js` ni **o'zi inject qiladi** — hech narsa qo'shmang.
- Lokal/sandbox'da avtomatik **offline rejim**: localStorage save, mock liderbord/IAP.

## 3. Teleblar va ularning kod joyi

| Talab | Metod | Joyi |
|---|---|---|
| Cloud save ≤ 200 KB | `yandex.saveCloud(state)` | `js/yandex.js` (hajm `core/save.js:fitsYandexCloud` tekshiradi) |
| Liderbord | `yandex.setScore(...)` / `getScores()` | eng katta baliq har sotuvda yuboriladi (`ui.js:_openVendorSell`) |
| Rewarded video | `yandex.showRewarded(cb)` | savdogar oynasidagi "📺 ×2 pul" tugmasi |
| Interstitial | `yandex.showInterstitial()` | `main.js` dan chaqiring (masalan orol almashtirganda) |
| IAP | `yandex.getPurchases()/buy(id)` | mock katalog tayyor (remove_ads, starter_pack, golden_rod) |
| GameplayStart/Stop | `yandex.gameplayStart/Stop` | `main.js:startGame/toMenu` da chaqirilgan |
| LoadingAPI.ready | `yandex.loadingReady()` | `main.js:boot` da |

## 4. Moderatsiya nazorat-ro'yxati

- [ ] Barcha matn 3 tilda (UZ/RU/EN) — Yandex RU talab qiladi, bor.
- [ ] O'yin pauzada reklama ko'rsatmaydi (faqat opted-in rewarded) ✔.
- [ ] Saqlash hajmi: `core/save.js` testi 200 KB limitni kafolatlaydi.
- [ ] Pointer-lock: Yandex iframe'da ruxsat; `index.html` fullscreen CSS bilan.
- [ ] `orientation`/mobil: hozir desktop-first (klaviatura). Mobil uchun sensor
      tugmalar keyingi bosqich.

## 5. Multiplayer (Photon Fusion) ga o'tish

`js/net.js` dagi `NetAdapter.connect()` ichida `mode === 'fusion'` tarmog'ini
haqiqiy Photon WebGL SDK (`Photon-realtime.min.js`) chaqiruvlari bilan to'ldiring:
`joinRoom`, `onJoinRoom`, `raiseEvent`. Hodisalar formati (`state/event/damage/catch`)
allaqachon umumiy — render qismi o'zgarmaydi.
