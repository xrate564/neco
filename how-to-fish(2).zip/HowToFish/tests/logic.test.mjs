/**
 * tests/logic.test.mjs — sof mantiq testlari.
 * Ishga tushirish:  node HowToFish/tests/logic.test.mjs
 */
import assert from 'node:assert/strict';
import { CFG, SIZE_ORDER, RARITY_ORDER } from '../js/core/balance.js';
import { SPECIES, BOSSES, ISLANDS, BAITS, CHARMS, fishPrice, pickSpecies, rollSizeTier, rollWeight, rollWeighted, SPECIES_BY_ID } from '../js/core/fishData.js';
import { createFight, updateFight, CastMachine, biteDelay, rollCatch, setFightRng } from '../js/core/fishing.js';
import { WEAPONS, weaponStats, upgradeCost, shotDamage, trickShot, valueMultiplier, armedFishShot } from '../js/core/weapons.js';
import { LuckSystem, rollLuckyFish } from '../js/core/luck.js';
import { createBoss, updateBoss, damageBoss, unlockNextIsland, bossReward, BOSS_ATTACKS } from '../js/core/bosses.js';
import { Cooler, Grill, Lantern, makeCatchEntry } from '../js/core/inventory.js';
import { shopCatalog, purchase, upgradeWeapon, sellFish, VENDORS, canUnlockIsland, unlockIsland, restockVendors } from '../js/core/shop.js';
import { spinRoulette, resolveRoulette, spinSlots, Blackjack, PokerGame, evaluatePoker, simulateHouseEdge, handValue } from '../js/core/casino.js';
import { WorldTime, Weather, WEATHERS, mulberry32 } from '../js/core/time.js';
import { GameState, createInitialState, fitsYandexCloud } from '../js/core/save.js';

let pass = 0, fail = 0;
const T = (name, fn) => {
  try { fn(); pass++; console.log(`  ✔ ${name}`); }
  catch (e) { fail++; console.log(`  ✘ ${name}\n     ${e.message}`); }
};
const rnd = mulberry32(1337);
const section = (s) => console.log(`\n— ${s}`);

/* ---------------- 1. Ma'lumotlar ---------------- */
section('Ma\'lumotlar (species/islands/bosses)');
T('50+ baliq turi bor', () => assert.ok(SPECIES.length >= 50, `${SPECIES.length} ta`));
T('barcha 6 rarity ishlatilgan', () => {
  const set = new Set(SPECIES.map((s) => s.rarity));
  for (const r of RARITY_ORDER) assert.ok(set.has(r), `${r} yo'q`);
});
T('har bir orolda kamida 8 tur uchraydi', () => {
  for (const isle of ISLANDS) {
    const n = SPECIES.filter((s) => s.islands.includes(isle.id)).length;
    assert.ok(n >= 8, `${isle.name}: ${n}`);
  }
});
T('har bir orolda bitta boss', () => {
  assert.equal(BOSSES.length, ISLANDS.length);
  assert.equal(new Set(BOSSES.map((b) => b.island)).size, ISLANDS.length);
});
T('qurollangan baliqlar mavjud', () => assert.ok(SPECIES.filter((s) => s.armed).length >= 5));
T('species id lari takrorlanmaydi', () => assert.equal(new Set(SPECIES.map((s) => s.id)).size, SPECIES.length));
T('barcha qurollangan baliq qurollari katalogda', () => {
  for (const s of SPECIES.filter((x) => x.armed)) assert.ok(WEAPONS[s.armedWeapon], s.id);
});

/* ---------------- 2. Narx matematikasi ---------------- */
section('Narx / o\'ldirish usuli / Mythic 50×');
T('Mythic baliq Common dan ≥50× qimmat (bir xil og\'irlikda)', () => {
  const com = fishPrice({ species: 'perch', tier: 'Hefty', weight: 2, method: 'rod' });
  const myt = fishPrice({ species: 'megalodon', tier: 'Hefty', weight: 2, method: 'rod' });
  const baseRatio = myt / com;
  const withoutMythicBonus = myt / CFG.rarity.mythicValueBonus / com;
  assert.ok(baseRatio > 50, `ratio ${baseRatio}`);
  assert.ok(withoutMythicBonus < baseRatio, 'mythicValueBonus qo\'llanmagan');
});
T('pichoq = 2× (rod ga nisbatan)', () => {
  const r = fishPrice({ species: 'pike', tier: 'Massive', weight: 6, method: 'rod' });
  const k = fishPrice({ species: 'pike', tier: 'Massive', weight: 6, method: 'knife' });
  assert.equal(Math.round(k / r * 100) / 100, 2);
});
T('snayper 1.6×, musht 1.75×', () => {
  const base = fishPrice({ species: 'cod', tier: 'Hefty', weight: 5, method: 'rod' });
  assert.equal(Math.round(fishPrice({ species: 'cod', tier: 'Hefty', weight: 5, method: 'sniper' }) / base * 100) / 100, 1.6);
  assert.equal(Math.round(fishPrice({ species: 'cod', tier: 'Hefty', weight: 5, method: 'fist' }) / base * 100) / 100, 1.75);
});
T('pishirilgan baliq ×1.75', () => {
  const raw = fishPrice({ species: 'carp', tier: 'Massive', weight: 8 });
  const cooked = fishPrice({ species: 'carp', tier: 'Massive', weight: 8, cooked: true });
  assert.equal(Math.round(cooked / raw * 100) / 100, CFG.economy.grillMult);
});
T('savdogarlar turli narx beradi (blackMarket > fishMarket > pier)', () => {
  const o = { species: 'salmon', tier: 'Colossal', weight: 12 };
  const bm = fishPrice({ ...o, vendor: 'blackMarket' });
  const fm = fishPrice({ ...o, vendor: 'fishMarket' });
  const pr = fishPrice({ ...o, vendor: 'pier' });
  assert.ok(bm > fm && fm > pr, `${bm} ${fm} ${pr}`);
});
T('hajm sinfi narxni oshiradi (Plump < Leviathan)', () => {
  const a = fishPrice({ species: 'carp', tier: 'Plump', weight: 1 });
  const b = fishPrice({ species: 'carp', tier: 'Leviathan', weight: 1 });
  assert.ok(b > a * 4);
});
T('trick-shot multiplikatori 12× dan oshmaydi', () => {
  const t = trickShot({ weaponId: 'sniper', distance: 200, headshot: true, scoped: false, playerAirborne: true, fishAirborne: true, moving: true, weakspot: true });
  assert.ok(t.mult <= CFG.kill.trickShotMaxMult + 1e-9, `mult ${t.mult}`);
  assert.ok(t.parts.length >= 5);
});
T('trick-shot: no-scope faqat snayperda', () => {
  const t = trickShot({ weaponId: 'sniper', distance: 30, scoped: false });
  assert.ok(t.parts.includes('noscope'));
  const t2 = trickShot({ weaponId: 'rifle', distance: 30, scoped: false });
  assert.ok(!t2.parts.includes('noscope'));
});

/* ---------------- 3. Qurollar ---------------- */
section('Qurollar (7 tur, 25 daraja)');
T('7 xil qurol', () => assert.equal(Object.keys(WEAPONS).length, 7));
T('har bir qurol 25 darajagacha, zarar o\'sadi', () => {
  for (const id of Object.keys(WEAPONS)) {
    const a = weaponStats(id, 1), b = weaponStats(id, 25);
    assert.ok(b.dmg >= a.dmg, `${id} dmg`);
    assert.ok(b.rpm >= a.rpm, `${id} rpm`);
    assert.ok(b.spread <= a.spread + 1e-9, `${id} spread`);
    assert.equal(upgradeCost(25), Infinity, `${id} max`);
  }
});
T('yangilash narxi o\'simli', () => {
  const c = [1, 5, 10, 20, 24].map(upgradeCost);
  for (let i = 1; i < c.length; i++) assert.ok(c[i] > c[i - 1], c.join(','));
});
T('masofa bilan zarar pasayadi', () => {
  const near = shotDamage({ weaponId: 'pistol', level: 5, distance: 3 });
  const far = shotDamage({ weaponId: 'pistol', level: 5, distance: 50 });
  assert.ok(far < near);
});
T('headshot 1.6×', () => {
  const a = shotDamage({ weaponId: 'rifle', level: 3, distance: 10 });
  const b = shotDamage({ weaponId: 'rifle', level: 3, distance: 10, headshot: true });
  assert.ok(b > a * 1.5 && b < a * 1.7);
});
T('qurollangan baliq o\'q otadi va zarar beradi', () => {
  const sp = SPECIES_BY_ID['megalodon'];
  let hits = 0, dmg = 0;
  for (let i = 0; i < 200; i++) { const r = armedFishShot(sp, 10, rnd); if (r.hit) { hits++; dmg += r.dmg; } }
  assert.ok(hits > 20, `hits ${hits}`);
  assert.ok(dmg > 0);
});

/* ---------------- 4. Baliq ovlash mini-o'yini ---------------- */
section('Fishing mini-o\'yini (tension)');
setFightRng(rnd);

/** Insondek o'ynaydigan AI: tension 0.55 dan pastda tortadi, 0.85 da qo'yib yuboradi (pump). */
function playFight(st, dt = 1 / 60, maxSteps = 12000) {
  let low = false, i = 0;
  while (st.state === 'fight' && i++ < maxSteps) {
    const inZone = st.fishPos >= st.zonePos && st.fishPos <= st.zonePos + st.zoneWidth;
    if (!low && st.tension >= 0.85) low = true;      // qo'yib yubor
    else if (low && st.tension <= 0.55) low = false;  // qayta tort
    updateFight(st, dt, { reeling: !low && inZone, zone: st.fishPos });
  }
  return i;
}

T('har doim terminal holatga yetadi (300 simulyatsiya)', () => {
  let caught = 0, snapped = 0, escaped = 0, other = 0;
  for (let i = 0; i < 300; i++) {
    const st = createFight({ speciesId: 'carp', tier: SIZE_ORDER[i % 6], rnd });
    // AI: zonani baliqqa olib boradi, tension yuqori bo'lsa — qo'yib yuboradi (pump)
    const steps = playFight(st);
    assert.ok(steps < 12000, 'guard tugadi');
    assert.equal(st.state, 'done', 'terminal emas');
    assert.ok(st.result, 'result yo\'q');
    if (st.result.ok) caught++;
    else if (st.result.reason === 'line_snap') snapped++;
    else if (st.result.reason === 'escaped') escaped++;
    else other++;
  }
  const rate = caught / 300;
  assert.ok(rate >= 0.4 && rate <= 1, `catch rate ${rate} (snap ${snapped}, escape ${escaped}, other ${other})`);
});
T('yaxshi o\'yin katta baliqni ham tutadi (Leviathan)', () => {
  let caught = 0;
  for (let i = 0; i < 60; i++) {
    const st = createFight({ speciesId: 'wels', tier: 'Leviathan', rnd });
    playFight(st);
    if (st.result?.ok) caught++;
  }
  assert.ok(caught >= 30, `caught ${caught}/60`);
});
T('doimiy bosib tursang chiziq uziladi (spam = fail)', () => {
  let snaps = 0;
  for (let i = 0; i < 40; i++) {
    const st = createFight({ speciesId: 'wels', tier: 'Leviathan', rnd });
    let guard = 0;
    while (st.state === 'fight' && guard++ < 12000) updateFight(st, 1 / 60, { reeling: true });
    if (st.result?.reason === 'line_snap') snaps++;
  }
  assert.ok(snaps >= 30, `snaps ${snaps}/40`);
});
T('zonani noto\'g\'ri joyda ushlab tursang — baliq qochadi', () => {
  let escaped = 0;
  for (let i = 0; i < 20; i++) {
    const st = createFight({ speciesId: 'pike', tier: 'Massive', rnd });
    let guard = 0;
    // zonani bar chap chetida ushlab turish, tortmaslik → baliq qochib ketadi
    while (st.state === 'fight' && guard++ < 12000) updateFight(st, 1 / 60, { reeling: false, zone: 0 });
    if (st.result?.reason === 'escaped') escaped++;
  }
  assert.ok(escaped >= 10, `escaped ${escaped}/20`);
});
T('hech narsa qilmasang baliq qochib ketadi', () => {
  const st = createFight({ speciesId: 'pike', tier: 'Massive', rnd });
  let guard = 0;
  while (st.state === 'fight' && guard++ < 6000) updateFight(st, 1 / 60, { reeling: false });
  assert.ok(['escaped', 'timeout'].includes(st.result.reason), st.result.reason);
});
T('katta baliq uchun zona torroq', () => {
  const small = createFight({ speciesId: 'minnow', tier: 'Plump', rnd });
  const big = createFight({ speciesId: 'megalodon', tier: 'Mythic', rnd });
  assert.ok(big.zoneWidth < small.zoneWidth, `${big.zoneWidth} vs ${small.zoneWidth}`);
});
T('tension hech qachon 1 dan oshmaydi va 0 dan pastga tushmaydi', () => {
  const st = createFight({ speciesId: 'bream', tier: 'Hefty', rnd });
  for (let i = 0; i < 3000; i++) {
    updateFight(st, 1 / 60, { reeling: i % 3 === 0 });
    if (st.state !== 'fight') break;
    assert.ok(st.tension >= 0 && st.tension <= 1, st.tension);
  }
});
T('CastMachine holatlar ketma-ketligi to\'g\'ri', () => {
  const seen = [];
  const cm = new CastMachine({ rodLevel: 5, onState: (s) => seen.push(s) });
  assert.equal(cm.state, 'idle');
  cm.startWindup();
  for (let i = 0; i < 80; i++) cm.update(1 / 60);
  const d = cm.release();
  assert.ok(d > CFG.fishing.rod.castDistanceMin, `dist ${d}`);
  for (let i = 0; i < 600 && cm.state !== 'waiting'; i++) cm.update(1 / 60);
  assert.equal(cm.state, 'waiting');
  cm.bite(); assert.equal(cm.state, 'strike');
  assert.equal(cm.hookFish(), true); assert.equal(cm.state, 'fight');
  assert.deepEqual(seen, ['windup', 'airborne', 'sinking', 'waiting', 'strike', 'fight']);
});
T('strike oynasidan o\'tsa — missed_strike', () => {
  const cm = new CastMachine();
  cm.startWindup(); cm.update(1.2); cm.release();
  for (let i = 0; i < 600 && cm.state !== 'waiting'; i++) cm.update(1 / 60);
  cm.bite();
  for (let i = 0; i < 200; i++) cm.update(1 / 60);
  assert.equal(cm.state, 'done');
  assert.equal(cm.result.reason, 'missed_strike');
});
T('ob-havo tishlash vaqtiga ta\'sir qiladi (bo\'ron < oydurov < tuman)', () => {
  const avg = (o) => { let s = 0; for (let i = 0; i < 400; i++) s += biteDelay({ ...o, rnd }); return s / 400; };
  const storm = avg({ weather: 'storm', hour: 12, bait: 'none' });
  const clear = avg({ weather: 'clear', hour: 12, bait: 'none' });
  const fog = avg({ weather: 'fog', hour: 12, bait: 'none' });
  assert.ok(storm < clear && clear < fog, `${storm} ${clear} ${fog}`);
});
T('yem tishlashni tezlashtiradi', () => {
  const avg = (b) => { let s = 0; for (let i = 0; i < 400; i++) s += biteDelay({ bait: b, hour: 12, rnd }); return s / 400; };
  assert.ok(avg('magic') < avg('worm') && avg('worm') < avg('none'));
});
T('pickSpecies har doim o\'sha orol hovuzidan tanlaydi (har orol uchun 400 martadan)', () => {
  for (const isle of ISLANDS) {
    for (let i = 0; i < 400; i++) {
      const sp = pickSpecies({ island: isle.id, luck: 40, bait: 'shrimp', weather: 'rain', hour: 19, rnd });
      assert.ok(sp.islands.includes(isle.id), `${sp.id} ${isle.id} hovuzida yo'q`);
    }
  }
});
T('rollCatch orol hovuzidan tur qaytaradi', () => {
  for (let i = 0; i < 300; i++) {
    const island = i % ISLANDS.length;
    const c = rollCatch({ island, luck: 40, bait: 'shrimp', weather: 'rain', hour: 19, rnd });
    assert.ok(c.species.islands.includes(island), `${c.speciesId} ${island}`);
    assert.ok(c.weight > 0);
    assert.ok(SIZE_ORDER.includes(c.tier));
  }
});
T('orol biomi va baliq biomi mos keladi (sho\'r/chuchuk)', () => {
  for (const isle of ISLANDS) {
    for (const s of SPECIES.filter((x) => x.islands.includes(isle.id))) {
      const ok = isle.biome === 'salt' ? s.biomes.includes('salt') : !s.biomes.includes('salt');
      assert.ok(ok, `${s.id} (${s.biomes}) ${isle.name} (${isle.biome}) da bo'lolmaydi`);
    }
  }
});
T('har bir tur kamida bitta orolda uchraydi', () => {
  for (const s of SPECIES) assert.ok(s.islands.length >= 1, s.id);
});

/* ---------------- 5. Omad ---------------- */
section('Omad tizimi');
T('0 omad → past noyoblik', () => { const l = new LuckSystem(); assert.ok(l.rareChance < 0.15, l.rareChance); });
T('100 omad → ~95% noyob baliq', () => {
  const l = new LuckSystem();
  const c = CHARMS.reduce((a, x) => a + x.luck, 0);
  l.base = Math.max(0, 100 - c);
  // hammasini sotib olish orqali 100 ga chiqaramiz
  const l2 = new LuckSystem(); let money = 1e9;
  for (const ch of CHARMS) l2.buy(ch.id, money);
  assert.ok(l2.value >= 95, `value ${l2.value}`);
  const rc = CFG.luck.rareChanceAt(100);
  assert.ok(rc >= 0.94 && rc <= 0.96, `rareChance ${rc}`);
});
T('omad monoton o\'sadi', () => {
  let prev = -1;
  for (let v = 0; v <= 100; v += 5) { const r = CFG.luck.rareChanceAt(v); assert.ok(r >= prev); prev = r; }
});
T('charm do\'konida pul yetmasa xarid bo\'lmaydi', () => {
  const l = new LuckSystem();
  assert.equal(l.buy('kraken_eye', 10).ok, false);
  assert.ok(l.buy('rabbit_foot', 1000).ok);
  assert.equal(l.buy('rabbit_foot', 1000).reason, 'owned');
});
T('lucky fish faqat ba\'zida', () => {
  let n = 0; for (let i = 0; i < 5000; i++) if (rollLuckyFish(100, rnd).lucky) n++;
  assert.ok(n > 100 && n < 500, `n ${n}`);
});

/* ---------------- 6. Ob-havo / vaqt ---------------- */
section('Ob-havo va kun/tun');
T('yomg\'ir/momaqaldiroq tishlashni oshiradi, qor/tuman kamaytiradi', () => {
  assert.ok(WEATHERS.thunder.bite > 1 && WEATHERS.rain.bite > 1);
  assert.ok(WEATHERS.snow.bite < 1 && WEATHERS.fog.bite < 1);
});
T('har bir orolning o\'z iqlimi/ob-havo to\'plami bor', () => {
  const sets = ISLANDS.map((i) => i.weathers.join(','));
  assert.equal(new Set(sets).size, ISLANDS.length, 'ob-havo to\'plamlari takrorlanadi');
  for (const i of ISLANDS) for (const w of i.weathers) assert.ok(WEATHERS[w], w);
});
T('kun/tun sikli 24 soatni aylanib chiqadi', () => {
  const t = new WorldTime(6, 1);
  let days = 0; const startDay = t.day;
  for (let i = 0; i < 60 * 60 * 26; i++) t.update(1 / 60);
  assert.ok(t.day >= startDay + 1, `day ${t.day}`);
  assert.ok(t.hour >= 0 && t.hour < 24);
});
T('soat fazalari to\'g\'ri', () => {
  const t = new WorldTime(0);
  assert.equal(t.phase, 'night'); t.hour = 6.5; assert.equal(t.phase, 'dawn');
  t.hour = 12; assert.equal(t.phase, 'day'); t.hour = 18; assert.equal(t.phase, 'dusk');
});
T('ob-havo vaqt o\'tishi bilan almashadi', () => {
  const w = new Weather(2, 42);
  const seen = new Set([w.current]);
  for (let i = 0; i < 60 * 60 * 12; i++) { w.update(1 / 60); seen.add(w.current); }
  assert.ok(seen.size >= 2, `faqat ${[...seen]}`);
  for (const s of seen) assert.ok(ISLANDS[2].weathers.includes(s), s);
});
T('momaqaldiroqda chaqmoq chaqnaydi', () => {
  const w = new Weather(0, 7); w.roll('thunder');
  let flashed = 0;
  for (let i = 0; i < 60 * 40; i++) { w.update(1 / 60); if (w.lightning > 0.9) flashed++; }
  assert.ok(flashed > 0, 'chaqmoq yo\'q');
});

/* ---------------- 7. Inventar ---------------- */
section('Inventar (sovutgich/panjara/chiroq)');
T('sovutgich 20 baliq, 21-si sig\'maydi', () => {
  const c = new Cooler();
  for (let i = 0; i < 20; i++) assert.ok(c.add({ speciesId: 'perch', tier: 'Plump', weight: 1, method: 'rod' }).ok);
  assert.equal(c.add({ speciesId: 'perch', tier: 'Plump', weight: 1, method: 'rod' }).reason, 'full');
});
T('panjara pishiradi va narxni oshiradi', () => {
  const c = new Cooler(); const g = new Grill();
  const { item } = c.add({ speciesId: 'carp', tier: 'Hefty', weight: 3, method: 'rod' });
  const before = c.totalValue();
  assert.ok(g.start(c, item.uid).ok);
  for (let i = 0; i < 60 * 6; i++) g.update(1 / 60, c);
  assert.equal(c.items[0].cooked, true);
  assert.ok(c.totalValue() > before * 1.7);
});
T('panjara yoqilg\'isi tugasa ishlamaydi', () => {
  const c = new Cooler(); const g = new Grill(); g.fuel = 0;
  const { item } = c.add({ speciesId: 'perch', tier: 'Plump', weight: 1, method: 'rod' });
  assert.equal(g.start(c, item.uid).reason, 'no_fuel');
});
T('chiroq rejimlari va batareya', () => {
  const l = new Lantern();
  assert.equal(l.modes.length, 5);
  for (let i = 0; i < 60 * 300; i++) l.update(1 / 60, i / 60);
  assert.equal(l.on, false, 'batareya tugagach o\'chishi kerak');
  l.recharge(); assert.equal(l.battery, 100);
});
T('sovutgichdagi barcha baliqlar sotiladi', () => {
  const c = new Cooler();
  for (let i = 0; i < 5; i++) c.add({ speciesId: 'cod', tier: 'Massive', weight: 4, method: 'knife' });
  const r = c.sellAll('blackMarket');
  assert.equal(r.count, 5); assert.equal(c.count, 0); assert.ok(r.money > 0);
});

/* ---------------- 8. Do'kon / iqtisod ---------------- */
section('Do\'kon va iqtisod');
T('pul yetmasa xarid yo\'q', () => {
  const st = new GameState({ money: 10 });
  const item = shopCatalog(st).find((i) => i.id === 'sniper');
  const r = purchase(st, item);
  assert.equal(r.ok, false); assert.equal(r.reason, 'no_money');
});
T('qurol sotib olish + 25 darajagacha yangilash', () => {
  const st = new GameState({ money: 1e7 });
  const item = shopCatalog(st).find((i) => i.id === 'pistol');
  assert.ok(purchase(st, item).ok);
  let lv = 1;
  for (let i = 0; i < 40; i++) { const r = upgradeWeapon(st, 'pistol'); if (!r.ok) { assert.equal(r.reason, 'max_level'); break; } lv = r.level; }
  assert.equal(lv, CFG.weapons.maxLevel);
  assert.equal(weaponStats('pistol', 25).level, 25);
});
T('egallangan qurolni ikkinchi marta sotib bo\'lmaydi', () => {
  const st = new GameState({ money: 1e7 });
  const item = shopCatalog(st).find((i) => i.id === 'knife');
  assert.ok(purchase(st, item).ok);
  assert.equal(purchase(st, { ...item, owned: false }).reason, 'owned');
});
T('savdogar sig\'imi tugasa sotib olmaydi, restock tiklaydi', () => {
  const st = new GameState();
  restockVendors(st);
  st.vendorStock.blackMarket = 0;
  assert.equal(sellFish(st, 'blackMarket', {}, 100).reason, 'vendor_full');
  restockVendors(st);
  assert.ok(sellFish(st, 'blackMarket', {}, 100).ok);
});
T('orol faqat boss mag\'lub bo\'lgach ochiladi', () => {
  const st = new GameState({ money: 1e9 });
  assert.equal(canUnlockIsland(st, 1).reason, 'boss_required');
  st.defeatedBosses.push(0);
  assert.ok(canUnlockIsland(st, 1).ok);
  assert.ok(unlockIsland(st, 1).ok);
  assert.equal(canUnlockIsland(st, 1).reason, 'already');
});
T('o\'q va yem zaxirasi to\'g\'ri oshadi', () => {
  const st = new GameState({ money: 1e6 });
  const ammo = shopCatalog(st).find((i) => i.kind === 'ammo' && i.id === 'auto');
  purchase(st, ammo, 2);
  assert.equal(st.ammo.auto, (ammo.pack ?? 30) * 2);
});

/* ---------------- 9. Boss ---------------- */
section('Boss janglari');
T('har bir boss hujumlari katalogda', () => {
  for (const b of BOSSES) for (const a of b.attacks) assert.ok(BOSS_ATTACKS[a], `${b.id}:${a}`);
});
T('boss HP tushadi, 3 faza bor, mag\'lub bo\'ladi', () => {
  const b = createBoss(0);
  const phases = new Set();
  let guard = 0;
  while (b.alive && guard++ < 10000) {
    updateBoss(b, 0.05, { distance: 8 });
    phases.add(b.phase);
    damageBoss(b, 25);
  }
  assert.equal(b.alive, false);
  assert.deepEqual([...phases].sort(), [1, 2, 3]);
});
T('kam HP da boss tezlashadi (enrage)', () => {
  const b = createBoss(3); b.hp = b.maxHP * 0.2; updateBoss(b, 0.01, {});
  assert.ok(b.enrage > 1.3, b.enrage);
});
T('boss maxsus hujum qiladi', () => {
  const b = createBoss(0);
  let atk = null, guard = 0;
  while (!atk && guard++ < 20000) atk = updateBoss(b, 0.05, { distance: 5 }).attack;
  assert.ok(atk, 'hujum yo\'q');
  assert.ok(BOSS_ATTACKS[atk].dmg >= 0);
});
T('boss masofa tashqarisida bo\'lsa charge qilmaydi', () => {
  const b = createBoss(0);
  b.cooldowns = { charge: 0, summon: 99, whirlpool: 99 };
  const r = updateBoss(b, 0.05, { distance: 500 });
  assert.ok(!r.attack || r.attack !== 'charge', r.attack);
});
T('boss mag\'lubiyati keyingi orolni ochadi + mukofot beradi', () => {
  const st = new GameState();
  const b = createBoss(0); damageBoss(b, 99999);
  const r = unlockNextIsland(st, 0);
  assert.equal(r.unlocked, 1);
  assert.ok(st.unlockedIslands.includes(1));
  const rew = bossReward(b);
  assert.ok(rew.money > 0);
});

/* ---------------- 10. Kazino ---------------- */
section('Kazino');
T('ruletka 0..36 va ranglar to\'g\'ri', () => {
  for (let i = 0; i < 2000; i++) {
    const s = spinRoulette(rnd);
    assert.ok(s.number >= 0 && s.number <= 36);
    assert.ok(['red', 'black', 'green'].includes(s.color));
    if (s.number === 0) assert.equal(s.color, 'green');
  }
});
T('ruletka to\'lovlari: raqam 36×, rang 2×', () => {
  const s = { number: 17, color: 'black' };
  assert.equal(resolveRoulette([{ type: 'number', value: 17, amount: 10 }], s).payout, 360);
  assert.equal(resolveRoulette([{ type: 'black', amount: 10 }], s).payout, 20);
  assert.equal(resolvePayoutSafe(s), 0);
  function resolvePayoutSafe(sp) { return resolveRoulette([{ type: 'red', amount: 10 }], sp).payout; }
});
T('slot: 3 ta bir xil → katta yutuq', () => {
  let jackpot = 0;
  for (let i = 0; i < 20000; i++) { const s = spinSlots(rnd); if (s.reels[0] === s.reels[1] && s.reels[1] === s.reels[2]) { assert.ok(s.mult >= 2); jackpot++; } }
  assert.ok(jackpot > 100, `jackpot ${jackpot}`);
});
T('blackjack: 21 dan oshsa bust', () => {
  const bj = new Blackjack(rnd);
  let busts = 0;
  for (let i = 0; i < 500; i++) { bj.deal(10); let g = 0; while (!bj.done && g++ < 20) bj.hit(); if (bj.result.reason === 'bust') busts++; }
  assert.ok(busts > 100, `busts ${busts}`);
});
T('blackjack 21 = blackjack to\'lovi 2.5×', () => {
  const pad = [];
  for (let i = 0; i < 20; i++) pad.push({ r: '7', s: '♣' });
  // draw() pop() qiladi → oxiridagi karta birinchi chiqadi
  const deck = [...pad, { r: '9', s: '♦' }, { r: '9', s: '♣' }, { r: 'K', s: '♥' }, { r: 'A', s: '♠' }];
  const bj = new Blackjack(rnd, deck);
  bj.deal(100);
  assert.equal(bj.done, true, 'blackjack darhol yakunlanishi kerak');
  assert.equal(bj.result.reason, 'blackjack');
  assert.equal(bj.result.payout, 250);
});
T('handValue: A = 1 yoki 11', () => {
  assert.equal(handValue([{ r: 'A', s: '♠' }, { r: 'K', s: '♠' }]), 21);
  assert.equal(handValue([{ r: 'A', s: '♠' }, { r: 'A', s: '♥' }, { r: '9', s: '♠' }]), 21);
});
T('poker qo\'llarini to\'g\'ri baholaydi', () => {
  const H = (arr) => arr.map(([r, s]) => ({ r, s }));
  assert.equal(evaluatePoker(H([['A','♠'],['K','♠'],['Q','♠'],['J','♠'],['10','♠']])).name, 'straightFlush');
  assert.equal(evaluatePoker(H([['9','♠'],['9','♥'],['9','♦'],['2','♣'],['3','♠']])).name, 'threeKind');
  assert.equal(evaluatePoker(H([['9','♠'],['9','♥'],['2','♦'],['2','♣'],['3','♠']])).name, 'twoPair');
  assert.equal(evaluatePoker(H([['9','♠'],['9','♥'],['4','♦'],['2','♣'],['3','♠']])).name, 'pair');
  assert.equal(evaluatePoker(H([['A','♠'],['2','♥'],['3','♦'],['4','♣'],['5','♠']])).name, 'straight');
  assert.equal(evaluatePoker(H([['A','♠'],['K','♠'],['2','♠'],['7','♠'],['9','♠']])).name, 'flush');
});
T('kazino house edge ijobiy (o\'yinchi uzoq muddatda yutqazadi)', () => {
  const r = simulateHouseEdge(20000, rnd);
  assert.ok(r.rtp > 0.78 && r.rtp < 0.999, `rtp ${r.rtp} edge ${r.edge}`);
});

/* ---------------- 11. Saqlash ---------------- */
section('Saqlash (Yandex Cloud ≤200 KB)');
T('yangi holat seriyalanadi va qayta tiklanadi', () => {
  const st = new GameState();
  st.money = 4321; st.cooler.add({ speciesId: 'pike', tier: 'Epic', weight: 9, method: 'knife' });
  const clone = GameState.fromJSON(st.serialize());
  assert.equal(clone.money, 4321);
  assert.equal(clone.cooler.count, 1);
  assert.equal(clone.cooler.items[0].speciesId, 'pike');
  assert.equal(clone.luck.value, 0);
});
T('saqlash 200 KB dan kichik (hatto to\'la holatda)', () => {
  const st = new GameState({ money: 1e6 });
  for (const s of SPECIES) for (let i = 0; i < 6; i++) st.cooler.items.push({ uid: `x${i}${s.id}`, speciesId: s.id, tier: 'Mythic', weight: 99, method: 'knife', cooked: true });
  st.codex = Object.fromEntries(SPECIES.map((s) => [s.id, { count: 40, best: 99, bestTier: 'Mythic' }]));
  const f = fitsYandexCloud(st);
  assert.ok(f.ok, `${f.kb} KB > ${f.limitKB} KB`);
});
T('statistika va kodeks to\'g\'ri yangilanadi', () => {
  const st = new GameState();
  st.addCatch({ speciesId: 'perch', tier: 'Plump', weight: 1.2 });
  st.addCatch({ speciesId: 'perch', tier: 'Hefty', weight: 2.4 });
  assert.equal(st.stats.caught, 2);
  assert.equal(st.stats.biggest, 2.4);
  assert.equal(st.codex.perch.count, 2);
  assert.equal(st.codex.perch.bestTier, 'Hefty');
  assert.equal(st.codexProgress().seen, 1);
});

/* ---------------- 12. Multiplayer cheklovi ---------------- */
section('Multiplayer');
T('maksimum 4 o\'yinchi', () => assert.equal(CFG.multiplayer.maxPlayers, 4));

/* ---------------- Yakun ---------------- */
console.log(`\n===== ${pass} passed, ${fail} failed =====`);
process.exit(fail ? 1 : 0);
