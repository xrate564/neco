/**
 * tests/net.test.mjs — ko'p o'yinchi adapterini Node'da tekshirish
 * (Node 18+ BroadcastChannel bilan — brauzerdagi kabi ishlaydi).
 * Ishga tushirish: node tests/net.test.mjs
 */
import assert from 'node:assert/strict';
import { NetAdapter } from '../js/net.js';
import { CFG } from '../js/core/balance.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let pass = 0, fail = 0;
const T = (name, fn) => {
  try { fn(); pass++; console.log(`  ✔ ${name}`); }
  catch (e) { fail++; console.log(`  ✘ ${name}\n     ${e.message}`); }
};
const pump = async (adapters, ms = 120, dt = 0.05) => {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    for (const a of adapters) a.update(dt, { name: a.selfName, x: 1, y: 2, z: 3, ry: 0, hp: 100, weapon: 'rod', island: 0 });
    await sleep(10);
  }
};

console.log('— Kooperativ adapter (BroadcastChannel, Node)');
T('maksimum o\'yinchi konfiguratsiyada 4', () => assert.equal(CFG.multiplayer.maxPlayers, 4));

const room = 'NODE_' + Date.now();
const mk = () => new NetAdapter('local');
const A = mk(), B = mk(), C = mk(), D = mk();
const eventsB = [];
B.onEvent = (e) => eventsB.push(e);

await A.connect(room, 'Ali');
await B.connect(room, 'Bek');
await C.connect(room, 'Cam');
await D.connect(room, 'Dil');
await pump([A, B, C, D], 200);

T('4 o\'yinchi bir xonada ko\'rinadi', () => {
  for (const a of [A, B, C, D]) assert.equal(a.count, 4, `${a.selfId}: ${a.count}`);
});
T('holat sinxronlanadi (ism/koordinata)', () => {
  const peer = A.players.get(B.selfId);
  assert.ok(peer, 'B ko\'rinmadi');
  assert.equal(peer.name, 'Bek');
  assert.equal(peer.x, 1);
});

// --- 5-o'yinchi rad etiladi ---
const E = mk();
await E.connect(room, 'Esh');
await pump([A, B, C, D, E], 200);
T('5-o\'yinchi xonaga kirolmaydi (reject protokoli)', () => {
  assert.equal(E.rejected, true, 'E rad etilmagan');
  assert.equal(E.count, 1, `E count=${E.count}`);
  assert.equal(A.count, 4, `A count=${A.count}`);
  assert.equal(A.players.has(E.selfId), false, 'A baribir E ni qo\'shgan');
});
E.disconnect();

// --- PvP zarar hodisasi ---
await pump([A, B, C, D], 60);
const ok = A.sendDamage(B.selfId, 25, 'pistol');
await pump([A, B, C, D], 120);
T('PvP zarar hodisasi nishonga yetib boradi', () => {
  assert.equal(ok, true);
  const ev = eventsB.find((e) => e.type === 'game' && e.kind === 'damage');
  assert.ok(ev, 'hodisa yetmadi');
  assert.equal(ev.data.dmg, 25);
  assert.equal(ev.data.target, B.selfId);
});

// --- o'yin hodisasi (tutish) hammaga boradi ---
const eventsC = [];
C.onEvent = (e) => eventsC.push(e);
A.sendEvent('catch', { speciesId: 'carp', tier: 'Massive', weight: 8, name: 'Ali' });
await pump([A, B, C, D], 120);
T('tutish hodisasi boshqa o\'yinchiga boradi', () => {
  const ev = eventsC.find((e) => e.kind === 'catch');
  assert.ok(ev && ev.data.speciesId === 'carp');
});

// --- chiqib ketgan o'yinchi tozalanadi (prune) ---
D.disconnect();
for (const a of [A, B, C]) for (const p of a.players.values()) if (p.id === D.selfId) p.lastSeen = performance.now() - 99999;
await pump([A, B, C], 80);
T('uzilib qolgan o\'yinchi ro\'yxatdan chiqadi', () => {
  for (const a of [A, B, C]) assert.equal(a.players.has(D.selfId), false, `${a.selfId} hali ushlab turibdi`);
  assert.equal(A.count, 3);
});

A.disconnect(); B.disconnect(); C.disconnect();
console.log(`\n===== ${pass} passed, ${fail} failed =====`);
process.exit(fail ? 1 : 0);
