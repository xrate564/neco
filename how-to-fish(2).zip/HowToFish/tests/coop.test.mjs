/**
 * tests/coop.test.mjs — haqiqiy 2 sahifa (tab) o'rtasida kooperativ tekshiruvi.
 * Ishga tushirish: node tests/coop.test.mjs [url]
 */
import puppeteer from 'puppeteer';

const URL = process.argv[2] ?? 'http://127.0.0.1:8080/index.html?test';
let pass = 0, fail = 0;
const T = (n, c, x = '') => { if (c) { pass++; console.log(`  ✔ ${n}`); } else { fail++; console.log(`  ✘ ${n} ${x}`); } };

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
const ctx = await browser.createBrowserContext();
const A = await ctx.newPage();
const B = await ctx.newPage();
for (const p of [A, B]) {
  p.on('pageerror', (e) => console.log('PAGEERROR:', e.message));
  await p.setViewport({ width: 640, height: 480 });
}

const boot = async (page, name) => {
  await page.goto(URL, { waitUntil: 'networkidle2', timeout: 90000 });
  await page.waitForFunction(() => window.app && window.app.ui, { timeout: 60000 });
  await new Promise((r) => setTimeout(r, 1500));
  await page.evaluate((n) => { window.app.ya.setPlayerName(n); window.app.playerName = n; }, name);
  await page.click('#btn-play');
  await new Promise((r) => setTimeout(r, 1200));
};

console.log('→ 2 tab kooperativ: ' + URL);
await boot(A, 'Ali');
await boot(B, 'Bek');

await A.evaluate(() => window.app.connectNet('COOPT', true));
await B.evaluate(() => window.app.connectNet('COOPT', false));
await new Promise((r) => setTimeout(r, 1500));

const info = await A.evaluate(() => ({ self: window.app.net.selfId, count: window.app.net.count, names: window.app.net.list().map((p) => p.name) }));
const infoB = await B.evaluate(() => ({ self: window.app.net.selfId, count: window.app.net.count, names: window.app.net.list().map((p) => p.name) }));
T('A va B bir xonada (2/4)', info.count === 2 && infoB.count === 2, JSON.stringify({ info, infoB }));
T('ismlar sinxron', info.names.includes('Bek') && infoB.names.includes('Ali'), JSON.stringify({ info, infoB }));

// A B ni otadi (PvP)
const dmg = await A.evaluate((bid) => window.app.net.sendDamage(bid, 30, 'rifle'), infoB.self);
await new Promise((r) => setTimeout(r, 1200));
const hpB = await B.evaluate(() => ({ hp: window.app.state.hp, php: window.app.player.hp }));
T('PvP: A o\'qi B ga zarar berdi', dmg && hpB.php <= 71 && hpB.hp <= 71, JSON.stringify(hpB));

// B harakatlanadi → A ko'radi
await B.evaluate(() => { window.app.player.pos.x += 5; });
await new Promise((r) => setTimeout(r, 1200));
const posA = await A.evaluate((bid) => {
  const p = window.app.net.players.get(bid);
  const m = window.app.remoteMeshes.get(bid);
  return { px: p?.x, mx: m ? +m.position.x.toFixed(1) : null, hasMesh: !!m };
}, infoB.self);
T('B pozitsiyasi A sahnasida yangilanadi (mesh ham bor)', posA.hasMesh && Math.abs((posA.mx ?? 0) - 5) < 2, JSON.stringify(posA));

// tutish hodisasi killfeed'da
await B.evaluate(() => window.app.net.sendEvent('catch', { speciesId: 'wels', tier: 'Leviathan', weight: 90, name: 'Bek' }));
await new Promise((r) => setTimeout(r, 1000));
const feed = await A.evaluate(() => document.getElementById('killfeed').textContent);
T('tutish e\'loni A da ko\'rinadi', feed.includes('wels'), feed);

console.log(`\n===== ${pass} passed, ${fail} failed =====`);
await browser.close();
process.exit(fail ? 1 : 0);
