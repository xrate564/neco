/**
 * tests/browser.test.mjs — haqiqiy Chrome (headless, WebGL) da o'yinni tekshirish.
 * Ishga tushirish: node tests/browser.test.mjs [url]
 */
import puppeteer from 'puppeteer';

const URL = process.argv[2] ?? 'http://127.0.0.1:8080/index.html?test';
const errors = [];
const warns = [];
const logs = [];
let pass = 0, fail = 0;
const T = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`  ✔ ${name}`); }
  else { fail++; console.log(`  ✘ ${name} ${extra}`); }
};

const browser = await puppeteer.launch({
  headless: 'shell',
  args: [
    '--no-sandbox', '--disable-setuid-sandbox',
    '--use-gl=angle', '--use-angle=swiftshader',
    '--enable-unsafe-swiftshader',
    '--window-size=1280,800',
  ],
});
const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 800 });

page.on('console', (m) => {
  const txt = `[${m.type()}] ${m.text()}`;
  logs.push(txt);
  if (m.type() === 'error') errors.push(txt);
  if (m.type() === 'warning') warns.push(txt);
});
page.on('pageerror', (e) => errors.push('[pageerror] ' + e.message));
page.on('response', (r) => { if (r.status() >= 400) errors.push(`[http ${r.status()}] ` + r.url()); });
page.on('requestfailed', (r) => {
  const u = r.url();
  if (u.includes('cdn.jsdelivr')) warns.push('[cdn] ' + u + ' ' + r.failure()?.errorText);
  else errors.push('[requestfailed] ' + u + ' ' + r.failure()?.errorText);
});

console.log('→ ' + URL);
await page.goto(URL, { waitUntil: 'networkidle2', timeout: 90000 });

// yuklanishni kutish
await page.waitForFunction(() => window.app && window.app.world && window.app.ui, { timeout: 60000 });
await new Promise((r) => setTimeout(r, 2500));

console.log('\n— Yuklanish');
T('window.app mavjud', await page.evaluate(() => !!window.app));
T('loader yashirilgan', await page.evaluate(() => document.getElementById('loader').classList.contains('hidden')));
T('menyu ko\'rinadi', await page.evaluate(() => !document.getElementById('menu').classList.contains('hidden')));
T('Three.js sahnasi qurilgan', await page.evaluate(() => window.app.world.scene.children.length > 5),
  await page.evaluate(() => 'children=' + window.app.world.scene.children.length));
T('52 baliq turi yuklangan', await page.evaluate(() => window.app.world.interactables.length > 0));
T('interaktiv obyektlar (do\'kon/kazino/pirs/boss)', await page.evaluate(() => window.app.world.interactables.length >= 8),
  await page.evaluate(() => 'n=' + window.app.world.interactables.length));
T('ovoz fayllari dekodlangan', await page.evaluate(() => Object.keys(window.app.audio.buffers).length >= 18),
  await page.evaluate(() => 'n=' + Object.keys(window.app.audio.buffers).length));

console.log('\n— O\'yinni boshlash');
await page.click('#btn-play');
await new Promise((r) => setTimeout(r, 1200));
T('mode = play', (await page.evaluate(() => window.app.mode)) === 'play');
T('HUD ko\'rinadi', await page.evaluate(() => !document.getElementById('hud').classList.contains('hidden')));
T('o\'yinchi orolda', await page.evaluate(() => Math.hypot(window.app.player.pos.x, window.app.player.pos.z) < 40));

console.log('\n— Qarmoq otish');
const stBefore = await page.evaluate(() => window.app.fishing.machine.state);
await page.mouse.move(640, 400);
await page.mouse.down();
// test rejimida kadr tezligi past — kuch yig'ilishini holat bo'yicha kutamiz
await page.waitForFunction(() => window.app.fishing.machine.power >= 0.6, { timeout: 40000 });
const power = await page.evaluate(() => window.app.fishing.machine.power);
await page.mouse.up();
await page.waitForFunction(() => ['waiting', 'strike', 'fight'].includes(window.app.fishing.machine.state), { timeout: 15000 });
const stAfter = await page.evaluate(() => window.app.fishing.machine.state);
T('windup boshlandi (idle → …)', stBefore === 'idle', `before=${stBefore}`);
T('otish kuchi yig\'ildi', power > 0.4, `power=${power}`);
T('qarmoq suvda (waiting)', stAfter === 'waiting' || stAfter === 'strike' || stAfter === 'fight', `after=${stAfter}`);
T('poplavok ko\'rinadi', await page.evaluate(() => window.app.player.bobber.visible));

console.log('\n— Tishlash va mini-o\'yin');
const fightOk = await page.evaluate(async () => {
  const app = window.app;
  // kutish holatiga yetkazish (agar hali bo'lmasa)
  let g = 0;
  while (app.fishing.machine.state === 'airborne' || app.fishing.machine.state === 'sinking') { app.fishing.update(1 / 30); if (g++ > 200) break; }
  app.fishing.machine.bite();                 // tishlashni majburlash
  await new Promise((r) => setTimeout(r, 120));
  if (!app.fishing.machine.hookFish()) return { ok: false, why: 'hook yo\'q: state=' + app.fishing.machine.state };
  await new Promise((r) => setTimeout(r, 200));
  const f = app.fishing.current;
  if (!f) return { ok: false, why: 'fight yo\'q' };
  // yaxshi o'yin: zonani baliqqa olib borish + pump
  let low = false, i = 0;
  const setMouse = (x) => { app.player.mouseNX = x; };
  while (f.state === 'fight' && i++ < 4000) {
    setMouse(f.fishPos);
    if (!low && f.tension >= 0.85) { low = true; app.fishing._reelingHeld = false; }
    else if (low && f.tension <= 0.55) { low = false; }
    app.fishing._reelingHeld = !low;
    app.fishing.update(1 / 60);
    if (f.state === 'done') break;         // finish() current'ni null qiladi — natijani shu yerda olamiz
  }
  return { ok: true, result: f.result, steps: i, species: f.speciesId, tier: f.tier, weight: f.weight, cooler: app.state.cooler.count };
});
T('mini-o\'yin yakunlandi', fightOk.ok && fightOk.result, JSON.stringify(fightOk));
T('baliq tutildi (yoki chiziq uzildi — ikkalasi ham valid)',
  fightOk.result && ['caught', 'line_snap', 'escaped', 'timeout'].includes(fightOk.result.reason),
  JSON.stringify(fightOk.result));
const cooler = await page.evaluate(() => window.app.state.cooler.count);
T('sovutgichda baliq bor (agar tutildi)', fightOk.result?.reason === 'caught' ? cooler >= 1 : true, `cooler=${cooler}`);

console.log('\n— Qurol tizimi');
const weapons = await page.evaluate(async () => {
  const m = await import('./js/core/shop.js');
  const app = window.app;
  app.state.money = 1e7;
  const bought = [];
  for (const id of ['pistol', 'rifle', 'auto', 'sniper', 'knife']) {
    const item = m.shopCatalog(app.state).find((i) => i.id === id);
    const r = m.purchase(app.state, item);
    if (r.ok) bought.push(id);
    let lv = 1;
    for (let i = 0; i < 30; i++) { const u = m.upgradeWeapon(app.state, id); if (!u.ok) break; lv = u.level; }
    app.state.levels[id] = lv;
  }
  // rod va fist do'konda sotilmaydi, lekin ular ham 25 darajagacha yangilanadi
  for (const id of ['rod', 'fist']) {
    for (let i = 0; i < 30; i++) { const u = m.upgradeWeapon(app.state, id); if (!u.ok) break; app.state.levels[id] = u.level; }
  }
  return { bought, levels: { ...app.state.levels }, money: app.state.money };
});
T('5 xil qurol sotib olindi', weapons.bought.length === 5, JSON.stringify(weapons.bought));
T('har biri 25-darajaga chiqdi', Object.values(weapons.levels).every((v) => v === 25), JSON.stringify(weapons.levels));

console.log('\n— O\'q otish (hitscan + boss)');
const shotTest = await page.evaluate(async () => {
  const app = window.app;
  app.player.setWeapon('sniper');
  app.state.ammo.sniper = 100;
  app.combat.clips.sniper = 10;
  app.startBoss();
  const hp0 = app.bossState.hp;
  // boss AI ni muzlatamiz (aks holda u harakatlanib nishondan chiqib ketadi)
  app.bossState.hold = true;
  const mesh = app.world.boss.mesh;
  mesh.position.copy(app.player.cam.position).add(app.player.forward.clone().multiplyScalar(5));
  mesh.updateMatrixWorld(true);
  app.combat.hitscanTargets = app.collectTargets();
  const res = app.combat.fire(app.player);
  return { hp0, res: res ? { dmg: res.dmg, dist: +res.dist.toFixed(1), trick: res.trick, target: res.target } : null };
});
T('boss paydo bo\'ldi', shotTest.hp0 > 0, `hp0=${shotTest.hp0}`);
T('o\'q nishonga tegdi (hitscan + zarar + trick-shot)', !!shotTest.res && shotTest.res.dmg > 0 && shotTest.res.target === 'boss', JSON.stringify(shotTest));
T('trick-shot hisoblandi', !!shotTest.res?.trick?.mult, JSON.stringify(shotTest.res?.trick));

console.log('\n— Boss mag\'lubiyati → orol ochilishi');
const bossDone = await page.evaluate(() => {
  const app = window.app;
  let guard = 0;
  while (app.bossState?.alive && guard++ < 500) app.combat.onKill({ target: 'boss', dmg: 500, trick: { mult: 1, parts: [] } });
  return { defeated: app.state.defeatedBosses.slice(), money: app.state.money, unlocked: app.state.unlockedIslands.slice(), bossGone: !app.bossState };
});
T('boss mag\'lub bo\'ldi', bossDone.defeated.includes(0), JSON.stringify(bossDone.defeated));
T('keyingi orol ochildi', bossDone.unlocked.includes(1), JSON.stringify(bossDone.unlocked));
T('mukofot pul berdi', bossDone.money > 1e6, `money=${bossDone.money}`);

console.log('\n— Kazino');
await page.evaluate(() => window.app.ui.show('casino'));
await new Promise((r) => setTimeout(r, 400));
T('kazino ekrani ochildi', await page.evaluate(() => !document.getElementById('casino').classList.contains('hidden')));
const casinoTest = await page.evaluate(async () => {
  const app = window.app;
  const before = app.state.money;
  app.state.money = 5000;
  app.ui.casinoTab = 'slots'; app.ui.renderCasino();
  document.getElementById('slot-btn').click();
  await new Promise((r) => setTimeout(r, 1500));
  const afterSlots = app.state.money;
  app.ui.casinoTab = 'blackjack'; app.ui.renderCasino();
  const bjMoney0 = app.state.money;
  document.getElementById('bj-deal').click();
  await new Promise((r) => setTimeout(r, 250));
  const bj = !!app.ui.bj && app.ui.bj.player.length === 2 && app.state.money < bjMoney0;
  app.ui.casinoTab = 'roulette'; app.ui.renderCasino();
  document.querySelector('[data-rb="red"]').click();
  document.getElementById('spin-btn').click();
  await new Promise((r) => setTimeout(r, 4000));
  return { before, afterSlots, bj, afterRoulette: app.state.money };
});
T('slot mashinasi ishlaydi (pul o\'zgardi)', casinoTest.afterSlots !== 5000, JSON.stringify(casinoTest));
T('blackjack karta tarqatdi', casinoTest.bj);
T('ruletka aylanib to\'lov berdi', typeof casinoTest.afterRoulette === 'number');

console.log('\n— Do\'kon / inventar / kodeks / orollar / sozlamalar');
for (const [id, sel] of [['shop', '#shop-body'], ['inv', '#inv-body'], ['codex', '#codex-body'], ['islands', '#islands-body'], ['settings', '#settings-body']]) {
  await page.evaluate((i) => window.app.ui.show(i), id);
  await new Promise((r) => setTimeout(r, 250));
  const len = await page.evaluate((s) => document.querySelector(s).innerHTML.length, sel);
  T(`${id} ekrani to'ldirildi`, len > 200, `len=${len}`);
}

console.log('\n— Til almashtirish');
const langs = await page.evaluate(() => {
  const out = {};
  for (const l of ['uz', 'ru', 'en']) {
    window.app.state.settings.lang = l;
    window.app.ui.refreshLang();
    out[l] = document.querySelector('#btn-play').textContent;
  }
  return out;
});
T('3 til ham ishlaydi', langs.uz !== langs.ru && langs.ru !== langs.en && langs.uz.length > 3, JSON.stringify(langs));

console.log('\n— Saqlash (Yandex Cloud ≤200 KB)');
const saveTest = await page.evaluate(async () => {
  const app = window.app;
  app.state.money = 1e6;
  for (let i = 0; i < 15; i++) app.state.cooler.items.push({ uid: 'x' + i, speciesId: 'megalodon', tier: 'Mythic', weight: 900, method: 'sniper', trickMult: 8, cooked: true, luckyMult: 2 });
  const local = app.saveGame(false);
  const cloud = await app.saveCloud();
  return { local, cloud, bytes: app.state.byteSize() };
});
T('lokal saqlash muvaffaqiyatli', saveTest.local.ok);
T('cloud save 200 KB dan kichik', saveTest.cloud.ok && saveTest.cloud.bytes <= 200 * 1024, JSON.stringify(saveTest.cloud));

console.log('\n— Kooperativ (BroadcastChannel)');
const coopTest = await page.evaluate(async () => {
  const app = window.app;
  const ok = await app.connectNet('TESTROOM', true);
  await new Promise((r) => setTimeout(r, 300));
  return { ok, connected: app.net.connected, selfId: app.net.selfId, count: app.net.count };
});
T('BroadcastChannel orqali ulandi', coopTest.connected === true, JSON.stringify(coopTest));
T('maks 4 o\'yinchi cheklovi', await page.evaluate(() => window.app.net.count <= 4));

console.log('\n— Orolga sayohat + ob-havo');
const travelTest = await page.evaluate(async () => {
  const app = window.app;
  app.resume();
  app.travel(1);
  await new Promise((r) => setTimeout(r, 900));
  return { island: app.state.island, name: app.world.island.name, weather: app.weather.current };
});
T('orol almashdi', travelTest.island === 1 && travelTest.name === 'Cold Pine Bay', JSON.stringify(travelTest));

console.log('\n— Ishlash unumdorligi (FPS)');
const fps = await page.evaluate(() => new Promise((res) => {
  let n = 0; const t0 = performance.now();
  const step = () => { n++; if (performance.now() - t0 < 2000) requestAnimationFrame(step); else res(n / ((performance.now() - t0) / 1000)); };
  requestAnimationFrame(step);
}));
T('render sikli ishlaydi (SwiftShader software renderer)', fps > 0.3, `fps=${fps.toFixed(1)} (dasturiy renderer — haqiqiy GPU da 60 FPS)`);

console.log('\n— Xatolar');
const realErrors = errors.filter((e) => !/favicon|cdn\.jsdelivr/.test(e));
T('konsol xatolari yo\'q', realErrors.length === 0, '\n    ' + realErrors.slice(0, 8).join('\n    '));
if (warns.length) console.log('  ⚠ ' + warns.length + ' warning (cdn/audio): ' + warns.slice(0, 3).join(' | '));

console.log(`\n===== ${pass} passed, ${fail} failed =====`);
await browser.close();
process.exit(fail ? 1 : 0);
